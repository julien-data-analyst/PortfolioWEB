########################################-
# Auteur : Renoult Julien, Rukimirago Axelle, 
# Mohamed Camara, Lou-Anne Thomas
# Date : 06/06/2023
# Sujet : Analyse des ventes
# Données : Ventes.csv
########################################-

###################################-

###############################-

# ---- Importation des données ----

## Prise de connaissance de la structure du fichier

readLines(con = "../DATA/Ventes.csv", n=10)

## Importation

read.table(file = "../DATA/Ventes.csv",
           sep = ",", encoding = "UTF-8", header = TRUE) -> dataset

head(dataset, n=10)

## Changement de type des données

str(dataset)

within(dataset, {Date = as.Date(Date, 
                   format = "%d-%m-%Y");

                Temp = as.POSIXct(Heure_minutes_secondes, 
                   format = "%H : %M : %S");
                
                nom_produits = factor(nom_produits);
                
                Catégorie = factor(Catégorie);
                
                Sous.catégorie = factor(Sous.catégorie)
                
                
                }) -> data

str(data)


###############################-

# ---- Analyse exploratoire ----

# ---- Top 5 des produits ----

## Top 5 des produits les plus vendus

### Récupération des 5 produits les plus vendus 

with(data, split(Quantité, nom_produits)) -> liste_quantite

sapply(liste_quantite, sum) -> sum_par_produits

sort(sum_par_produits, decreasing = TRUE)[1:5] -> top5

top5 = round((top5/sum(top5))*100,2)
### Représentation graphique des cinq produits les plus vendus 

graphique_quantité = barplot(height = top5,
                           col = "green4",
                           main = "Top 5 des produits les plus vendus",
                           xlab = "Nom du produit",
                           ylab = "Quantité vendu",
                           cex.names = 1,
                           ylim = c(0,top5[1]+5))

text(graphique_quantité, top5+1,
     labels =paste0(top5, "%"))

## Top 5 des produits qui rapportent le plus

with(data, split(Prix_total, nom_produits)) -> liste_quantite

sapply(liste_quantite, sum) -> sum_par_produits

sort(sum_par_produits, decreasing = TRUE)[1:5] -> top5

### Représentation graphique des cinq produits qui rapportent le plus

graphique_quantité = barplot(height = top5,
                             col = "red",
                             main = "Top 5 des produits qui rapportent le plus",
                             xlab = "Nom du produit",
                             ylab = "Quantité vendu",
                             ylim = c(0,top5[1]+5))

text(graphique_quantité, top5+2,
     labels =paste0(top5, " €"))

###############################-
## Montant total rapporté

montant_total = sum(data$Prix_total)

print(paste0(montant_total, " € le montant total rapporté pour toutes les ventes"))

## Montant total rapporté pour chaque jour

with(dataset, split(Prix_total, Date)) -> liste_montant_2

with(data, split(Prix_total, Date)) -> liste_montant

sapply(liste_montant, sum) -> sum_par_jour

graphique_montant = barplot(height = sum_par_jour,
                            col = "orange",
                            names.arg = names(liste_montant_2),
                            main = "Montant total rapporté selon le jour",
                            xlab = "Date du jour",
                            ylab = "Montant total",
                            ylim = c(0,sum_par_jour[which.max(sum_par_jour)]+50))
  
text(graphique_montant, sum_par_jour+10,
     labels = paste0(sum_par_jour, " €"))      

# ---- Alimentation VS Divers ----

## Quantité vendu selon la catégorie

with(data, split(Quantité, Catégorie)) -> liste_quantite

sapply(liste_quantite, sum) -> sum_par_catégorie

pourcentage_par_catégorie = round((sum_par_catégorie/sum(sum_par_catégorie))*100,2)

graphique_categorie = barplot(height = pourcentage_par_catégorie,
                             col = "yellow",
                             main = "Ventes selon la catégorie",
                             xlab = "Catégorie",
                             ylab = "Pourcentage",
                             ylim = c(0, pourcentage_par_catégorie[which.max(pourcentage_par_catégorie)]+5))

text(graphique_quantité, pourcentage_par_catégorie+2,
     labels =paste0(pourcentage_par_catégorie, "%"))

## Montant rapporté selon la catégorie

with(data, split(Prix_total, Catégorie)) -> liste_montant

sapply(liste_montant, sum) -> prix_total_categorie

graphique_montant = barplot(height = prix_total_categorie,
                            col = "black",
                            main = "Montant total rapporté selon la catégorie",
                            xlab = "Catégorie",
                            ylab = "Montant total",
                            ylim = c(0,prix_total_categorie[which.max(prix_total_categorie)]+50))

text(graphique_montant, prix_total_categorie+10,
     labels = paste0(prix_total_categorie, " €"))      

###############################-
# ---- Sous-catégorie (Alimentation) ----

subset(data, subset = Catégorie == "Alimentation") -> Alimentation

Alimentation$Sous.catégorie = factor(Alimentation$Sous.catégorie)

str(Alimentation)

## Quantité vendu selon la sous-catégorie

with(Alimentation, split(Quantité, Sous.catégorie)) -> liste_quantite

sapply(liste_quantite, sum) -> sum_par_sous_catégorie

pourcentage_par_sous_catégorie = round((sum_par_sous_catégorie/sum(sum_par_sous_catégorie))*100,2)

graphique_sous_categorie = barplot(height = pourcentage_par_sous_catégorie,
                              col = "yellow",
                              main = "Ventes selon la sous-catégorie (Alimentaton)",
                              xlab = "Sous-catégorie",
                              ylab = "Pourcentage",
                              ylim = c(0, pourcentage_par_sous_catégorie[which.max(pourcentage_par_sous_catégorie)]+5))

text(graphique_sous_categorie, pourcentage_par_sous_catégorie+2,
     labels =paste0(pourcentage_par_sous_catégorie, "%"))

## Montant rapporté selon la sous-catégorie

with(Alimentation, split(Prix_total, Sous.catégorie)) -> liste_montant

sapply(liste_montant, sum) -> prix_total_categorie

graphique_montant = barplot(height = prix_total_categorie,
                            col = "black",
                            main = "Montant total rapporté selon la sous-catégorie (Alimentaton)",
                            xlab = "Sous-catégorie",
                            ylab = "Montant total",
                            ylim = c(0,prix_total_categorie[which.max(prix_total_categorie)]+10))

text(graphique_montant, prix_total_categorie+5,
     labels = paste0(prix_total_categorie, " €"))    

###############################-
# ---- Sous-catégorie (Divers) ----

subset(data, subset = Catégorie == "Divers") -> Divers

Divers$Sous.catégorie = factor(Divers$Sous.catégorie)

str(Divers)

## Quantité vendu selon la sous-catégorie

with(Divers, split(Quantité, Sous.catégorie)) -> liste_quantite

sapply(liste_quantite, sum) -> sum_par_sous_catégorie

pourcentage_par_sous_catégorie = round((sum_par_sous_catégorie/sum(sum_par_sous_catégorie))*100,2)

graphique_sous_categorie = barplot(height = pourcentage_par_sous_catégorie,
                                   col = "yellow",
                                   main = "Ventes selon la sous-catégorie (Divers)",
                                   xlab = "Sous-catégorie",
                                   ylab = "Pourcentage",
                                   ylim = c(0, pourcentage_par_sous_catégorie[which.max(pourcentage_par_sous_catégorie)]+5))

text(graphique_sous_categorie, pourcentage_par_sous_catégorie+2,
     labels =paste0(pourcentage_par_sous_catégorie, "%"))

## Montant rapporté selon la sous-catégorie

with(Divers, split(Prix_total, Sous.catégorie)) -> liste_montant

sapply(liste_montant, sum) -> prix_total_categorie

graphique_montant = barplot(height = prix_total_categorie,
                            col = "black",
                            main = "Montant total rapporté selon la sous-catégorie (Divers)",
                            xlab = "Sous-catégorie",
                            ylab = "Montant total",
                            ylim = c(0,prix_total_categorie[which.max(prix_total_categorie)]+50))

text(graphique_montant, prix_total_categorie+5,
     labels = paste0(prix_total_categorie, " €"))    

###############################-


# ---- Prix unitaire ----

graphique_prix_unitaire = hist(data$Prix_unitaire,
                               probability = TRUE,
                               breaks = 5,
                               main = "Distribution du prix unitaire des produits vendus",
                               xlab = "Prix unitaire",
                               ylab = "Densité")


### Représentation du montant moyen sur le graphique
abline(v = mean(data$Prix_unitaire),
       lty = 2,
       col = "green4",
       lwd = 2)


### Représentation de la médiane sur le graphique
abline(v = quantile(data$Prix_unitaire,
                    probs = c(0.5)),
       lty =2,
       col = "red",
       lwd = 2)

### Ajout des effectifs sur le graphique 

text(graphique_prix_unitaire$mids,
     graphique_prix_unitaire$density+0.001,
     labels=paste0(round(100*graphique_prix_unitaire$counts/sum(graphique_prix_unitaire$counts),2),"%"))


legend(x = "topright",
       lty = c(2,2,1),
       lwd = c(1,1,1),
       col = c("red", "green4"),
       legend = c(paste0(paste0("Médiane : ", quantile(data$Prix_unitaire,probs = c(0.5)))," €"), 
                  paste0(paste0("Moyenne : ", round(mean(data$Prix_unitaire),2)," €"))),
       bty = "n")
###############################-

