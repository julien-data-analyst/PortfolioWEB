import Package.package_sql as ps
import Package.package as p
import pandas as pd

# -------------------------------------------------------------------------------------------------------------------------------------
# Ce programme permet d'écrire un fichier sur les ventes faites en indiquant différentes informations telles que :
# - Nom produit
# - Quantité
# - Prix unitaire du produit
# - Prix total (Quantité*Prix unitaire pour UN ticket)
# - Date
# - Heure, minutes et les secondes
# - Catégorie
# - Sous-catégorie
# -------------------------------------------------------------------------------------------------------------------------------------

# Récupération de TOUTES les ventes qui se sont faites dans la base de données analyse.db
result = ps.sqlitedonnee("Base_données/analyse.db", "Ventes")

# Les différentes colonnes
dataset = [["id", "nom_produits", "Quantité", "Prix_unitaire", "Prix_total", "Date", "Heure_minutes_secondes", "Catégorie", "Sous-catégorie"]]

# Rajout de l'information sur les catégories et sous-catégories des produits
for tupl in result:
    liste_elt = []
    categorie=ps.sqliterequest("Base_données/base.db", "SELECT Categorie FROM Produits WHERE Nom='"+tupl[1]+"' ;", ())
    if categorie[0][0]=="Alimentation":
        sous_categorie = ps.sqliterequest("Base_données/base.db", "SELECT A.SousCategorie FROM Aliments AS A INNER JOIN Produits AS P ON A.EAN=P.EAN WHERE P.Nom='"+tupl[1]+"' ;", ())
    else :
        sous_categorie = ps.sqliterequest("Base_données/base.db", "SELECT D.SousCategorie FROM Divers AS D INNER JOIN Produits AS P ON D.EAN=P.EAN WHERE P.Nom='"+tupl[1]+"' ;", ())
    
    for elt in tupl:
        liste_elt+=[elt]
    liste_elt+=[categorie[0][0], sous_categorie[0][0]]
    dataset.append(liste_elt)

#print(dataset[0:10])

# Écriture du fichier d'analyse en CSV pour l'analyse graphique avec le langage R
p.writeListtoCSV("Analyse_ventes/DATA/Ventes.csv", dataset)
