import Package.package_sql as ps

# -------------------------------------------------------------------------------------------------------------------------------------
#                                                               CRÉATION BASE DE DONNÉES
# Dans ce programme, nous allons créer les tables nécessaires pour insérer les données des différentes sources. 
# Cela concerne deux fichier db : 
# - base.db concerne la gestion du Stock et Rayon avec les informations en plus des différents produits
# - analyse.db concerne les ventes effectués sur les produits
# -------------------------------------------------------------------------------------------------------------------------------------

# Création des tables pour base.db :

## Préparation des requêtes :

request_drop = ["DROP TABLE IF EXISTS Livre;",
    "DROP TABLE IF EXISTS Lien_livre_auteur;",
    "DROP TABLE IF EXISTS Auteur ;",
    "DROP TABLE IF EXISTS Produits ;",
    "DROP TABLE IF EXISTS Aliments ;",
    "DROP TABLE IF EXISTS Divers ;",
    "DROP TABLE IF EXISTS Stock ;",
    "DROP TABLE IF EXISTS Rayon;"]

request_create = [

    # Partie Livre

    """
    CREATE TABLE Livre(
        EAN INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
        isbn VARCHAR(200) NOT NULL,
        date_publication DATE NOT NULL
    );
    """,
    """
    CREATE TABLE Lien_livre_auteur (
        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
        isbn VARCHAR(200) NOT NULL,
        id_auteur INTEGER NOT NULL
    );
    """,
    """
    CREATE TABLE Auteur (
        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
        Nom_prenom VARCHAR(64) NOT NULL
    );
    """,
    # Partie Produits

    """CREATE TABLE IF NOT EXISTS Produits(
        EAN INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
        Nom varchar(200) NOT NULL,
        Categorie VARCHAR(10) NOT NULL,
        Prix DECIMAL(4,2) NOT NULL,
        Unite INT NOT NULL
    );""",

    # Partie Stock 
    # A pour viandes et poisson. B pour surgelé. C pour céréale. D pour divers. E Fruits_légumes.

    """CREATE TABLE Stock(
    EAN INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
    Lieu VARCHAR(1) NOT NULL,
    Emplacement INT NOT NULL,
    Stock INT NOT NULL
    );""",

    # Partie Rayon 
    # Frais (viandes, poissons et surgelé), Fruits_Légumes, Céréales, Librairie, Général 

    """CREATE TABLE Rayon(
    EAN INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
    Lieu VARCHAR(15) NOT NULL,
    Emplacement INT NOT NULL,
    Rayon INT NOT NULL
    );""",

    # Partie Divers

    """CREATE TABLE IF NOT EXISTS Divers(
    EAN INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
    SousCategorie VARCHAR(10) NOT NULL
    );""",

    # Partie Aliments 

    """CREATE TABLE IF NOT EXISTS Aliments (
    EAN INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
    Date_limite_conso DATE,
    Num_prod_arriv VARCHAR(15),
    SousCategorie VARCHAR(10) NOT NULL
    );"""

    ]

## Exécution des requêtes :

for req in request_drop :
    ps.sqliterequest("Base_données/base.db", req, ())

for req in request_create :
    ps.sqliterequest("Base_données/base.db", req, ())


# Création de la table concernant analyse.db :

## Préparation des requêtes :

request_drop ="DROP TABLE IF EXISTS Ventes;"

request_create = """CREATE TABLE Ventes(
    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, 
    Produits VARCHAR(200) NOT NULL, 
    Quantite INTEGER NOT NULL, 
    Prix_unitaire DECIMAL(5,2) NOT NULL,
    Prix_total DECIMAL(5,2) NOT NULL, 
    date_achat DATE NOT NULL,
    heure_minute_seconde TIME NOT NULL);"""

## Exécution des requêtes :

ps.sqliterequest("Base_données/analyse.db", request_drop, ())

ps.sqliterequest("Base_données/analyse.db", request_create, ())

