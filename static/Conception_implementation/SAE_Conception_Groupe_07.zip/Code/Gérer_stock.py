import Package.Outil_de_commande as ODC

# -------------------------------------------------------------------------------------------------------------------------------------
# Ce programme permet de faire une gestion des stocks et rayon interactif à l'aide de différentes commandes indiqués.
# Un fichier log retrace les différentes actions faites par l'utilisateur.  
# -------------------------------------------------------------------------------------------------------------------------------------

# -------------------------------------------------------------------------------------------------------------------------------------
# ------------------------------------------------------- GESTION STOCK/RAYON ---------------------------------------------------------
# -------------------------------------------------------------------------------------------------------------------------------------

print("\nCOMMENCEMENT DE LA GESTION DES STOCK/RAYON")

fini=False

# Création du fichier log resumer_des_gestions

ODC.file = ODC.fich_log_gest_vent("G")

ODC.file.info("COMMENCEMENT DE LA GESTION")

while fini==False:
    #---- Partie Initialisation ----
    verif = True
    liste_commande=["C","R","E","A","S"]
    #-------------------------------

    #---- Partie demande ----
    ## Commande d'action
    comd = input("Qu'est ce que vous voulez faire ? \n(C) -> Changer de place un produit \n(R) -> Recherche d'un produit \n(E) -> Échanger un produit entre rayon et stock \n(A) -> Ajouter de nouveaux arrivages de produits \n(S) -> Retirer des exemplaires d'un produit \n")

    ## Vérification si la commande écrite est bonne
    if comd in liste_commande:

        ## Nom du produit
        nom = input("Quel est le produit concerné ? \n")

        ## Rayon ou Stock
        ray_stock = input("Est-ce que c'est le rayon (R) ou le stockage (S) qu'il est concerné ? \n")

        ## Vérification si la commande écrtie est bonne
        if ray_stock == "S":
                liste_lieu = ["A","B","C","D","E"]

        elif ray_stock == "R":
                liste_lieu = ["Frais", "Fruits_légumes", "Céréales", "Général", "Librairies"]
        
        else:
                verif=False
                ODC.file.error(nom+" : SAISIE DE COMMANDE INCORRECTE ENTRE STOCK ET RAYON")
                print("\nErreur de saisie de commande au niveau du choix entre rayon et stock\n")

        ## Vérification de l'existence du produit
        nom = nom.replace("'", " ")
        nom = nom.replace('"', ' ')
        result = ODC.recherche_prod(nom, ray_stock, show=False)
        #print(nom)
        #print(result)
    #-------------------------------

        if result != [] and verif==True:
            #---- Partie exécution de la commande ----
            ODC.file.info(nom+" : COMMANDE "+comd+" UTILISE")

            ## Recherche du produit
            if comd=="R": 
                ODC.recherche_prod(nom, ray_stock, show = True)

            ## Changement de place du produit
            elif comd=="C":
                lieu =  input("Quel est le lieu concerné "+ str(liste_lieu)+ " ? \n")
                
                nb_esp=ODC.nb_emplacement(lieu, ray_sto=ray_stock)
                empl = input("Quel est l'emplacement concerné (en nombre) de 0 à "+str(nb_esp)+" ? \n")

                ODC.change_place_stock_rayon(nom, lieu, int(empl), ray_stock )
                    
            ## Échanger exemplaire de produits entre Rayon et Stock 
            elif comd=="E":
                nb = input("Quel est le nombre de produits concernés ? \n")
                ODC.echange_exemplaire_produit(nom, int(nb), ray_stock)

            ## Ajouter/Supprimer des produits définitifs
            else:
                nb = input("Quel est le nombre de produits arrivés/supprimé ? \n")
                if comd=="A":
                    ODC.ret_aj_def(nom, ray_stock, nb=int(nb))

                elif comd=="S":
                    ODC.ret_aj_def(nom, ray_stock, aj_ret="RETIRER", nb=int(nb))
            
            print("Requête exécuté")
            #-------------------------------

        ## Nom produit inexistant
        else:
            ODC.file.error(nom+" : NOM PRODUIT INEXISTANT -> REQUETE IGNORE -> DEMANDE DE CONTINUATION")

    ## Commande incorrecte
    else:
        ODC.file.error("SAISIE DE COMMANDE INCORRECTE")
        print("\nJe n'ai pas compris votre commande \n")
    
    #---- Demande de continuation de la gestion ----
    cont = input("Voulez-vous continuer ? \n OUI (O) ou NON (N) \n")
    
    ## Si NON, on arrête
    if cont.upper()=="N":
        ODC.file.info("FIN DE LA GESTION\n")
        fini=True
    
    ## Si OUI, on continue
    elif cont.upper()=="O":
        print("CONTINUATION DE LA GESTION \n")
    
    ## Sinon, on arrête
    else:
        fini=True
        print("Erreur, fin de la gestion \n")

    #---------------------------------------------

#---------------------------------------------------------------------------------------------
#---------------------------------------------------------------------------------------------
#---------------------------------------------------------------------------------------------