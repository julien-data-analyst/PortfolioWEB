import Package.package_sql as ps
import Package.package as p
import Lecture_des_fichiers as lp
import datetime

# -------------------------------------------------------------------------------------------------------------------------------------
# Pour chaque table présent dans base.db, nous allons insérer les données nécessaires
#    à l'aide des fichiers crées grâce au programme Lecture_des_fichiers.
# ATTENTION : Nous supprimerons les " et ' présent dans les différents noms de produits pour éviter des erreurs dans la suite des autres programmes
# -------------------------------------------------------------------------------------------------------------------------------------

req_insert = ["INSERT INTO Produits VALUES (?,?,?,?,?);",
"INSERT INTO Divers VALUES (?,?);",
"INSERT INTO Livre VALUES (?,?,?);",
"INSERT INTO Lien_livre_auteur(isbn,id_auteur) VALUES (?,?);",
"INSERT INTO Auteur(Nom_prenom) VALUES (?);",
"INSERT INTO Stock VALUES (?,?,?,?);",
"INSERT INTO Rayon VALUES (?,?,?,?);"
 ]

# ---------------------------- Insertion dans Table Produits ----------------------------
# Catégorie alimenation :

for data in lp.inf_prod_alimentaire_1_unite:
    if "'" in data[0] or '"' in data[0]:
        data[0]=lp.supp_guimmet(data[0])

    ps.sqliteinsertdata("Base_données/base.db", req_insert[0], (data[2], data[0],"Alimentation", data[1], 1))

for data in lp.inf_prod_fruits :
    if "'" in data[0] or '"' in data[0]:
        data[0]=lp.supp_guimmet(data[0])

    ps.sqliteinsertdata("Base_données/base.db", req_insert[0], (data[3], data[0], "Alimentation", data[1], data[2]))

#print(ps.sqlitedonnee("Base_données/base.db","Produits",10))

# Catégorie Divers :

for data in lp.inf_prod_div:
    if "'" in data[0] or '"' in data[0]:
        data[0]=lp.supp_guimmet(data[0])
    ps.sqliteinsertdata("Base_données/base.db", req_insert[0], (data[2], data[0], "Divers", data[1], 1))


# ---------------------------- Insertion dans Table Aliments ----------------------------

# Sous-catégorie Poisson, Viande, Surgele

ps.insert_donnees_Alimentaire(lp.inf_alim_total)

ps.insert_donnees_Alimentaire(lp.inf_alim_fruits_legumes)

ps.insert_donnees_Alimentaire(lp.inf_alim_cereal)

#print(ps.sqlitedonnee("Base_données/base.db","Aliments",10))


# ---------------------------- Insertion dans Table Divers ----------------------------

# Divers
for data in lp.inf_prod_divers:
    ps.sqliteinsertdata("Base_données/base.db", req_insert[1], (data[2], "Divers"))

# Librairire
for data in lp.inf_prod_librairie:
    ps.sqliteinsertdata("Base_données/base.db", req_insert[1], (data[2], "Livres"))

#print(ps.sqlitedonnee("Base_données/base.db","Produits",10))
#print(ps.sqlitedonnee("Base_données/base.db","Divers",10))

# ---------------------------- Insertion dans Table Stock ----------------------------

# Catégorie Viande et Poisson
for index,data in enumerate(lp.stock_poisson_viande):
    ps.sqliteinsertdata("Base_données/base.db", req_insert[5], (data[1],"A",lp.emplacement_A[index],data[0]))

#print(ps.sqlitedonnee("Base_données/base.db","Stock",10))

# Catégorie Surgelé 
for index,data in enumerate(lp.stock_surgele):
    ps.sqliteinsertdata("Base_données/base.db", req_insert[5], (data[1],"B",lp.emplacement_B[index],data[0]))

# Catégorie Céréale
for index,data in enumerate(lp.stock_cereal):
    ps.sqliteinsertdata("Base_données/base.db", req_insert[5], (data[1],"C",lp.emplacement_C[index],data[0]))

#print(ps.sqlitedonnee("Base_données/base.db","Stock",10))

# Catégorie Divers et livres
for index,data in enumerate(lp.stock_divers):
    ps.sqliteinsertdata("Base_données/base.db", req_insert[5], (data[1],"D",lp.emplacement_D[index],data[0]))

#print(ps.sqlitedonnee("Base_données/base.db","Stock",10))

# Catégorie Fruits et légumes
for index,data in enumerate(lp.stock_fruits_legumes):
    ps.sqliteinsertdata("Base_données/base.db", req_insert[5], (data[1],"E",lp.emplacement_E[index],data[0]))

#print(ps.sqlitedonnee("Base_données/base.db","Stock",10))

# ---------------------------- Insertion dans Table Rayon ----------------------------

# Rayon Frais :
for index,data in enumerate(lp.rayon_frais):
    ps.sqliteinsertdata("Base_données/base.db", req_insert[6], (data[1],"Frais",index,0))

#print(ps.sqlitedonnee("Base_données/base.db","Rayon",10))

# Rayon Fruits_légumes :
for index,data in enumerate(lp.rayon_fruits_legumes):
    ps.sqliteinsertdata("Base_données/base.db", req_insert[6], (data[1],"Fruits légumes",index,0))

# Rayon Céréale :
for index,data in enumerate(lp.rayon_cereal):
    ps.sqliteinsertdata("Base_données/base.db", req_insert[6], (data[1],"Céréales",index,0))

# Rayon Librairie :
for index,data in enumerate(lp.rayon_librairie):
    ps.sqliteinsertdata("Base_données/base.db", req_insert[6], (data[1],"Librairie",index,0))

# Rayon Générale :
for index,data in enumerate(lp.rayon_general):
    ps.sqliteinsertdata("Base_données/base.db", req_insert[6], (data[1],"Général",index,0))

#print(ps.sqlitedonnee("Base_données/base.db","Rayon",10))

# ---------------------------- Insertion dans Table Livre ----------------------------

for data in lp.Livres_inf:
    date = data[1].split("T")
    date = datetime.datetime.strptime(date[0], '%Y-%m-%d') # en jour,mois,année
    date = date.strftime('%Y-%m-%d')
    ps.sqliteinsertdata("Base_données/base.db", req_insert[2], (data[3], data[0], date))

#print(ps.sqlitedonnee("Base_données/base.db", "Livre", 10))

# ---------------------------- Insertion dans Table Auteur ----------------------------

for keys in lp.auteurs_inf:
    key =''
    if '"' in keys :
        keys = keys.split('"')
        for elt in keys :
            key+=elt
    else:
        key=keys
    ps.sqliteinsertdata("Base_données/base.db", req_insert[4], (key,))

#print(ps.sqlitedonnee("Base_données/base.db", "Auteur", 10))

# ---------------------------- Insertion dans Table Lien_Livre_Auteur ----------------------------

for keys in lp.auteurs_inf:
    key =''
    if '"' in keys :
        elt_sep = keys.split('"')
        for elt in elt_sep :
            key+=elt
    else:
        key=keys
    req_select = 'SELECT id FROM Auteur WHERE Nom_prenom = "'+key+'";'
    id = ps.sqliterequest("Base_données/base.db", req_select, ())
    for isbn in lp.auteurs_inf[keys]:
        ps.sqliteinsertdata("Base_données/base.db", req_insert[3], (isbn, id[0][0]))

#print(ps.sqlitedonnee("Base_données/base.db", "Lien_livre_auteur", 10))