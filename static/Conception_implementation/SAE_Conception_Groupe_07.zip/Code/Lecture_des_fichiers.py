import Package.package as p
import datetime

# -------------------------------------------------------------------------------------------------------------------------------------
# Pour chaque fichier présent dans DATA, nous allons récupérer les données sous forme de liste. Nous allons également créer un dictionnaire
#                                         (name_colonne) afin de faciliter la manipulation de ces listes. 
# -------------------------------------------------------------------------------------------------------------------------------------

name_colonne = {}

# A ) Partie lecture de fichier 
## --------------------------------------------------- Partie lecture fichier CSV ---------------------------------------------------

# Lecture fichier POISSON, les données sont rangées de la façon suivante : 
# ['nom', 'date limite de consomation', "numéro d'arrivage", 'prix', 'stock', 'EAN']

poisson = p.readCSVtoListe("DATA/CSV/poisson.csv")
name_colonne["poisson"] = poisson[0] # Ajout des noms de colonnes
del poisson[0]
#print(poisson[0:4])

# Lecture fichier SURGELE, les données sont rangées de la façon suivante : 
# ['nom', 'date limite de consomation', "numéro de producteur", 'prix', 'stock', 'EAN']

surgele = p.readCSVtoListe("DATA/CSV/surgele.csv")
name_colonne["surgele"] = surgele[0] # Ajout des noms de colonnes
del surgele[0]
#print(surgele[0:4])

# Lecture fichier VIANDE, les données sont rangées de la façon suivante : 
# ['nom', 'date limite de consomation', "numéro de producteur", 'prix', 'stock', 'EAN']

viandes = p.readCSVtoListe("DATA/CSV/viandes.csv")
name_colonne["viandes"] = viandes[0] # Ajout des noms de colonnes
del viandes[0]
#print(viandes[0:4])

## --------------------------------------------------- Partie lecture fichier TXT ---------------------------------------------------

# Lecture fichier DIVERS, les données sont rangées de la façon suivante :
# ['nom','price','stock','EAN']

data_divers = p.readTXTtoList("DATA\TXT\divers.txt")
divers = [] 

for i in data_divers :
    i = i.strip()
    i = i.split("|")
    divers += [i]

name_colonne["divers"] = divers[0] # Ajout des noms de colonnes
del divers[0]

#print(divers[0:4])

# Lecture fichier FRUITS_LEGUMES, les données sont rangées de la façon suivante :
# ['nom','numéro de producteur','price','lot de n unité', stock, EAN]

fruits_legumes = p.readTXTtoList("DATA/TXT/fruits_legumes.txt")

for line in range(len(fruits_legumes)):
    fruits_legumes[line] = fruits_legumes[line].strip('\n')
    fruits_legumes[line] = fruits_legumes[line].split('|') 

name_colonne["fruits_legumes"] = fruits_legumes[0] # Ajout des noms de colonnes
del fruits_legumes[0]

#print(fruits_legumes[0:4])

## --------------------------------------------------- Partie lecture fichier JSON ---------------------------------------------------

# Lecture fichier CEREAL, les données sont rangées de la façon suivante :
# ['name', 'date_limite_conso', 'price', 'stock', 'EAN']

data_cereal = p.readJSONtoOBJET("DATA\JSON\cereal.json")

cereal = []

for elt in data_cereal : 
    nom = elt['name']
    date = elt['date_limite_conso']
    prix = elt['price']
    stock = elt['stock']
    ean = elt['EAN']
    cereal += [[nom,date,prix,stock,ean]]

#print(cereal[0:4])

name_colonne["céréale"] = ['nom', 'date_limite_conso','price','stock','EAN'] # Ajout des noms de colonnes

# Lecture fichier LIBRAIRIE, les données sont rangées de la façon suivante :
# ['title', 'isbn', 'publishedDate', 'authors', 'price', 'stock', 'EAN']

data_librairie = p.readJSONtoOBJET("DATA\JSON\librairie.json")

librairie = []

for elt in data_librairie : 
    nom = elt['title']
    isbn = elt['isbn']
    date = elt['publishedDate']
    auteurs = elt['authors']
    prix = elt['price']
    stock = elt['stock']
    ean = elt['EAN']
    librairie += [[nom,isbn,date,auteurs,prix,stock,ean]]

#print(librairie[0:4])

name_colonne["librairie"] = ['title', 'isbn', 'publishedDate', 'authors', 'price', 'stock', 'EAN'] # Ajout des noms de colonnes

print(name_colonne["librairie"])

# B ) Récupération des données à insérer dans les tables
## --------------------------------------------------- Table Produits ---------------------------------------------------

# Catégorie alimentaire :

inf_prod_poisson = p.produits_inf(poisson, name_colonne, "poisson")
inf_prod_surgele = p.produits_inf(surgele, name_colonne, "surgele")
inf_prod_viande = p.produits_inf(viandes, name_colonne, "viandes")
inf_prod_cereal = p.produits_inf(cereal, name_colonne, "céréale")
inf_prod_alimentaire_1_unite = inf_prod_cereal+inf_prod_surgele+inf_prod_poisson+inf_prod_viande
inf_prod_fruits = p.produits_inf(fruits_legumes, name_colonne, "fruits_legumes")

#print(inf_prod_poisson[0:4])

#print(inf_prod_surgele[0:4])

#print(inf_prod_viande[0:4])

#print(inf_prod_cereal[0:4])

#print(inf_prod_fruits[0:4])

# Catégorie divers :

inf_prod_divers = p.produits_inf(divers, name_colonne, "divers")
inf_prod_librairie = p.produits_inf(librairie, name_colonne, "librairie")
inf_prod_div = inf_prod_divers+inf_prod_librairie
#print(inf_prod_librairie[0:4])
#print(inf_prod_div[0:4])

## --------------------------------------------------- Table Alimentaire ---------------------------------------------------

inf_alim_poisson = p.produits_inf(poisson, name_colonne, "poisson", ["EAN", "date limite de consomation", "numéro d'arrivage"])
inf_alim_viande = p.produits_inf(viandes, name_colonne, "viandes", ["EAN", "date limite de consomation", "numéro de producteur"])
inf_alim_surgele = p.produits_inf(surgele, name_colonne, "surgele", ["EAN", "date limite de consomation", "numéro de producteur"])
inf_alim_fruits_legumes = p.produits_inf(fruits_legumes, name_colonne, "fruits_legumes", ["EAN", "numéro de producteur"])
inf_alim_cereal = p.produits_inf(cereal, name_colonne, "céréale", ["EAN", "date_limite_conso"])

inf_alim_total = inf_alim_poisson+inf_alim_viande+inf_alim_surgele

#print(inf_alim_poisson[0:4])

#print(inf_alim_viande[0:4])

#print(inf_alim_surgele[0:4])

#print(inf_alim_fruits_legumes[0:4])

#print(inf_alim_cereal[0:4])

## --------------------------------------------------- Table Stock ---------------------------------------------------

# 1) Récupération des données :

# Catégorie poisson et viande :
stock_poisson_viande = p.produits_inf(poisson,name_colonne,"poisson", liste_elt =["stock","EAN"])
stock_poisson_viande += p.produits_inf(viandes,name_colonne,"viandes", ['stock', 'EAN'])
#print("----- Poisson et viande -----\n ",stock_poisson_viande[0:10])

# Catégorie surgelé :
stock_surgele = p.produits_inf(surgele,name_colonne,"surgele", liste_elt =["stock","EAN"])
#print("----- Surgelé -----\n ",stock_surgele[0:10])

# Catégorie divers :
stock_divers_D = p.produits_inf(divers,name_colonne,"divers", liste_elt =["stock","EAN"])
stock_librairie = p.produits_inf(librairie,name_colonne,"librairie", ['stock', 'EAN'])
stock_divers = stock_librairie+stock_divers_D
# print("----- Divers -----\n ",stock_divers)

# Catégorie Fruit et légume :
stock_fruits_legumes = p.produits_inf(fruits_legumes,name_colonne,"fruits_legumes", ['stock','EAN'])
# print("----- Fruit -----\n ",stock_fruits_legumes)

# Catégorie Cereal :
stock_cereal = p.produits_inf(cereal,name_colonne,"céréale", ['stock', 'EAN'])
# print("----- céréale -----\n ",stock_cereal)

# 2) Il faut attribuer un emplacement à ses données dans nos stocks (nous assignons les emplacements nous même) :

# Ajout d'un emplacement en Stock A :  viandes et poisson
emplacement_A = []
for emplacement, element in enumerate(stock_poisson_viande):
    emplacement_A += [emplacement]

# Ajout d'un emplacement en Stock B :  surgelé
emplacement_B = []
for emplacement, element in enumerate(stock_surgele):
    emplacement_B += [emplacement]

# Ajout d'un emplacement en Stock C : cereal
emplacement_C = []
for emplacement, element in enumerate(stock_cereal):
    emplacement_C += [emplacement]

# Ajout d'un emplacement en Stock D : divers
emplacement_D = []
for emplacement, element in enumerate(stock_divers):
    emplacement_D += [emplacement]

# Ajout d'un emplacement en Stock E : Fruit/légume
emplacement_E = []
for emplacement, element in enumerate(stock_fruits_legumes):
    emplacement_E += [emplacement]

## --------------------------------------------------- Table Rayon ---------------------------------------------------
# On va récupérer que l'EAN donc nous allons utiliser les données stocks pour ne prendre que les EAN.

# 1) récupération des données :

# Catégorie frais (viandes, poisson et surgelé) :

rayon_frais = stock_surgele+stock_poisson_viande
#print("----- Frais -----\n ",rayon_frais[0:10])

# Catégorie Fruits et légumes :

rayon_fruits_legumes = stock_fruits_legumes
#print("----- Fruits légumes -----\n ",rayon_fruits_legumes[0:10][0])

# Catégorie Céréale :

rayon_cereal = stock_cereal
#print("----- Céréales -----\n ",rayon[0:10])

# Catégorie librairie :

rayon_librairie = stock_librairie
#print("----- Librairie -----\n ",rayon[0:10])

# Catégorie général :

rayon_general = stock_divers_D
#print("----- Générale -----\n ",rayon[0:10])

## --------------------------------------------------- Table Livre ---------------------------------------------------

# 1) récupération des données :

Livres_inf = p.produits_inf(librairie,name_colonne,"librairie", ['EAN', 'isbn', 'publishedDate', 'authors'])

#print(Livres_inf[0:10])

# 2) traitement des auteurs :

auteurs_inf = {}
for data in Livres_inf:
    for auteur in data[2]:
        if not(auteur in auteurs_inf):
           auteurs_inf[auteur] = [data[0]]
        else:
            auteurs_inf[auteur] += [data[0]]

#print(auteurs_inf) # Liste des auteurs reliés aux isbn des différents livres dont ils sont l'auteurs

def supp_guimmet(chaine):
    chaine =chaine.replace("'", " ")
    chaine = chaine.replace('"', ' ')
    return chaine
