if __name__=="__main__":
    import package_sql as ps
    import logger as lo
    file=lo.getLogger("resumer_des_gestions_Stock_Rayon.log")
    base = "..../Base_données/base.db"
else:
    import Package.package_sql as ps
    import Package.logger as lo
    base = "./Base_données/base.db"

# ----------------------------------------------------------------------------------------------------------------------------------------------------
#                                               FONCTION D'AIDE DANS LA GESTION DES STOCKS ET RAYONs
# ----------------------------------------------------------------------------------------------------------------------------------------------------

# ---- CRÉATION DU FICHIER LOG ----
# C'est selon le lancement du programme. Si vous êtes dans la gestion des stocks et rayons (G), alors, on trouvera 
# le résumé des actions faites sur la gestion dans le fichier resumer_des_gestions_Stock_Rayon.log.
# Si c'est pour la vente, alors le résumé des actions faites sur les ventes seront sur le fichier resumer_des_ventes.log.

def fich_log_gest_vent(gest_vent = "V"):
    ## Création du fichier log pour la gestion des STOCKS/RAYONS
    if gest_vent=="G":
        file_act_gestion = lo.getLogger("resumer_des_gestions_Stock_Rayon.log")
        return file_act_gestion
    
    ## Création du fichier log pour les ventes effectués
    elif gest_vent=="V":
        file_act_ventes = lo.getLogger("resumer_des_ventes.log")
        return file_act_ventes
    
    ## ERREUR CRITIQUE DANS L'ARGUMENT POUR LA CRÉATION DU FICHIER LOG
    else:
        return "Erreur critique dans la création du fichier log"
# ---------------------------------


# ---- RECHERCHE D'UN PRODUIT ----
def recherche_prod(nom_produit, ray_sto = "S", show = True):

    # ---- Partie Initialisation ----
    rep_S_R=""
    if ray_sto=="S":
        rep_S_R="Stock"
        arg =" S.EAN, S.Lieu, S.Emplacement, S.Stock, P.Prix"
        ean = "S.EAN"

    elif ray_sto=="R":
        rep_S_R="Rayon"
        arg ="R.EAN, R.Lieu, R.Emplacement, R.Rayon, P.Prix"
        ean = "R.EAN"

    else :
        #print("Erreur de réponse, veuillez recommencez le programme")
        file.error(nom_produit+" : ATTENTION, erreur de saisie au niveau du choix entre rayon et stock pour l'échange entre stock et rayon")
        return 'erreur'
    #------------------------------
    #print(arg, rep_S_R, ray_sto, ean, nom_produit)

    # ---- Partie Exécution ----
    result = ps.sqliterequest(base,'SELECT '+ arg+' FROM '+ rep_S_R+' AS '+ray_sto+' INNER JOIN Produits as P ON P.EAN = '+ ean +' WHERE P.Nom ="'+nom_produit+'" ;',())
    #print(result)
    #---------------------------

    # ---- Partie Retour ----
    ## Si on ne le trouve pas, alors il y aurait une erreur dans le nom du produit
    if result==[]:
        print("\nErreur dans le nom du produit")
        return result

    ## Si on le trouve et qu'il y a en STOCK/RAYON, alors on indique son lieu, son emplacement et le nombre d'exemplaire qu'il y a 
    elif result[0][3]>0:
            if show==True:
                file.info(nom_produit+" : RECHERCHE "+rep_S_R.upper()+" : Lieu : "+result[0][1]+", Emplacement : "+str(result[0][2])+", Exemplaire : "+str(result[0][3]))
                print("\nLe produit "+nom_produit+" se trouve dans "+ rep_S_R.upper() +", dans le lieu "+result[0][1]+", dans l'emplacement "+str(result[0][2])+" pour "+str(result[0][3])+" exemplaires \n")
            return result[0]
        
    ## Si on le trouve mais qu'il n'y a plus d'exemplaire dans STOCK/RAYON, alors on indique son lieu, son emplacement et préviens qu'il n'y a plus d'exemplaire
    elif result[0][3]==0:
            file.warning("ATTENTION : "+nom_produit + " : Recherche "+rep_S_R.upper()+" : Lieu : "+result[0][1]+", Emplacement : "+str(result[0][2])+ ", Exemplaire nulle : "+str(result[0][3]))
            if show == True:
                print("\nAttention le produit n'est plus en "+rep_S_R.upper()+' dans le lieu '+result[0][1]+", dans l'emplacement "+str(result[0][2])+ "\n")
            return result[0]
    
    ## Sinon, il y a une ERREUR CRITIQUE dans la recherche du produit
    else :
            file.critical("CRITIQUE : "+nom_produit + " : Recherche "+rep_S_R.upper()+" : Lieu : "+result[0][0]+", Emplacement : "+str(result[0][1])+ ", Exemplaire erreur : "+str(result[0][2]))
            return "ERREUR CRITIQUE AU NIVEAU DE LA RECHERCHE"
    #---------------------------
#----------------------------------


# ---- ÉCHANGE ENTRE STOCK ET RAYON DES EXEMPLAIRES DU PRODUIT ----
def echange_exemplaire_produit(nom_produit, nb = 1, rayon_stock = "S"):

    #---- Partie Initialisation ----
    # Récupération des informations et préparation des arguments pour retirer le produit soit dans Stock ou dans Rayon

    result_S = recherche_prod(nom_produit, "S", show=False)
    result_R = recherche_prod(nom_produit, "R", show=False)

    #print(result_R)
    #print(result_S)

    repon_ret=""
    repon_aj = ""

    # Préparation des différents arguments
    if rayon_stock=="S":
     result_ret = result_S
     result_aj = result_R
     repon_ret+="Stock"
     repon_aj +="Rayon"

    elif rayon_stock=="R":
        result_ret = result_R
        result_aj = result_S
        repon_ret+="Rayon"
        repon_aj+="Stock"

    else :
        print("Erreur de réponse, veuillez recommencez le programme")
        file.error(nom_produit+" : ATTENTION, erreur de saisie au niveau du choix entre rayon et stock pour le retirement")
        return 'erreur'
    #---------------------------

    # ---- Vérification du nombre demandé a être retirer dans STOCK/RAYON ----
    if nb<=0:
        file.error(nom_produit+" : ATTENTION "+ repon_ret.upper() + " : Erreur de saisie, le nombre demande a etre retirer est negatif ou nulle "+" : "+str(nb))
        print("Erreur de saisie dans le nombre de commande à retirer pour le produit")
        return 'erreur'
    
    elif type(nb)!=int:
        file.error(nom_produit+" : ATTENTION "+ repon_ret.upper() + " : Erreur de saisie, le format du nombre ne correspond pas a celui autorise : "+str(type(nb)))
        print("Erreur de saisie dans le nombre de commande à retirer pour le produit")
        return 'erreur'

    else:
        True
        #print("Ok")
    #--------------------------------------------------------------------------

    # ---- Application de l'échange ----
    if result_ret[3]-nb>=0:
        ## Si le nombre demandés est inférieur au nombre qu'il y a en STOCK/RAYON, alors on exécute l'échange
        ps.sqliteinsertdata(base, "UPDATE "+ repon_ret +" SET "+ repon_ret +" = "+ str(result_ret[3]-nb)+" WHERE EAN="+str(result_ret[0])+" ;",())
        ps.sqliteinsertdata(base, "UPDATE "+ repon_aj +" SET "+ repon_aj +" = "+ str(result_aj[3]+nb)+" WHERE EAN="+str(result_aj[0])+" ;",())

        ## Résumé de l'action effectué
        file.info(nom_produit+" : "+ repon_ret.upper() +" : "+str(result_ret[3])+ " -> "+str(result_ret[3]-nb))
        file.info(nom_produit+" : "+ repon_aj.upper() +" : "+str(result_aj[3])+ " -> "+str(result_aj[3]+nb))

        ## Retourne le produit situé en STOCK/RAYON qui a subi l'échange
        return recherche_prod(nom_produit, rayon_stock, show=False)
    
    elif result_ret[3]>0:
        ## Si le nombre demandés est supérieur à ce qu'on a, alors on préviens l'utilisateur que le produit à moins d'exemplaire que ça en indiquant son nombre
        print(nom_produit+" : Attention, ce produit a moins d'exemplaire que ce qu'on demande dans le "+ repon_ret.upper()+ " : "+str(result_ret[3])+" < "+str(nb))
        
        ## Résumé de l'action effectué
        file.error(nom_produit+" : nb produits "+ repon_ret.upper() +" < nb produits demande. ANNULATION")
        return 'erreur'
        
    else:
        ## Si le nombre en STOCK/RAYON est nul, alors on préviens l'utilisateur que ce produit n'a plus d'exemplaire dans RAYON/STOCK
        print(nom_produit+" : Attention, ce produit n'a plus d'exemplaire dans le "+ repon_ret.upper())

        ## Résumé de l'action effectué
        file.error(nom_produit+" : ATTENTION, ce produit n'est plus dans le "+repon_ret.upper())
        return 'erreur'
    #-------------------------------------
    
#------------------------------------------------------------------


# ---- CHANGEMENT DE PLACE POUR UN PRODUIT ----
def change_place_stock_rayon(nom_produit, lieu , emplacement, ray_sto = "S"):

    # ---- Partie Initialisation ----
    
    ## ---- Partie Lieu ----
    # Lieu : A, B, C, D, E pour STOCK
    if ray_sto=="S":
        re_P_S="Stock"
        liste_lieu=["A","B","C", "D", "E"]

    # Lieu : Frais, Fruits_légumes, Céréales, Général, Librairies pour RAYON
    if ray_sto=="R":
        re_P_S="Rayon"
        liste_lieu=["Frais", "Fruits légumes", "Céréales", "Librairie", "Général"]
    ##----------------------

    ## ---- Partie Emplacement ----
    nb_espac_max = ps.sqliterequest(base, "SELECT MAX(Emplacement) FROM "+re_P_S+" WHERE Lieu = '"+ lieu +"' ;")
    #print(nb_espac_max)
    #------------------------------

    ## ---- Partie Recherche ----
    result=recherche_prod(nom_produit, ray_sto, show=False)
    #print(result)

    result2 = ps.sqliterequest(base, "SELECT P.EAN, P.Nom FROM "+re_P_S +" AS S INNER JOIN Produits AS P ON P.EAN = S.EAN WHERE Emplacement = "+str(emplacement)+" AND Lieu = '"+lieu+"' ;")
    #print(result2)
    ##---------------------------

    ## ---- Partie Exécution ----
    ## Vérification du lieu si elle existe
    if lieu in liste_lieu:
        ## Vérification de l'emplacement proposée
        if emplacement <= nb_espac_max[0][0] and emplacement>=0:
                
                print("Exécution de la requête")

                ## Mise en place de l'échange de place pour le produit
                ps.sqliteinsertdata(base, "UPDATE "+re_P_S+" SET Lieu = '"+result[1]+"', Emplacement = "+str(result[2])+" WHERE EAN = "+str(result2[0][0])+" ;")
                ps.sqliteinsertdata(base, "UPDATE "+re_P_S+" SET Lieu = '"+lieu+"', Emplacement = "+str(emplacement)+" WHERE EAN = "+str(result[0])+" ;")
                
                ## Résumé de l'action 
                file.info(nom_produit+" : RANGER "+re_P_S.upper()+" : Lieu : "+result[1]+" -> "+lieu+", Emplacement : "+str(result[2])+" -> "+str(emplacement))
                file.info(result2[0][1]+" : RANGER "+re_P_S.upper()+" : Lieu : "+lieu+" -> "+result[1]+", Emplacement : "+str(emplacement)+" -> "+str(result[2]))

                ## Retourne la recherche du produit
                return recherche_prod(nom_produit, ray_sto, show=False)
        
        ## Erreur de saisie au niveau de l'emplacement
        else:
            print("Erreur de saisie, l'emplacement "+ emplacement +" n'existe pas dans le lieu "+lieu+", dans "+re_P_S+"\n il n'y a que de 0 à "+nb_espac_max[0][0]+".")
            file.error(nom_produit+" ATTENTION RECHERCHE, Erreur de saisie au niveau de l'emplacement de "+re_P_S.upper()+" pour l'emplacement : " + str(emplacement) + ", combien d'emplacement : "+str(nb_espac_max[0][0]))
    
    ## Erreur de saisie au niveau du lieu
    else:
        print("Erreur de saisie, le lieu "+ lieu +" n'existe pas dans "+re_P_S+". Les lieux existants sont "+str(liste_lieu)+".")
        file.error(nom_produit+" : ATTENTION RECHERCHE, Erreur de saisie au niveau du lieu de "+re_P_S.upper()+" pour le lieu : "+lieu+", lieux existants : "+str(liste_lieu))
    ## --------------------------

#-------------------------------------------------

# ---- AJOUT OU RETIREMENT DÉFINITIF D'UN PRODUIT ----
def ret_aj_def(nom_produit, ray_sto = "S", aj_ret = "AJOUTER", nb=1):

    # ---- Partie Initialisation ----

    ## ---- Vérification de où on doit retirer/ajouter (STOCK/RAYON) -----
    if ray_sto=="S":
        re_P_S="Stock"
    
    elif ray_sto=="R":
        re_P_S="Rayon"
    
    else:
            file.error(nom_produit+" : ATTENTION AJOUTER/RETIRER, Erreur de saisie au niveau du choix entre rayon (R) et stock (S) : "+ray_sto)
            return "erreur"
    ##--------------------------------------------------------------------

    

    ## ---- Vérification du nombre demandé ----
    if nb<=0:
            file.error(nom_produit+" : ATTENTION "+ aj_ret.upper() + " dans "+ re_P_S.upper() +" : Erreur de saisie, le nombre demande a etre retirer est negatif ou nulle "+" : "+str(nb))
            print("Erreur de saisie dans le nombre de commande à "+ aj_ret +" pour le produit")
            return 'erreur'
        
    elif type(nb)!=int:
            file.error(nom_produit+" : ATTENTION "+ aj_ret.upper() + " : Erreur de saisie, le format du nombre ne correspond pas a celui autorise : "+str(type(nb)))
            print("Erreur de saisie dans le nombre de commande à "+ aj_ret.upper() +" pour le produit")
            return 'erreur'

    else:
        n=0
        #print("Ok")
    ##------------------------------------------

    ## ---- Vérifcation si c'est pour retirer ou ajouter des produits ----
    if aj_ret=="RETIRER":
        nb_ar= -nb
    
    elif aj_ret=="AJOUTER":
        nb_ar = nb
    
    else:
            file.error(nom_produit+" : ATTENTION AJOUTER/RETIRER, Erreur de saisie au niveau du choix entre ajout (AJOUTER) et retirement (RETIRER) dans "+ re_P_S.upper() +" : "+aj_ret)
            return "erreur"
    ##--------------------------------------------------------------------

    ## ---- Partie Recherche ----
    result = recherche_prod(nom_produit=nom_produit, ray_sto=ray_sto, show=False)
    #print(result)
    ##---------------------------

    ## ---- Partie Exécution ----

    ## Si on peut ajouter/retirer les produits sans que ça tombe en dessous de zéros, alors on peut exécuter normalement la tâche
    if result[3]+nb_ar>=0:

        ## Exécution de la requête
        ps.sqliteinsertdata(base, "UPDATE "+ re_P_S +" SET "+ re_P_S +" = "+ str(result[3]+nb_ar)+" WHERE EAN="+str(result[0])+" ;",())

        ## Résumé de l'action
        file.info(nom_produit+" : "+aj_ret+" "+re_P_S.upper()+" : "+str(result[3])+" -> "+str(result[3]+nb_ar))

        ## Retourne la recherche du produit
        return recherche_prod(nom_produit,ray_sto=ray_sto, show=False)

    ## Si le nombre demandés (a être retirer spécifiquement) est supérieur au nombre qu'on a en STOCK/RAYON, alors on demande à l'utilisateur s'il veut enlever quand même les produits
    elif result[3]>0: 
        ## Enregistre un WARNING
        file.warning(nom_produit+" : nb produits "+ re_P_S.upper() +" < nb produits demande. Demande de l'enlevement des produits.")

        ## Demande de l'utilisateur pour enlever
        rep=input("ATTENTION le nombre de produits dans le "+ re_P_S.upper() +" est inférieur au nombre de produit demandés à être retirer, voulez vous retirer quand même les produits restants ? \n OUI (O) ou NON (N) \n")
        
        ## Si oui, alors on enlève ce qu'il reste des produits dans RAYON/STOCK
        if rep=="O":
                
                ## Exécution de la requête
                ps.sqliteinsertdata(base, "UPDATE "+ re_P_S +" SET "+ re_P_S +" = "+ str(result[1]-result[1])+" WHERE EAN="+str(result[0])+" ;",())

                ## Résumé de l'action
                file.info(nom_produit+" : "+ re_P_S.upper() +" : "+str(result[1])+ " -> "+str(result[1]-nb))
                
                ## Retourne la recherche du produit
                return recherche_prod(nom_produit, show=False, ray_sto=ray_sto)

        ## Si non, alors on annule le retirement des produits dans RAYON/STOCK
        elif rep=="N":
                    
                    ## Résumé de l'action
                    file.info(nom_produit+" : ANNULATION du retirement des produits dans "+re_P_S.upper())
                
                    ## Annonce à l'utilisateur que ça a été annulé
                    print("\nAnnulation du retirement dans "+re_P_S.upper()+"\n")
                    return "annulation"
        
        ## Sinon, on annule le retirement des produits et on préviens l'utilisateur qu'il a mal répondu
        else:
                    ## Résumé de l'action
                    file.error(nom_produit+" : ATTENTION, erreur dans la saisie de la demande pour le retirement dans le "+re_P_S.upper())
                    
                    ## Annonce à l'utilisateur que ça a été annulé
                    print("\nErreur de réponse, annulation du retirement\n")
                    return 'erreur'
        
    ## Dans le cas où le produits n'a plus d'exemplaire dans STOCK/RAYON, alors on prévient l'utilisateur qu'il n'y en a plus    
    else:
         ## Résumé de l'action
         file.error(nom_produit+" : ATTENTION, Ce produits n'a plus d'exemplaire dans "+re_P_S.upper())

         ## Annonce à l'utilisateur qu'il n'y a plus de produits
         print("Plus de produits dans le "+re_P_S.upper()) 
         return "Plus de produits"    
#-----------------------------------------------------------------------------------------------------------------

# ---- SAVOIR LE NOMBRE D'EMPLACEMENT DANS UN LIEU ----
def nb_emplacement(lieu, ray_sto = "S"):
     
     # ---- Partie Initialisation ----
     if ray_sto=="S":
          re_P_S = "Stock"
     else:
          re_P_S = "Rayon"
     #--------------------------------

     # ---- Partie Exécution ----
     nb_espac_max = ps.sqliterequest(base, "SELECT MAX(Emplacement) FROM "+re_P_S+" WHERE Lieu = '"+ lieu +"' ;")

     return nb_espac_max[0][0]
     #---------------------------
#-------------------------------------------------------

