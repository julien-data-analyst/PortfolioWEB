import logging

# -------------------------------------------------------------------------------------------------------------------------------------
#                                                       AIDE À LA CRÉATION DU FICHIER LOG
# -------------------------------------------------------------------------------------------------------------------------------------

def getLogger(file, format = "%(asctime)s - %(levelname)s - %(message)s"):

    logging.basicConfig(filename = file,
                        filemode = "w",
                        format   = format, 
                        level    = logging.DEBUG)
    return logging.getLogger()

def setLoggerLevel(logger, lvl):
    if lvl == "DEBUG" :
        logger.setLevel(logging.DEBUG)
    elif lvl == "INFO" :
        logger.setLevel(logging.INFO)
    elif lvl == "ERROR" :
        logger.setLevel(logging.ERROR)
    elif lvl == "CRITICAL" :
        logger.setLevel(logging.CRITICAL)
    return logger