import csv
import os
import json
import datetime

# ----------------------------------------------------------------------------------------------------------------------------------------------------
#                                               FONCTION D'AIDE DANS LA LECTURE ET RECHERCHE D'INFORMATIONS DANS LES FICHIERS
# ---------------------------------------------------------------------------------------------------------------------------------------------------

#--------------------------------------
#---- Partie lecture des fichiers ----
#--------------------------------------

#---- Partie TXT ----
def readTXTtoList(path):
    f = open(path,'r', encoding="UTF8")
    lines = f.readlines()
    liste=[]
    for row in lines:
        liste+=[row]
    f.close()
    return liste

def readTXTtoString(path):
    f = open(path,'r', encoding="UTF8")
    lines = f.readlines()
    chaine=''
    for row in lines:
        chaine+=row
    f.close()
    return chaine
#-----------------


#---- Partie CSV ----
def readCSVtoListe(path):
    f = open(path,'r', encoding="utf8")
    reads = csv.reader(f)
    liste=[]
    for row in reads:
        liste.append(row)
    f.close()
    return liste
#--------------------

#---- Partie JSON ----
def readJSONtoOBJET(path):
    f = open(path, "r", encoding="UTF-8")
    dataset = json.load(f)
    return dataset
#---------------------

#--------------------------------------
#---- Partie écriture des fichiers ----
#--------------------------------------

#---- Partie TXT ----
def writeListtoTXT(path,liste):
    f = open(path,'w', encoding="UTF8")
    for chain in liste:
        f.write(chain+"\n")
    f.close()

def writeStrtoTXT(path,chain):
    f = open(path,'w', encoding="UTF8")
    f.write(chain)
    f.close()
#-----------------

#---- Partie CSV ----
def writeListtoCSV(path,liste):
    f = open(path,'w', newline="", encoding="utf8")
    reads = csv.writer(f)
    for donn in liste:
        reads.writerow(donn)
    f.close()
#-----------------

#---- Partie JSON ----
def writeObjettoJSON(path, donnees):
    data_sortie = json.dumps(donnees, sort_keys= True, indent=4)
    #print(data_sortie)
    writeStrtoTXT(path, data_sortie)
    return "OK"
#-----------------

# -------------------------------------------------------------------------------------------------------------------------------------
# Ce programme permet de trouver les différentes informations nécessaires pour l'insertion des données.
# Il n'aide que dans le cas de l'insertion et non à la recherche dans la base de données.
# -------------------------------------------------------------------------------------------------------------------------------------

def produits_inf(donnees, name_colonne, produit, liste_elt =["price","prix","EAN","nom","title","lot de n unité"], recup_type = True):
    """Recherche d'information dans les éléments à l'aide de donnnées, 
    d'un dictionnaire contenant le nom des colonnes, 
    le nom du produit et les éléments à récupérer"""

    #---- Partie Initialisation ----
    informations_donn = []
    table_ind=[]
    #-------------------------------

    #---- Partie Indice ----
    ## Cette partie de programme permet de trouver à l'aide du nom du produit les différentes indices pour trouver les informations nécessaires du produit
    ## On parle pour : poissons, surgelés, livres, céréales, fruits_légumes, viandes, divers
    for ind in range(len(name_colonne[produit])):
            for elt in liste_elt:
                if name_colonne[produit][ind]==elt:
                    table_ind+=[ind]
    #-----------------------

    #print(table_ind)
    
    #---- Partie Recherche ----
    for elt in donnees:
        information = []
        for ind in table_ind:
            information += [elt[ind]]
        if recup_type==True:
            informations_donn.append(information+[produit])
        else:
            informations_donn.append(information)
    #--------------------------

    # Retour des informations demandés et trouvés sur les différents produits.
    return informations_donn
