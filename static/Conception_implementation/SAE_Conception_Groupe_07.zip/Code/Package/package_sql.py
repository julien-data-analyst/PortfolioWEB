import sqlite3
import datetime
import re 

# ----------------------------------------------------------------------------------------------------------------------------------------------------
#                                               FONCTION D'AIDE DANS LA GESTION ET CRÉATION DES BASES DE DONNÉES
# ---------------------------------------------------------------------------------------------------------------------------------------------------

#-------------------------
# ---- Partie requête ----
#-------------------------

#---- Partie INSERTION ----
def sqliteinsertdata(database, sql, data=()) :
    try :
        connection = sqlite3.connect(database)
        c = connection.cursor()
        c.execute(sql, data)
        connection.commit()
        connection.close()
    except Exception as e:
        print(e)
#-------------------------

#---- Partie REQUÊTAGE ----
def sqliterequest(database, sql, data=()) :
    result = None
    try :
        connection = sqlite3.connect(database)
        c = connection.cursor()
        c.execute(sql, data)
        result = c.fetchall()
        connection.close()
    except Exception as e:
        print(e)
    return result
#-------------------------

#---- Partie DONNÉES ----
def sqlitedonnee(database,nom_table,nbr_donnee=0) :
    if nbr_donnee==0:
        req="SELECT * FROM "+nom_table
    else:
        req="SELECT * FROM "+nom_table+" "+"LIMIT "+str(nbr_donnee)
    result = None
    try :
        connection = sqlite3.connect(database)
        c = connection.cursor()
        c.execute(req, ())
        result = c.fetchall()
        connection.close()
    except Exception as e:
        print(e)
    return result
#-----------------------


#---- Partie INSERTION pour les produits de catégorie ALIMENTATION ----

def insert_donnees_Alimentaire(donnees):

    # ---- Dans le cas où il y a le numéro de producteur et la date limite de consommation ----
    if len(donnees[0])==4:
        for data in donnees :
            date = datetime.datetime.strptime(data[0], '%Y-%m-%d') 
            date = date.strftime('%Y-%m-%d')
            sqliteinsertdata("Base_données/base.db","INSERT INTO Aliments VALUES (?,?,?,?);", (data[2], date, data[1], data[3]))
    #------------------------------------------------------------------------------------------


    # ---- Dans le cas où il n'y a que la date limite de consommation et non le numéro de producteur ----
    elif len(donnees[0])==3 and re.match("\d{4}-\d{2}-\d{2}", donnees[0][0])!= None:
        for data in donnees:
            date = datetime.datetime.strptime(data[0], '%Y-%m-%d')
            date = date.strftime('%Y-%m-%d')
            sqliteinsertdata("Base_données/base.db","INSERT INTO Aliments(EAN, Date_limite_conso, SousCategorie) VALUES (?,?,?);", (data[1], date, data[2]))
    #----------------------------------------------------------------------------------------------------

    # ---- Dans le cas où il n'y a que le numéro de producteur ----
    elif len(donnees[0])==3:
        for data in donnees:
            sqliteinsertdata("Base_données/base.db","INSERT INTO Aliments(EAN, Num_prod_arriv, SousCategorie) VALUES (?,?,?);", (data[1], data[0], data[2]))
    #--------------------------------------------------------------

    # ---- ERREUR CRITIQUE ----
    else:
        return "error"
    #--------------------------
    
#-----------------------------------------------------------------------
