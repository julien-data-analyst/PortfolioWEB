import distribution_rayon
import Gérer_stock
import venteGUI
import Compte_rendu

