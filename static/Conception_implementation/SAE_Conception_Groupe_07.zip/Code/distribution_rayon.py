import Package.Outil_de_commande as ODC
import Package.package_sql as ps

# -------------------------------------------------------------------------------------------------------------------------------------
#                                                               DISTRIBUTION AUTOMATIQUE DES PRODUITS DANS LE RAYON
# Dans ce programme, nous allons faire la répartition automatique des différents produits en mettant la moitié en rayon arrondi à l'inférieur si nombre impair. 
# -------------------------------------------------------------------------------------------------------------------------------------
 
# Récupération de tous les noms des produits et le nombre d'exemplaire dans le stock dans la table Produits
result = ps.sqliterequest("Base_données/base.db","SELECT P.Nom,S.Stock FROM Produits AS P INNER JOIN Stock AS S ON S.EAN=P.EAN;", ())
#print(result[0:10])

# Un fichier log retraçant les différents actions fait pour cette distribution
ODC.file = ODC.fich_log_gest_vent("G")

# Ici, on fait la distribution automatique des exemplaires dans le rayon 
for elt in result:
    if elt[1]//2 !=0:
        ODC.echange_exemplaire_produit(elt[0], elt[1]//2, rayon_stock="S")


#result = ps.sqliterequest("Base_données/base.db","SELECT P.Nom,R.Rayon FROM Produits AS P INNER JOIN Rayon AS R ON R.EAN=P.EAN;", ())
#print(result[0:10])

#result = ps.sqliterequest("Base_données/base.db", "SELECT Nom, EAN FROM Produits WHERE Nom='SQL Server MVP Deep Dives';",())
#print(result)