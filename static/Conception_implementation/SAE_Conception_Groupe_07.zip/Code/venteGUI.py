import sys
from PyQt5.QtWidgets import QMainWindow, QWidget, QGridLayout, QLabel, QLineEdit, QPushButton, QScrollArea, QFrame, QApplication, QMessageBox
import Package.Outil_de_commande as OCD
import regex as r
import Package.package as p
import Package.package_sql as ps
from datetime import datetime
from time import strftime

# -------------------------------------------------------------------------------------------------------------------------------------
# Ce programme permet de faire les ventes des produits et la création d'un ticket.
# De plus, cela enregistre les ventes dans une base de données et mets à jour la quantité disponible du produit mis en place
# Un fichier log retrace les différentes actions faites par l'utilisateur.  
# -------------------------------------------------------------------------------------------------------------------------------------

# -------------------------------------------------------------------------------------------------------------------------------------
# ------------------------------------------------------- VENTE INTERACTIF ---------------------------------------------------------
# -------------------------------------------------------------------------------------------------------------------------------------

print("\nCOMMENCEMENT DE LA VENTE AUX TICKET")

OCD.file = OCD.fich_log_gest_vent()

class VenteGUI(QMainWindow):
    def __init__(self, parent=None):
        super(VenteGUI, self).__init__(parent)
        self.setWindowTitle("Vente GUI")
        # INFO
        self.info = QLabel()
        self.info.setText("Ventes de produits")
        # ZONE DE SAISIE
        self.entryfield = QLineEdit()
        self.valid = QPushButton("Valid")
        self.valid.clicked.connect(self.validation_article)
        self.valid.setShortcut('Return')
        self.validticket = QPushButton("END")
        self.validticket.clicked.connect(self.validation_ticket)
        # LOG de SAISIE
        self.scrollA = QScrollArea()
        self.scrollA.setWidgetResizable(True)
        self.scrollA.setFrameShape(QFrame.NoFrame)
        self.ticket = QLabel()
        self.scrollA.setWidget(self.ticket)
        self.ticket.setWordWrap(True)
        self.ticket.setText("Ticket \nProduit Quantité Prix unitaire (€) Prix total (€)")
        # LAYOUT
        layout = QGridLayout()
        layout.addWidget(self.info, 0, 0)
        layout.addWidget(self.entryfield,1, 0)
        layout.addWidget(self.valid,1, 1)
        layout.addWidget(self.validticket,1, 2)
        layout.addWidget(self.scrollA,2, 0, 4, 3)
        wid = QWidget(self)
        self.setCentralWidget(wid)
        wid.setLayout(layout)
        self.resize(1000, 500)

        # CRÉATION DE DEUX VARIABLES CONTENANT LA LISTE DES PRODUITS VENDUS POUR UN TICKET ET LA SOMME TOTAL DU TICKET
        self.liste_nom = []
        self.somme_total = 0
        # ______________________________________________________________
        # éventuelles variables
        # ______________________________________________________________
    

    def validation_article(self):
        # ______________________________________________________________
        # TODO
#----------------------------------------------------------------------------------------------------------------------------
#------------------------------------ Enregistrement d'un article -----------------------------------------------------------
#----------------------------------------------------------------------------------------------------------------------------

        msgbox_produit = QMessageBox()
        nom = self.entryfield.text().replace("'", " ")
        nom = nom.replace('"', ' ')
        print(nom)
        result=OCD.recherche_prod(nom, ray_sto="R",show=False)

        ## Vérification si le produit existe
        if result==[]:
             msgbox_produit.setWindowTitle('Attention erreur dans la saisie')
             msgbox_produit.setText("Attention, ce nom de produit n'existe pas")
             msgbox_produit.exec()
             print("Erreur de saisie")
            
        ## Vérification si le produit a toujours des exemplaires dans le rayon
        elif result[3]>0:
                    ## Mise à jour de la table Rayon dans base.db
                     verf=OCD.ret_aj_def(nom, nb=1, ray_sto="R", aj_ret="RETIRER")
                     
                     ## Vérification si pas de problème d'enlèvement
                     if verf!="annulation":
                        #print(self.liste_nom)
                        
#------------------------- Création et ajout de la ligne du ticket avec les différentes informations -------------------------
                        ## La non présence du nom dans la liste
                        if not("'"+nom+"'" in self.liste_nom):
                            ## Copie de la chaîne
                            chaine = str("'"+nom+"'")

                            ## Ajoute dans liste_nom
                            self.liste_nom.append(chaine)

                            ## Création et ajout de la ligne concernant le produit dans le ticket
                            ticket_temp = self.ticket.text() +"\n" +"'"+nom+"' 1 " + str(result[4])+ " "+str(result[4])
                            self.ticket.setText(ticket_temp)
                            self.somme_total+=result[4]
#----------------------------------------------------------------------------------------------------------------------------

#---------------------- Ajout plus un dans la quantité du produit acheté ----------------------------------------------------
                        else:
                            ## On sépare les différentes lignes
                            elt = self.ticket.text().split("\n")

                            for ind in range(len(elt)):                         
                                #print("chaine : "+ elt[ind])
                                #print(elt[ind])

                                ## Utilisation du regex pour détecter le nom du produit à l'aide des '' présents
                                result = r.search("'[\D\d]*'",elt[ind])
                                #print(result)

                                ## Dans le cas où ce n'est pas vide
                                if result!=None :

                                    ## Récupération des indices du résultat pour avoir le nom du produit
                                    index =result.span()
                                    
                                    ## Vérification du nom du produit concerné
                                    if elt[ind][index[0]:index[1]]=="'"+nom+"'":
                                            
                                            ## On sépare les différents éléments séparés par un espace
                                            liste_info=elt[ind][index[1]+1:].split(" ")
                                            #print(liste_info)

                                            ## Vérification de la présence du nom du produit dans liste_nom
                                            if elt[ind][index[0]:index[1]] in self.liste_nom:     

                                                ## Rajout +1 de la quantité de l'article
                                                liste_info[0]= int(liste_info[0])+1

                                                ## Rajout +Prix_unitaire dans le prix total
                                                liste_info[2] = round(float(liste_info[2])+float(liste_info[1]), 2)

                                                ## Réunion des différentes informations modifiés
                                                nouv_chaine = elt[ind][index[0]:index[1]] + " " + str(liste_info[0]) + " "+ str(liste_info[1]) + " "+str(liste_info[2])

                                                elt[ind]=nouv_chaine
                                                #print("nouvelle chaine :"+nouv_chaine)

                                            ## Modification du ticket en mettant les différentes élémentes plus celle modifiés
                                            nouv_ticket = ""
                                            for chaine in elt:
                                                nouv_ticket+=chaine + "\n"

                                            ## Suppresion du dernier saut de ligne tout à droite
                                            nouv_ticket = nouv_ticket.rstrip("\n")
                                            
                                            ## Modification du ticket
                                            self.ticket.setText(nouv_ticket)

                                            ## Rajout de la somme
                                            self.somme_total+=float(liste_info[1])
#-------------------------------------------------------------------------------------------------------------

                     else:
                          print("attention, erreur dans le nombre de produits vendus supérieurs au nombre de produits restants dans RAYON")
                     
        ## Préviens l'utilisateur si plus d'article dans le rayon
        else:
             msgbox_produit.setWindowTitle('Attention, plus de produit')
             msgbox_produit.setText("Attention, plus de produit dans rayon")
             msgbox_produit.exec()
             print("Erreur de produit, il y en a plus en rayon")
#-----------------------------------------------------------------------------------------------------------

        # ______________________________________________________________
    
    def validation_ticket(self):
        # ______________________________________________________________
        # TODO
#------------------------------------ Enregistrement du ticket -------------------------------------------------


        # ---- Partie Initialisation ----
        req_insert = "INSERT INTO Ventes(Produits, Quantite, Prix_unitaire, Prix_total, date_achat, heure_minute_seconde) VALUES (?,?,?,?,?,?);"
        liste_prod = self.ticket.text().split("\n")
        date = datetime.now()
        date_ymd_hms= date.strftime("%d-%m-%Y %H heures %M minutes %S secondes")
        date_ymd = date.strftime("%d-%m-%Y")
        date_hms = date.strftime("%H : %M : %S")
        #--------------------------------

        # ---- Partie Enregistrement dans la base de données analyse.db ----
        for ind in range(len(liste_prod)):
             result = r.search("'[\D\d]*'",liste_prod[ind])
             if result!=None:
                index =result.span()
                liste_info=liste_prod[ind][index[1]+1:].split(" ")
                ps.sqliteinsertdata("Base_données/analyse.db",req_insert,(liste_prod[ind][index[0]+1:index[1]-1], liste_info[0], liste_info[1], liste_info[2], date_ymd, date_hms))

             #print(liste_prod)
        #-------------------------------------------------------------------

        # ---- Partie Imprimation d'un ticket de caisse ----
        msgbox_valid = QMessageBox()
        
        ## Rajout du montant total à payer et la date avec le ticket
        msgbox_valid.setText(self.ticket.text()+"\n"+"Total à payer (€) : "+str(round(self.somme_total, 2))+"\n"+date_ymd_hms)

        ## Écriture du ticket de caisse
        p.writeStrtoTXT("Ticket_caisse/"+date_ymd_hms+".txt", msgbox_valid.text())
        
        ## Rénitialisation pour faire le prochain ticket
        msgbox_valid.setWindowTitle('Ticket de caisse')
        self.entryfield.setText("")
        self.ticket.setText("Ticket \n Produit Quantité Prix unitaire (€) Prix total (€)")
        self.entryfield.setText("")
        self.liste_nom = []
        self.somme_total = 0

        ## Envoie d'un message sur le résumé de la vente des produits
        msgbox_valid.exec()

        #----------------------------------------------------
        # ______________________________________________________________
#-----------------------------------------------------------------------------------------------------------

# ---- Lancement de l'application ----
app = QApplication.instance() 
if not app:
        app = QApplication(sys.argv)
fen = VenteGUI()
fen.show()
app.exec_()
#-------------------------------------

print("FIN DE LA VENTE AUX TICKET")