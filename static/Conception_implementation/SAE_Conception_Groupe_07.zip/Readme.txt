LES DIFFÉRENTS PROGRAMMES À LANCER :

POUR LA CRÉATION, L'INSERTION DES DONNÉES :

Veuillez lire le fichier Readme_Base.py

POUR LA DISTRIBUTION, L'OUTIL DE COMMANDE, L'INTERFACE DE VENTE AU TICKET :

Veuiller lire le fichier Readme_Interface.py