####################################-
# SAE Analyse de données, reporting et datavisualisation
# Auteurs : Renoult Julien, Pons-Fournier Amaury, 
# Vivet Éloise, Serrand Éloise
# Date : 05/05/2023 - 09/05/2023
# Données : Horodateurs Mobiliers et Horodateurs Transactions de Paiement 2014
# Source : https://opendata.paris.fr/explore/dataset/horodateurs-transactions-de-paiement/information/
# et https://opendata.paris.fr/explore/dataset/horodateurs-mobiliers/information/?disjunctive.arrondt&disjunctive.regime&disjunctive.acces_pmr&disjunctive.tarif&disjunctive.zoneres&disjunctive.paiement
####################################-


###################################-

# ---- Importation des données ----

## Prise de connaissance de la structure des deux fichiers avant importation

readLines(con = "../Data/horodateurs-mobiliers.csv", n=10)

readLines(con = "../Data/horodateurs-transactions-de-paiement.csv", n = 10)

## Importation

read.table(file = "../Data/horodateurs-transactions-de-paiement.csv",
           sep = ";", encoding = "UTF-8", header = TRUE, dec = ",") -> dataset2

## Contrôle de la structure du fichier

str(dataset2)

read.table(file = "../Data/horodateurs-mobiliers.csv", sep = ";",
           encoding = "UTF-8", quote = "\"", header = TRUE) -> dataset1

## Contrôle de la structure du fichier

str(dataset1)

## Contrôle de l'importation du fichier

head(dataset2, n=10)

head(dataset1, n=10)

###################################-

# ---- Préparation des données ----

# Création de data1 :

## Sélection des variables d'intérêts :

subset(x = dataset1, select = c("N..d.horodateur","Alimentation", "Modèle", "Arrondissement", "Tarif.horaire"))-> data1

## Vérification du succès de l'opération :

str(data1)

head(data1, n=10)

## Modification du type/nom des variables :

colnames(data1)[1]= "Horodateur"

within(data = data1,
       {
         
         Alimentation = factor(Alimentation, levels = c("PILE", "SOLAIRE"));
         
         Modèle = factor(Modèle);
         
         Arrondissement = factor(Arrondissement)
       }) -> data1

str(data1)

summary(data1)

# Création data2 :

## Sélection des variables d'intérêts :

subset(x = dataset2, select = -c(date.horodateur, durée.payée..h.)) -> data2

## Vérification du succès de l'opération :

str(data2)

head(data2, n = 10)

## Modification du type/nom des variables :

colnames(data2) = c("Horodateur", "Usager", "Paiement", "Montant", "Début", "Fin")

str(data2)
data2$Fin = ifelse(nchar(data2$Fin)<19, paste0(data2$Fin,":00"), data2$Fin)

within(data = data2,
       {
         Usager = factor(Usager);
         
         Paiement = factor(Paiement);
         
         Début = as.POSIXct(Début, 
                            format = "%d/%m/%Y %H:%M:%S");
         
         Fin = as.POSIXct(Fin,format = "%d/%m/%Y %H:%M:%S")
         }) -> data2

## Vérification du succès de l'opération :

str(data2)

summary(data2)

# Création de la variable Durée : 

## Partie opération entre la fin et le début à l'aide de la fonction difftime :

data2$Durée = round(difftime(data2$Fin, data2$Début,
                       units = "mins"), 2)

## Conversion en numérique :

data2$Durée = as.numeric(data2$Durée)

## Vérification du succès de l'opération :

head(data2, n = 10)

str(data2)

summary(data2)


## Ordonner les id :

data1[order(data1$Horodateur),] -> data1

data2[order(data2$Horodateur),] -> data2

## Jointure à gauche des données :

merge(x = data2, y = data1, by = "Horodateur", all.x = TRUE) -> data

## Vérification du succès de l'opération :

head(data, n = 10)

str(data)

summary(data)

## Changer l'ordre des variables :

data = data[, c(1, 2, 5, 6, 3, 7, 4, 8, 9, 10, 11)]

## Vérification du succès de l'opération :

head(data, n = 10)

str(data)

summary(data)

# Filtrage Arrondissement :

## Partie filtrage :

subset(x = data, subset = !is.na(Arrondissement)) -> data

## Vérification du succès de l'opération :

head(data, n = 10)

str(data)

summary(data)

# Filtrage Durée nulle, négatif ou pas renseigné:

## Partie filtrage :

subset(x = data, subset = Durée>0 & !is.na(Durée)) -> data

## Vérification du succès de l'opération :

head(data, n = 10)

summary(data)

# Filtrage début de stationnement en 2014 :

## Partie filtrage :

data[(data$Début>="2014-01-01" & 
               data$Début<="2014-12-31"),] -> data

## Vérification du succès de l'opération :

head(data, n = 10)

summary(data)

saveRDS(data, file = "Horodateurs-Paris.rds")
