####################################-
# SAE Analyse de données, reporting et datavisualisation
# Auteurs : Renoult Julien, Pons-Fournier Amaury, 
# Vivet Éloise, Serrand Éloise
# Date : 09/05/2023 - 19/05/2023
# Données : Horodateurs Mobiliers et Horodateurs Transactions de Paiement 2014
# Source : https://opendata.paris.fr/explore/dataset/horodateurs-transactions-de-paiement/information/
# et https://opendata.paris.fr/explore/dataset/horodateurs-mobiliers/information/?disjunctive.arrondt&disjunctive.regime&disjunctive.acces_pmr&disjunctive.tarif&disjunctive.zoneres&disjunctive.paiement
####################################-


####################################-

# ---- Chargement des librairies ----

library(vcd)
library(BioStatR)
library(RColorBrewer)

####################################-

# ---- Analyse exploratoire des données ----

## 2) Importation des données traités :

readRDS("Horodateurs-Paris.rds") -> horodateurs

str(horodateurs)
#####################################-

# ---- Type de paiement  ----

# Transactions selon le type d'usager 

## Création de la table :

### Fréquence

table_type_usager = table(horodateurs$Usager)

print(table_type_usager)

### Conversion en pourcentage 

table_type_usager = round(100*prop.table(table(horodateurs$Usager)), 2)

print(table_type_usager)

## Représentation graphique : 

graphique_usager = barplot(table_type_usager,
                               col="green",
                               main = "Répartition des transactions selon le type d'usager",
                               xlab = "Type d'usager",
                               ylab = "Pourcentage",
                               ylim = c(0,85)
)

text(graphique_usager, table_type_usager+3,
     labels = paste0(table_type_usager, " %"))

mtext(text = "Source : Opendata Paris", side = 1, line = 4, adj = 1, cex =0.75)

mtext("BUT Science des données - Lisieux", side =1, line = 4, adj = 0.015, cex=0.75)

### Commentaire :
# - On peut observer que les usagers sont majoritairement des usagers rotatif avec 77.7 %
# contre 22.3 % pour les résidents

# 3) Transactions selon le type de paiement 

## Création de la table :

### Fréquence

table_type_paiement = table(horodateurs$Paiement)

print(table_type_paiement)

### Conversion en pourcentage 

table_type_paiement = round(100*prop.table(table(horodateurs$Paiement)), 2)

print(table_type_paiement)

## Représentation graphique : 

graphique_paiement_1 = barplot(table_type_paiement,
                               col="green",
                               main = "Répartition des transactions selon le type de paiement",
                               xlab = "Type de paiement",
                               ylab = "Pourcentage",
                               ylim = c(0,60)
                               )

text(graphique_paiement_1, table_type_paiement+2,
     labels = paste0(table_type_paiement, " %"))

mtext(text = "Source : Opendata Paris", side = 1, line = 4, adj = 1, cex =0.75)

mtext("BUT Science des données - Lisieux", side =1, line = 4, adj = 0.015, cex=0.75)


### Commentaire :
# - On peut observer que les usagers paient majoritairement par le Paris carte avec 53.91 %
# tandis que 46.09 % paient par carte bleu


# 4) Association entre le type de paiement et l'arrondissement :

## Création de la table :

### Création de la table de contingence

table_type_arrond = table(horodateurs[,5], horodateurs[,10])

print(table_type_arrond)

addmargins(table_type_arrond, FUN = sum, quiet = TRUE)

### Conversion en pourcentage 

rows = round(100*prop.table(table_type_arrond,2),2)

rows

addmargins(rows, 1 , FUN = sum)

## Représentation graphique :

graphique_paiement_2=barplot(height = rows,
               beside=FALSE,
               main="Type de paiement selon l'arrondissement",
               xlab="Arrondissement",
               ylab = "Pourcentage",
               las = 1,
               col = c("pink","lightblue"))

percent= apply(rows,2,function(x) c(x[1]/2,head(cumsum(x),-1)+tail(x,-1)/2))


text(x=rep(graphique_paiement_2,each =nrow(percent)),
     y=c(percent),
     srt =  90,
     labels=(c(paste0(rows,"%"))))

mtext("Source: Opendata Paris", side =1, line = 4, adj = 1, cex=0.75)

mtext("BUT Science des données - Lisieux", side =1, line = 4, adj = 0.015, cex=0.75)

### Commentaire :
# - On peut observer que pour chaque arrondissement, on a très peu de changement ce qui témoigne d'une association très faible à première vue
# - Nous allons calculer le V de cramer pour en savoir l'intensité

## Intensité de l'association entre le type de paiement et l'arrondissement :

assocstats(table_type_arrond)

### Commentaire :
# - Il y a 4.6 %  d'intensité pour la relation 
# entre le type de paiement et l'arrondissement ce qui témoigne d'une association très faible même quasi inexistante


# 5) Association entre le type de paiement et et l'usager :

## Création de la table :

### Création de la table de contingence

table_type_usag = table(horodateurs[,5], horodateurs[,2])

print(table_type_usag)

addmargins(table_type_usag, FUN = sum, quiet = TRUE)

### Conversion en pourcentage 

rows = round(100*prop.table(table_type_usag,2),2)

rows

addmargins(rows, 1 , FUN = sum)

## Représentation graphique :

graphique_paiement_3=barplot(height = rows,
               beside=FALSE,
               main="Type de paiement selon l'usager",
               xlab="Pourcentage",
               las = 3,
               legend.text = TRUE,
               horiz = TRUE,
               col = c("pink","lightblue"),
               args.legend=list(x = "top",
                                horiz = TRUE,
                                inset = c(0.3, -0.1),
                                bty = "n"))

percent= apply(rows,2,function(x) c(x[1]/2,head(cumsum(x),-1)+tail(x,-1)/2))


text(x=c(percent),
     y=rep(graphique_paiement_3,each =nrow(percent)),
     srt =  90,
     labels=(c(paste0(rows,"%"))))

mtext("Source: Opendata Paris", side =1, line = 4, adj = 1, cex=0.75)

mtext("BUT Science des données - Lisieux", side =1, line = 4, adj = 0.015, cex=0.75)

### Commentaire :
# - On peut observer qu'il a une certaine variation dans le type de paiement entre Rotatif et Résident
# - Il existe donc une association entre ces deux variables
# - Nous allons calculer l'intensité de cette association

## Intensité de l'association :

assocstats(table_type_usag)

### Commentaire :
# - L'intensité de cette association est de 10.1 % ce qui témoigne d'une association faible entre le type de paiement et le type d'usager

####################################-

# ---- Montant payé ----

# 6) Distribution du montant payé pour le stationnement :

summary(horodateurs$Montant)

### Commentaire :
# - Le montant moyen est de 2.54 €
# - La médiane est de 2.40 €

## Représentation graphique

### Construction de l'histogramme

graphique_montant_1 = hist(horodateurs$Montant,
                           probability = TRUE,
                           breaks = c(0,0.5,1,1.5,2,2.5,3,3.5,4,4.5,5,5.5,6,6.5,7,7.5,8),
                           main = "Distribution du montant payé pour le stationnement",
                           xlab = "Montant payé en euros",
                           ylab = "Densité",
                           ylim = c(0,0.45),
                           xaxt = "n")

### Ajout de l'axe X

axis(side = 1,
     at = c(0,2,4,6,8),
     labels = c(0,2,4,6,8))

mtext("Source: Opendata Paris", side =1, line = 4, adj = 1, cex=0.75)

mtext("BUT Science des données - Lisieux", side =1, line = 4, adj = 0.015, cex=0.75)

### Représentation du montant moyen sur le graphique
abline(v = mean(horodateurs$Montant),
       lty = 2,
       col = "green4",
       lwd = 2)


### Représentation de la médiane sur le graphique

abline(v = quantile(horodateurs$Montant,
                    probs = c(0.5)),
       lty =2,
       col = "red",
       lwd = 2)

### Ajout des effectifs sur le graphique

text(graphique_montant_1$mids,
     graphique_montant_1$density+0.010,
     labels=graphique_montant_1$counts)

### Ajout de la densité lissé

lines(density(horodateurs$Montant, bw=0.2), col = "blue", lwd = 2)

### Création de la légende 

legend(x = "topright",
       lty = c(2,2,1),
       lwd = c(1,1,1),
       col = c("red", "dark green", "blue"),
       legend = c("Médiane : 2.4 €", "Moyenne : 2.53 €", "Dénsité lissé"),
       bty = "n")

### Commentaire :
# - On peut observer que la majorité des montants payés se trouvent dans deux intervalles. 
# - Pour le premier, on a l'intervalle entre 2 et 2.5 € qui donne un effectif de 3 842 031
# - Pour le deuxième, on a l'intervalle entre 0.5 et 1 € qui donne un effectif de 3 823 486 
# - On peut observer ça grâce à l'histogramme mais aussi à la densité lissé car elle montre deux pics appartenant aux deux intervalles précédentes
# mais aussi pour l'intervalle entre 3 et 3.5 € avec 2 385 545 en effectif, l'intervalle entre 4.5 et 5 € avec 1 677 073 en effectif et
# l'intervalle entre 7 et 7.5 € pour 1 024 921 en effectif.

# 7) Distribution du montant payé par les rotatifs/résidents pour le stationnement : 

## Représentation graphique

### Préparation des données et de la mise en forme des deux graphiques

par(mfrow = c(2,1))

rotatif = subset(horodateurs,
                 subset = Usager == "Rotatif")
résident = subset(horodateurs,
                  subset = Usager == "Résident")

summary(rotatif$Montant)

summary(résident$Montant)

### Commentaire :
# - On observe que les rotatifs payent en moyenne 2.66 € pour le stationnement
# - On observe que les résidents payent en moyenne 2.14 € pour le stationnement
# - On remarque qu'en moyenne les résidents payent moins le stationnement que les rotatifs

### Création du graphique 


####- Graphique Montant payé pour les rotatifs

graphique_montant_2=hist(rotatif$Montant ,
            main = "Montant payé par les rotatifs pour le stationnement",
            xlab = "Montant payé en euros",
            breaks = 15,
            ylab = "Densité",
            las = 1,
            xlim = c(0,8),
            col = "lightblue",
            prob = TRUE,
            ylim = c(0,0.7))

text(x = graphique_montant_2$mids,
     y = graphique_montant_2$density+0.09,
     labels = paste0(round(100*prop.table(graphique_montant_2$counts),1),"%"))

#####- Graphique Montant payé pour les résidents 

graphique_montant_3 = hist(résident$Montant,
            main = "Montant payé par les résidents pour le stationnement",
            xlab = "Montant payé en euros",
            breaks = 15,
            ylab = "Densité",
            las = 1,
            xlim = c(0,8),
            col = "lightblue",
            prob = TRUE,
            ylim = c(0,3.5))


text(x = graphique_montant_3$mids,
     y = graphique_montant_3$density+0.4,
     labels = paste0(round(100*prop.table(graphique_montant_3$counts),1),"%"))

mtext("Source: Opendata Paris", side =1, line = 4, adj = 1, cex=0.75)

mtext("BUT Science des données - Lisieux", side =1, line = 4, adj = 0.015, cex=0.75)

par(mfrow = c(1,1))

### Commentaire :
# - Pour le premier histogramme, on peut observer que le montant payé est majoritairement entre 2 et 2.5 € pour les usagers rotatifs pour 25.7 % d'entre eux
# - Pour le deuxième histogramme, on observer une grande différence avec le premier car ici, pour les résidents, on a un montant
# payé pour plus de 3 € pour la majorité des résidents avec 54.9 %.
# - Cela montre qu'il existe peut-être une association entre le montant payé et le type d'usager

## Mesure de l'intensité de cette association

### Somme des carrés

with(horodateurs,aov(Montant ~ Usager)) -> anova

summary(anova)

### Commentaire :

SCintra = 58338925
SCinter = 922828
SCtotal = SCintra + SCinter


### Rapport de corrélation entre Montant et Arrondissement

rap_cor = SCinter / SCtotal

rap_cor = rap_cor *100

rap_cor

### Commentaire :
# - Le rapport de corrélation donne une intensité de 1.56 % 
# ce qui témoigne d'une association très faible entre le montant payé et le type d'usager

# 8) Montant payé selon l'arrondissement :

## Moyenne des montants payés par arrondissement

with(horodateurs, tapply(X = Montant, INDEX = Arrondissement, mean))

## Représentation graphique 

### La représentation du Montant payé selon l'arrondissement :

with(horodateurs, boxplot(Montant ~ Arrondissement,
                       col = "Yellow",
                       main = "Montant payé selon l'arrondissement",
                       xlab = "Arrondissement",
                       ylab = "Montant payé en euros"))

### L'ajout de la moyenne sur le graphique :

moyenne_par_arrondi = with(horodateurs,aggregate(Montant,
                                                  list(Arrondissement),
                                                  mean))
points(x = 1:nrow(moyenne_par_arrondi),
       y = moyenne_par_arrondi$x,
       col = "red",
       pch = 16,
       cex = 1)

mtext("Source: Opendata Paris", side =1, line = 4, adj = 1, cex=0.75)

mtext("BUT Science des données - Lisieux", side =1, line = 4, adj = 0.015, cex=0.75)

### Commentaire :
# - On peut observer que pour chaque arrondissement, on a une distribution différente du montant payé
# - On peut remarquer que les arrondissements de 12 à 20 sont moins chers que les autres Arrondissements
# - Les arrondissements de 1 à 3 ont une ditribution large des montants entre 2 et 7 € avec la même valeur pour la médiane
# - On peut donc dire qu'il existe une association entre le montant payé et l'arrondissement

## Mesure de l'intensité de cette association

### Somme des carrés

with(horodateurs,aov(Montant ~ Arrondissement)) -> anova

summary(anova)

### Commentaire :
SCintra = 50051325
SCinter = 9210427

SCtotal = SCintra+SCinter

### Rapport de corrélation entre Montant et Arrondissement

rap_cor = SCinter/SCtotal

rap_cor = rap_cor * 100

rap_cor

### Commentaire :
# - Le rapport de corrélation donne une intensité de 15.54 % 
# ce qui témoigne d'une association très faible entre le montant payé et l'arrondissement

####################################-
# ---- Montant total / Transactions ----

## 9) Montant total rapporté selon le type d'usager :

## Calcul du montant total pour les résidents et les rotatifs :

## fonction somme des modalités :


sum(résident$Montant)/1000000 -> montant_total_résident

sum(rotatif$Montant)/1000000 -> montant_total_rotatif

somme_total_type_usager = data.frame(type_usagers = c("Résident","Rotatif"),
                         montant_total = c(montant_total_résident,montant_total_rotatif))

## Représentation graphique :

graphique_montant_total_1 = barplot(somme_total_type_usager$montant_total,
                                    names.arg = somme_total_type_usager$type_usagers,
                                    col = "green4",
                                    main = "Montant total en millions rapporté selon le type d'usager",
                                    ylab = "Montant en millions d'euros",
                                    ylim = c(0,45))

text(graphique_montant_total_1, (somme_total_type_usager$montant_total)+2,
     labels = paste0(round(somme_total_type_usager$montant_total,2), " millions"))

mtext("Source: Opendata Paris", side =1, line = 4, adj = 1, cex=0.75)

mtext("BUT Science des données - Lisieux", side =1, line = 4, adj = 0.015, cex=0.75)

## Commentaire :
# - Les usagers rotatifs rapportent davantage avec 39.52 millions d'euros que 9.09 millions d'euros pour les résidents



# 10) Nombre de transactions en millers par arrondissement 

## Création de la table 

table_arrond = table(horodateurs$Arrondissement)/1000

## Représentation graphique
graphique_nb_trans_total = with(horodateurs, barplot(height = table_arrond,
                          col = "blue",
                          main = "Nombre de transactions en milliers par arrondissement",
                          xlab = "Arrondissement",
                          ylab = "Nombre de transactions (en milliers)",
                          ylim = c(0,2250)),
                          )

text(graphique_nb_trans_total, table_arrond+50,
     labels = round(table_arrond,0))

mtext("Source: Opendata Paris", side =1, line = 4, adj = 1, cex=0.75)

mtext("BUT Science des données - Lisieux", side =1, line = 4, adj = 0.015, cex=0.75)

### Commentaire :
# - On peut observer que l'arrondissement contient le plus de transactions est l'arrondissement 16 avec 2 820 000 suivi de près
# par l'arrondissement 15 avec 2 050 000 de transactions

# 11) Montant total rapporté par arrondissement

## Calcul du montant total par arrondissement 

som_arrondissement = with(horodateurs, aggregate(Montant,
                            list(Arrondissement),
                            sum)) 

### Conversion en millions 

som_arrondissement$x = round(som_arrondissement$x / 1000000, 2)

## Représentation graphique

graphique_montant_total_2 = with(som_arrondissement, barplot(x,
                                    names.arg = Group.1,
                                    col = "pink",
                                    main = "Montant total en millions rapporté par arrondissement",
                                    ylab = "Montant en millions d'euros",
                                    xlab = "Arrondissement",
                                    ylim = c(0, 5.5)))

with(som_arrondissement, text(graphique_montant_total_2, x+0.2,
     labels = x))

mtext("Source: Opendata Paris", side =1, line = 4, adj = 1, cex=0.75)

mtext("BUT Science des données - Lisieux", side =1, line = 4, adj = 0.015, cex=0.75)

### Commentaire :
# - L'arrondissement 8 rapporte le plus gros montant parmi tous les autres arrondissements avec 4.89 millions d'euros
# - Les arrondissements qui rapportent plus de 4 millions d'euros sont les arrondissements 7, 8, 16, 17

# 12) Le type d'alimentation des horodateurs par arrondissement

## Création de la table de contingence

table_type_arrond = table(c(horodateurs[8],horodateurs[10]))

print(table_type_arrond)

addmargins(table_type_arrond, FUN = sum, quiet = TRUE)

table_type_arrond/1000 -> table_type_arrond

## Représentation graphique :

graphique_PILE_SOLAIRE=barplot(height = table_type_arrond,
                               beside=TRUE,
                               main="Horodateurs selon le type d'alimentation par arrondissement",
                               xlab="Arrondissement",
                               ylab = "Effectif (en millier)",
                               las = 1,
                               col = c("pink","lightblue"),
                               ylim = c(0,2000),
                               legend.text = TRUE,
                               args.legend = list(x = "topleft",
                                                  horiz = TRUE,
                                                  inset = c(0,0.01),
                                                  bty = "n"))




mtext("Source: Opendata Paris", side =1, line = 4, adj = 1, cex=0.75)

mtext("BUT Science des données - Lisieux", side =1, line = 4, adj = 0.015, cex=0.75)

## Commentaire :
# - On peut observer qu'il existe une association entre le type d'alimentation et l'arrondissement  car on a pour chaque arrondissement
# une distribution différente entre les deux types d'alimentations

## Intensité de l'association entre le type de paiement et l'arrondissement :

assocstats(table_type_arrond)

## Commentaire :
# - On peut observer que l'intensité de cette association est de 72.8 % 
# ce qui témoigne d'une association très forte entre le type d'alimentation des horodateurs et l'arrondissement de Paris

####################################-

# ---- Moyenne du prix horaire / nombre de transactions ----

# 13) Prix horaire moyen par arrondissement 

## Calcul de la moyenne du tarif horaire par arrondissement 

moy_arrond = with(horodateurs, aggregate(Tarif.horaire,
                                         list(Arrondissement),
                                         mean))
## Représentation graphique 

graphique_prix = with(moy_arrond, barplot(x,
                         names.arg = Group.1,
                         col = "green",
                         ylim = c(0,5),
                         main = "Prix horaire moyen par arrondissement",
                         xlab = "Arrondissement",
                         ylab = "Prix moyen en euro"))

with(moy_arrond, text(graphique_prix, x+0.2,
                              labels = paste0(x, "€")))

mtext("Source: Opendata Paris", side =1, line = 4, adj = 1, cex=0.75)

mtext("BUT Science des données - Lisieux", side =1, line = 4, adj = 0.015, cex=0.75)

### Commentaire :
# - Le prix horaire moyen pour les arrondissement 1 à 11 est de 4 € et de 12 à 20 est de 2.4 €

# 14) Nombre moyen de transactions par horodateur selon les arrondissements

## Fonction somme par arrondissement du nombre moyen de transactions par horodateur

moy_par_arrond = function(arrond){
  subset(horodateurs, subset = Arrondissement == arrond, select = c("Horodateur")) -> data_func
  
  data_func$Horodateur = factor(data_func$Horodateur)
  
  table_horo = table(data_func$Horodateur)/nlevels(data_func$Horodateur)
  
  sum(table_horo) -> arrond
  
  return(arrond)
}

## Calcul de la somme de chaque arrondissement du nombre moyen de transactions :

lapply(X = levels(horodateurs$Arrondissement),
       FUN = moy_par_arrond) -> liste_valeurs_moyenne

## Création du dataframe pour y contenir les valeurs :

data.frame(Arrondissement = levels(horodateurs$Arrondissement),
           montant_total = unlist(liste_valeurs_moyenne)) -> moy_arrond_par_horodateurs

### Commentaire :
# - Utilisation de unlist pour tourner une liste en un vecteur

## Représentation graphique

graphique_montant_moyen = with(moy_arrond_par_horodateurs,barplot(montant_total,
        names.arg = Arrondissement,
                          col = "blue",
                          main = "Nombre moyen de transactions par horodateur selon les arrondissements",
                          xlab = "Arrondissement",
                          ylab = "Nombre moyen de transactions",
                          ylim = c(0,4500)))

with(moy_arrond_par_horodateurs, text(graphique_montant_moyen, montant_total+100,
                              labels = round(montant_total,0)))

mtext("Source: Opendata Paris", side =1, line = 4, adj = 1, cex=0.75)

mtext("BUT Science des données - Lisieux", side =1, line = 4, adj = 0.015, cex=0.75)

### Commentaire :
# - Celui qui a le plus grand nombre moyen de transactions par horodateur selon les arrondissements est l'arrondissement 13
# avec 4185 en moyenne

# 15) Montant total rapporté par le meilleur horodateur

meilleur_sum_horodateur_arrond = function(arrond){
  
  subset(x = horodateurs, subset = Arrondissement == arrond) -> data
  
  with(data, split(Montant, Horodateur)) -> liste_par_horodateurs
  
  sapply(liste_par_horodateurs, sum) -> sum_par_horodateurs
  
  which.max(sum_par_horodateurs) -> n
  
  return(sum_par_horodateurs[n])
}

meilleur_sum_horodateur_arrond("1") -> arrond_1

lapply(X = levels(horodateurs$Arrondissement),
       FUN = meilleur_sum_horodateur_arrond) -> liste_meilleur_horodateurs

data.frame(Arrondissement = levels(horodateurs$Arrondissement),
           montant_total = unlist(liste_meilleur_horodateurs)) -> meilleur_horodateurs

## Représentation graphique

graphique_meilleur_horodateur = with(meilleur_horodateurs,barplot(montant_total/1000,
                                        names.arg = Arrondissement,
                                        col = "blue",
                                        main = "Montant total rapporté par le meilleur horodateur selon l'arrondissement",
                                        xlab = "Arrondissement",
                                        ylab = "Montant en euros",
                                        ylim = c(0,120)))

with(meilleur_horodateurs, text(graphique_meilleur_horodateur, (montant_total/1000)+2,
                                      labels = round(montant_total,0)))

mtext("Source: Opendata Paris", side =1, line = 4, adj = 1, cex=0.75)

mtext("BUT Science des données - Lisieux", side =1, line = 4, adj = 0.015, cex=0.75)

####################################-

# ---- Durée de stationnement ----

# 16) Distribution de la durée du stationnement

## Conversion des minutes en heures

horodateurs$Durée/60 -> horodateurs$Durée_heure

summary(horodateurs$Durée_heure)

### Commentaire :
# - On a une moyenne de durée de stationnement de 26 heures contre une médiane de 2 heure
# - Il y a une durée de stationnement de 912 heures parmi les usagers

## Création de la classe de durée de stationnement 

horodateurs$classe_duree= cut(x = horodateurs$Durée_heure, breaks = c(0,1,2,4,8,24,48,912),
                              labels = c("1h et moins", "Entre 1h et 2h", "Entre 2h et 4h", 
                                         "Entre 4h et 8h", "Entre 8h et 24h", "Entre 24h et 48h",
                                         "Plus de 48h"))

## Vérification du succès de l'opération 

head(horodateurs, n=10)

str(horodateurs)

## Création de la table 

table16=table(horodateurs$classe_duree)
table16

rows1 = round(100*prop.table(table16),2)
rows1

## Distribution de la durée de stationnement

graph16=barplot(rows1,
                main="Distribution de la durée de stationnement ",
                xlab="Durée de stationnement",
                ylab = "Pourcentage",
                col = "orange",
                ylim=c(0,50))

text(graph16,
     rows1+2,
     labels=paste0(rows1,"%"))

mtext("Source: Opendata Paris", side =1, line = 4, adj = 1, cex=0.75)

mtext("BUT Science des données - Lisieux", side =1, line = 4, adj = 0.015, cex=0.75)

# 17) Durée de stationnement en jours selon le type d'usagers

## Conversions des durée en heures en jour

horodateurs$Durée_jours = horodateurs$Durée_heure/24

summary(horodateurs$Durée_jours)

### Commentaire :
# - On a une moyenne de durée de stationnement de 1 journée
# - Il y a une durée de stationnement de 38 jours parmi les usagers

## Selon le type d'usager

### En heures 

with(horodateurs, tapply(X = Durée_heure, INDEX = Usager, mean))

### En jours

with(horodateurs, tapply(Durée_jours, INDEX = Usager, mean))

### Commentaire :
# - On a pour les résidents usagers une durée de stationnement moyen de 108 heures soit de 4.5 jours pour la durée de stationnement
# - On a pour les usagers rotatifs, on a une durée de stationnement moyen de 2.9 heures

## Création graphique

with(horodateurs,
     boxplot(Durée_jours ~ Usager,
             col ="lightblue",
             main = "Durée de stationnement en jours selon le type d'usager",
             xlab = "Usager",
             ylab = "Durée en jours"))

mtext("Source: Opendata Paris", side =1, line = 4, adj = 1, cex=0.75)

mtext("BUT Science des données - Lisieux", side =1, line = 4, adj = 0.015, cex=0.75)

### Commentaire:
# - Sur ces boxplots, on peut voir que le stationnement est beaucoup plus long pour les résidents que les rotatifs qui font souvent moins d'une journée
# - Il existe donc une association entre le type d'usager et la durée de stationnement
# - Il y a 50% des parisiens qui se stationne au moins pendant 5 jours.

## Mesure de l'intensité de cette association

### Somme des carrés

with(horodateurs,aov(Durée_jours ~ Usager)) -> anova

summary(anova)

### Commentaire :
SCintra = 64366964
SCinter = 51781673

SCtotal = SCintra + SCinter
SCtotal

### Rapport de corrélation entre Usager et Durée

rap_cor = SCinter / SCtotal

rap_cor = rap_cor * 100

rap_cor

### Commentaire :
# - Le rapport de corrélation donne une intensité de 44.58 % 
# ce qui témoigne d'une association modérée entre la durée de stationnement et le type d'usager

# 18) Ditribution de la durée de stationnement selon les arrondissements

## Création de la table :

### Création de la table de contingence

duree_arrondissement=table(horodateurs$classe_duree, horodateurs$Arrondissement)

print(duree_arrondissement)

addmargins(duree_arrondissement, FUN = sum, quiet = TRUE)

### Conversion en pourcentage 

rows4 = round(100*prop.table(duree_arrondissement,2),2)

## Création du graphique
graphique_durree_arrondissement=barplot(height = rows4,
                                        beside=FALSE,
                                        main="Distribution de la durée de stationnement selon les arrondissements",
                                        cex.main = 1,
                                        ylab = "Pourcentage",
                                        las = 1,
                                        col = c("red","orange","yellow","green","brown","purple","blue"),
                                        legend.text = TRUE,
                                        args.legend = list(x = 26,
                                                           y = -9,
                                                           horiz = TRUE,
                                                           bty = "n",
                                                           cex = 1,
                                                           text.width = c(2,2.2,2,2,2,2,2)))
                                        

mtext("BUT Science des données - Lisieux", side =1, line = 4, adj = 0.015, cex=0.75)

mtext("Source: Opendata Paris", side =1, line = 4, adj = 1, cex=0.75)

### Commentaire :
# - On peut observer que chaque arrondissement a un peu près la même distribution de la durée de stationnement

## L'intensité de l'association

assocstats(duree_arrondissement)

### Commentaire :
# - On peut observer une association très faible de 4.2 % entre l'arrondissement et la durée de stationnement

# 19) Le montant des prix selon l'arrondissement qui a le plus rapporté / le moins rapporté en terme de montant total

# Les differents prix selon l'arrondissement qui a le plus et le moins rapporté

arrondissement8 = subset(horodateurs,
                         subset = Arrondissement == 8)

arrondissement2 = subset(horodateurs,
                         subset = Arrondissement == 2)

## La moyenne des montants payés

summary(arrondissement8$Montant)

summary(arrondissement2$Montant)

## Représentation graphique

par(mfrow = c(2,1))

graphique_montant_arround8=hist(arrondissement8$Montant ,
                                main = "Montant payé par l'arrondissement 8 (celui qui a rapporté le plus)",
                                xlab = "Montant payé en euros",
                                ylab = "Densité",
                                las = 1,
                                breaks =  15,
                                col = "lightblue",
                                prob = TRUE,
                                xlim = c(0,9),
                                ylim = c(0,0.4))

text(x = graphique_montant_arround8$mids,
     y = graphique_montant_arround8$density+0.04,
     labels = paste0(round(100*prop.table(graphique_montant_arround8$counts),1),"%"))


graphique_montant_arround2=hist(arrondissement2$Montant ,
                                main = "Montant payé par l'arrondissement 2 (celui qui a rapporté le moins)",
                                xlab = "Montant payé en euros",
                                ylab = "Densité",
                                las = 1,
                                col = "lightblue",
                                prob = TRUE,
                                xlim = c(0,9),
                                ylim = c(0,0.8))

text(x = graphique_montant_arround2$mids,
     y = graphique_montant_arround2$density+0.07,
     labels = paste0(round(100*prop.table(graphique_montant_arround2$counts),1),"%"))

mtext("BUT Science des données - Lisieux", side =1, line = 4, adj = 0.015, cex=0.75)

mtext("Source: Opendata Paris", side =1, line = 4, adj = 1, cex=0.75)


par(mfrow = c(1,1))

### Commentaire :
# - On peut observer que pour les montants payés en arrondissement 8 sont beaucoup plus réparties 
# avec un montant entre 0 et 2 euros pour 31.3 % des usagers, entre 2 et 4 euros pour 31.6 %,
# entre 4 et 6 euros pour 21.1 % et entre 6 et 8 euros pour 15.9 %
#
# - On peut observer que pour les montants payés en arrondissement 2 sont majoritairement
# des montants payés de plus de 6 euros pour 32.3 % des usagers ou des montants payés entre 2 et 4 euros pour 31.7 % des usagers

####################################-

