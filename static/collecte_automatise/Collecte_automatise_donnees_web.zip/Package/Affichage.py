if __name__=="__main__":
    import Classe_SQL as pc_sql
else:
    import Package.Classe_SQL as pc_sql

import datetime as d
import babel.dates as b

# HTML TEMPLATE POUR TOUTES LES OPTIONS (DÉBUT ET FIN)

# DÉBUT            
html_template_debut = """
 <!DOCTYPE html>
    <html lang="fr">
    <head>
    <link href="style.css" rel="stylesheet" type="text/css"/>
    <meta charset="UTF-8" />
    <script>
    function changeColor(lien) {
      var link = document.getElementById(lien);
      link.classList.add('clicked');
    }
    </script>
"""

# FIN
html_template_fin = """<div class = 'origin'> <h4> Source des données : </h4> <br /> 
    <a id = 'lien_api' href = 'https://gnews.io/' onclick = "changeColor('lien_api')" target = _blank>GNews</a> pour la collecte des articles. <br />
    <a id = 'lien_news' href = 'https://www.alphavantage.co/' onclick = "changeColor('lien_news')" target = _blank>Alphavantage</a> pour la collecte des valeurs des actions. </div>
    </body>
    </html>"""

#######################################
def option1():
    """
    Cette fonction permet de montrer dans l'affichage console la liste des entreprises et leur symbole boursier associé.
    Elle permet aussi de faire l'affichage HTML avec le fichier CSS construit auparavant.
    """
    # Récupérer la liste des entreprises avec leurs actions
    liste_ent = pc_sql.Entreprise.liste_entreprises(index=False)

    # TEMPLATE HTML ####################################################
    html_liste = html_template_debut + """
        <title> Liste des entreprises avec leur symbole boursier</title>
    </head>
    <body>
    <header>
    <h1> Liste des entreprises avec leur action</h1>
    </header>"""
    ####################################################################

    # DÉBUT CONSOLE ####################################################
    print("\nListe des entreprises avec leur symbole boursier :")
    ####################################################################

    # UTILISATION DES ÉLÉMENTS RÉCUPÉRÉS ##############################
    for ent, symb in liste_ent :
        

        date = str(d.datetime.now())
        sep_date = date.split("-")
        donnees = pc_sql.Action.donnees_mensuelles_mois_annee(sep_date[1], sep_date[0], symb)[0]
        #print(donnees)
        # PARTIE CONSOLE ############################################
        print (f"\nEntreprise : '{ent}' \nSymbole boursier : '{symb}'")
        #############################################################

        # PARTIE HTML ###############################################
        html_liste += f"""<ul class = 'liste_ent1'>
            <li> <span class = 'entreprise'>Entreprise : 
        {ent} </span>
            <br /> <span class = 'symbole'> Symbole : 
        {symb} </span>
            <br /> Informations sur la valeur de l'action d'aujourd'hui : 
            <ul class = 'valeuract'> 
            <li> Valeur haute : {donnees[2]} $ </li>
            <li> Valeur basse : {donnees[3]} $ </li>
            <li> Valeur d'ouverture : {donnees[4]} $ </li>
            <li> Valeur de fermeture : {donnees[5]} $ </li>
            <li> Volume : {donnees[6]} </li>
            </ul>
            </li>
        </ul>"""
        ##############################################################
    ####################################################################

    # FIN DE L'AFFICHAGE CONSOLE
    print("\n") 
    ############################

    # AJOUT DE LA FIN DU FICHIER HTML
    html_liste += html_template_fin
    #################################

    # ÉCRITURE DANS UN FICHIER HTML 
    with open('Information_Entreprise_Action.html',"w", encoding='utf-8') as obj_fich:
        obj_fich.write(html_liste)  
        obj_fich.close()
    ###############################


def option2_annee(nom_entreprise, annee):
    """
    Cette fonction permet de montrer les données mensuelles sur une année complète de l'entreprise.
    Elle permet un affichage console et HTML.
    Elle aura besoin comme argument :
    - nom_entreprise : nom de l'entreprise
    - annee : l'année où chercher les données mensuelles sur l'action de l'entreprise
    """

    # PARTIE INITIALISATION ####################################
    # Récupérer le nom de l'entreprise avec son symbole boursier
    ent_act = pc_sql.Entreprise.liste_entreprises(nom_ent=nom_entreprise, index=False)
    #print(ent_act)

    # Dans le cas où la requête n'a donné aucun résultat
    if ent_act==[]:
         raise ValueError("Le nom de l'entreprise n'existe pas dans la base de données.")
    ############################################################

    # PARTIE APPLICATION #################################################
    donnees = pc_sql.Action.donnees_mensuelles_annee(annee, ent_act[0][1])
    #print(donnees)

    # DÉBUT CONSOLE ######################################################
    chaine = f"\nVoici les données mensuelles de l'entreprise {nom_entreprise} ({ent_act[0][1]}) pour l'année {annee} : \n\n"
    ######################################################################

    # TEMPLATE HTML ######################################################
    tableau = html_template_debut + f"""
            <title> Action de l'entreprise {nom_entreprise} ({ent_act[0][1]}) pour l'année {annee} </title>
    </head>
    <body>
        <header>
            <h1> Action de l'entrerpise {nom_entreprise} ({ent_act[0][1]})<br /> pour l'année {annee} </h1>
        </header>
        <br />
        <table>
                <tr> 
                    <th> Mois </th>
                    <th> Prix haut (USD) </th>
                    <th> Prix bas (USD) </th>
                    <th> Prix d'ouverture (USD) </th>
                    <th> Prix de fermeture (USD) </th>
                    <th> Volume </th>
                </tr>"""
    ###################################################################################################

    # PARTIE UTILISATION DES ÉLÉMENTS RÉCUPÉRÉS #######################################################
    for elt in donnees[::-1]:
         
         # RÉCUPÉRATION DU MOIS EN FRANCAIS
         date = d.datetime.strptime(elt[0], "%Y-%m-%d")
         date = b.format_date(date,format="MMMM",locale='fr_FR')
         #print(date)
         ##################################
         
         # PARTIE CONSOLE #################################################################
         chaine+= f"Pour le mois de {date}, nous avons comme données pour cette action : \n"
         chaine+= f"- haut : {elt[2]} \n- bas : {elt[3]} \n- ouverture : {elt[4]} \n- fermeture : {elt[5]} \n- volume : {elt[6]} \n\n"
         ##################################################################################

         # PARTIE HTML ##########################################################################################################################
         tableau += f"""
         <tr>
                <td> {date.upper()} </td>
                <td>{elt[2]}</td>
                <td>{elt[3]}</td>
                <td>{elt[4]}</td>
                <td>{elt[5]}</td>
                <td>{elt[6]}</td>
         </tr>"""
         ######################################################################################################################################

    ###########################################################################################################################################
    
    # FIN CONSOLE ####################
    print(chaine)
    ##################################

    # FIN HTML #######################
    tableau += "</table>"+html_template_fin
    ##################################

    # EXPORTATION DU FICHIER HTML ##################################################
    with open('Information_Entreprise_Action.html','w',encoding="UTF-8") as obj_fich:
        obj_fich.write(tableau)
        obj_fich.close()
    ################################################################################
    ####################################################################################
        
def option2_annee_mois(nom_entreprise, annee, mois):
    """
    Cette fonction permet de montrer pour une année et un mois précis, les données mensuelles de l'entreprise.
    Elle aura besoin de trois arguments qui sont :
    - nom_entreprise : nom de l'entreprise
    - annee : année où on doit chercher les données 
    - mois : mois où on doit chercher les données
    Cette fonction possède un affichage console et un affichage HTML
    """

    # PARTIE INITIALISATION #############################################################
    ent_act = pc_sql.Entreprise.liste_entreprises(nom_ent=nom_entreprise, index=False)
    #print(ent_act)

    if ent_act==[]:
         raise ValueError("Le nom de l'entreprise n'existe pas dans la base de données.")
    #####################################################################################

    # PARTIE APPLICATION ################################################################
    donnees = pc_sql.Action.donnees_mensuelles_mois_annee(mois, annee, ent_act[0][1])
    #print(donnees)

    
    # RÉCUPÉRATION DU MOIS EN FRANCAIS
    date = d.datetime.strptime(donnees[0][0], "%Y-%m-%d")
    date = b.format_date(date,format="MMMM",locale='fr_FR')
    #print(date)
    ##################################

    # PARTIE CONSOLE ###################################################################
    chaine = f"Voici les données mensuelles de l'entreprise {nom_entreprise} ({ent_act[0][1]}) pour l'année {annee} et le mois de {date.upper()} : \n"
    chaine += f"- haut : {donnees[0][2]} \n- bas : {donnees[0][3]} \n- ouverture : {donnees[0][4]} \n- fermeture : {donnees[0][5]} \n- volume : {donnees[0][6]} \n\n"
    ####################################################################################

    # TEMPLATE HTML ####################################################################
    tableau = html_template_debut + f"""
            <title> Action de l'entreprise {nom_entreprise} ({ent_act[0][1]}) pour l'année {annee} et le mois de {date.upper()} </title>
    </head>
    <body>

        <header>
        <h1> Action de l'entrerpise {nom_entreprise} ({ent_act[0][1]}) pour l'année {annee} et pour le mois de {date.upper()}</h1>
        </header>
        <br />
        <table>
            <tr> 
                <th> Mois </th>
                <th> Prix haut (USD) </th>
                <th> Prix bas (USD) </th>
                <th> Prix d'ouverture (USD) </th>
                <th> Prix de fermeture (USD) </th>
                <th> Volume </th>
            </tr>"""
    #####################################################################################

    # PARTIE HTML #######################################################################
    tableau += f"""<tr>
            <td> {date.upper()} </td>
            <td>{donnees[0][2]}</td>
            <td>{donnees[0][3]}</td>
            <td>{donnees[0][4]}</td>
            <td>{donnees[0][5]}</td>
            <td>{donnees[0][6]}</td>
            </tr>"""
    #####################################################################################

    # FIN HTML ##########################################################################
    tableau += "</table>"+html_template_fin
    #####################################################################################

    # EXPORTATION DU FICHIER HTML #######################################################
    with open('Information_Entreprise_Action.html','w',encoding="UTF-8") as obj_fich:
        obj_fich.write(tableau)
        obj_fich.close()
    #####################################################################################
        
    # FIN CONSOLE #######
    print(chaine)
    #####################

    ###############################################################################################################


def calcul_var_ord(data):
     """
          Cette fonction permet de calculer la variance des valeurs d'une action sur la fermeture pour chaque mois en ayant comme argument : 
          - data : [[date, valeur_fermeture], ...] (triés dans l'ordre croissant les dates)

          Cela permet de retourner une liste de liste appelée var contenant les éléments suivants :
          - var : [[année, date_mois_avant, date_mois_après, variation %], ...] 
    """
     
     # INITIALISATION ####
     var = []
     #####################

     # PARCOURS DES ÉLÉMENTS #########################
     for ind in range(len(data)):
         # ORDRE CROISSANT LES DATES DONC LE PREMIER ÉLÉMENT EST FORCÉMENT POUR LE MOIS DE JANVIER DONC ON PEUT L'IGNORER
         if ind != 0:
             
         # CALCUL DE LA VARIANCE ###############
         # Différence en pourcentage
             #print(data[ind])
             #print(data[ind-1])

             # Calcul de la différence
             nb = data[ind][1]-data[ind-1][1]

             # Ajout de l'année, la date d'avant, la date actuel et la variation en pourcentage
             var.append([data[ind][0].split("-")[0], 
                     data[ind-1][0], 
                     data[ind][0],
                     round(nb/data[ind-1][1]*100, 2),
                     data[ind][2]])
        ##########################################
    ##################################################
             
     # RENVOIE LA LISTE DES VARIANCES
     return var
     ################################


def option3(nom_entreprise, annee):
    """
    Cette fonction permet de montrer pour une année, les variations mensuelles de l'entreprise.
    Elle aura besoin de deux arguments qui sont :
    - nom_entreprise : nom de l'entreprise
    - annee : année où on doit chercher les données 
    Elle possède un affichage console et un affichage HTML.
    """
    # PARTIE INITIALISATION ######################################
    # Récupérer les données mensuelles pour une année complète sur la valeur de fermeture d'une entreprise
    donnees = pc_sql.Action.fermeture_annee(annee, nom_entreprise)
    #print(donnees)

    # Calcul de la variance
    var = calcul_var_ord(donnees)
    #print(var)
    ##############################################################

    # DÉBUT CONSOLE ###########
    chaine = ""
    ###########################

    # TEMPLATE HTML ###########
    html_tableau =html_template_debut+f"""
                              <title> Variations mensuelles de l'entreprise {nom_entreprise} ({donnees[0][2]}) pour l'année {annee} </title>
                        </head>
                        <body>
		                        <header>
                                <h1> Variations mensuelles <br /> de l'entreprise {nom_entreprise} ({donnees[0][2]}) <br />pour l'année {annee}</h1>
                                </header> <br />

                                    <table>

                                          <tbody>
                                                <tr>
                                                      <th>
                                                            {nom_entreprise} <br />
                                                            {annee}
                                                      </th>
                                                      <th>
                                                            {donnees[0][2]}
                                                      </th>
                                                </tr>
                                                <tr>
                                                      <th>
                                                            Mois
                                                      </th>
                                                      <th>
                                                            Variations
                                                      </th>
                                                </tr>"""
    #########################################################################

    # PARTIE UTILISATION DES ÉLÉMENTS RÉCUPÉRÉS #######################################################
    for elt in var:
         # CRÉATION DU SYMBOLE ET DE LA SYNTAXE PERMETTANT DE PRÉCISER SI C'EST UNE BAISSE OU UNE AUGMENTATION ET S'IL EST IMPORTANTE
         synt=""
         gras_av = ""
         gras_ap = ""
         # AJOUT DANS LA CONSOLE DU ** ET DU GRAS POUR LE HTML POUR METTRE EN ÉVIDENCE LES VARIATIONS SUPÉRIEURES À 5%
         if abs(elt[3]) > 5:
             synt = "**"
             gras_av = "<strong>"
             gras_ap = "</strong>"
         #############################################################################################################
         
         # CAS DU SYMBOLE ######
         symbole=""
         aug_bai = ""

         # CAS D'UNE BAISSE 
         if elt[3] < 0:
             symbole = "🔻"
             aug_bai = "class = baisse"    
         ###################
             
         # CAS D'UNE AUGMENTATION
         else:
             symbole = "🔺"
             aug_bai = "class = augmentation"
         ########################

         # RÉCUPÉRATION DU MOIS D'AVANT ET L'ACTUEL EN FRANCAIS    
         date_act = d.datetime.strptime(elt[2], "%Y-%m-%d")
         date_act = b.format_date(date_act,format="MMMM",locale='fr_FR')
         date_avt = d.datetime.strptime(elt[1], "%Y-%m-%d")
         date_avt = b.format_date(date_avt,format="MMMM",locale='fr_FR')
         ###############################################################

         # CAS DU DÉBUT DE PARCOURS POUR AJOUTER DANS LA CONSOLE SUR QUELLE ANNÉE SE FAIT LES VARIATIONS MENSUELLES
         if not("Variations" in chaine):
             chaine += f"Variations des prix de clôtures pour l'année {elt[0]} : \n\n"
         ##########################################################################################################
         
         # PARTIE CONSOLE ##############################################
         chaine += f"Pour les mois entre {date_avt} et {date_act} : \n"

         chaine += f"{elt[4]}: {symbole}{abs(elt[3])}% {synt}\n\n"
         ###############################################################

         # PARTIE HTML #################################################
         html_tableau+=f"""
                        <tr>
                              <td> {date_act.upper()} </td>
                              <td {aug_bai}> {gras_av} {symbole}{abs(elt[3])}% {gras_ap} </td>

                        </tr>
                        """
         ###############################################################
    
    # FIN DU HTML ###########################
    html_tableau+= "</table>"+html_template_fin
    #########################################

    # EXPORTATION DU FICHIER HTML ######################################
    f = open("Information_Entreprise_Action.html", 'w', encoding="utf-8")
    f.write(html_tableau)
    f.close()
    ####################################################################

    # AFFICHAGE CONSOLE
    print(chaine)
    ###################

def option4(nom_entreprise, annee):
    """
    Cette fonction permet de montrer pour une année, articles 'pertinents' de l'entreprise.
    Elle aura besoin de deux arguments qui sont :
    - nom_entreprise : nom de l'entreprise
    - annee : année où on doit chercher les données 
    Elle possède un affichage console et un affichage HTML.
    """

    # RÉCUPÉRATION DES ARTICLES DANS LA BASE ###############################
    donnees = pc_sql.Actu.recuperation_article_annee(annee, nom_entreprise)
    #print(donnees)
    ########################################################################

    # DÉBUT CONSOLE ###############################################################################################################
    chaine = f"Les articles pertinents de l'année {annee} sur l'entreprise {nom_entreprise} récoltés de façon TRIMESTRIELLE : \n\n"
    ###############################################################################################################################

    # TEMPLATE HTML #######################################
    html_texte = html_template_debut + f"""
                              <title> Articles concernant l'entreprise {nom_entreprise} </title>
                            </head>
                            <body>
                              <header>
                                <h1>Les articles concernant l'entreprise {nom_entreprise} en {annee} récupérés de façon TRIMESTRIELLE : </h1>
                              </header>"""
    #######################################################

    # PARTIE UTILISATION DES ÉLÉMENTS RÉCUPÉRÉS #######################################################
    # Identifiant permet le changement de couleur quand le lien est cliqué
    id = 0
    for elt in donnees:
         date = d.datetime.strptime(elt[4].split(" ")[0], "%Y-%m-%d")
         date = b.format_date(date,format="dd MMMM YYYY",locale='fr_FR')
         # PARTIE CONSOLE ######################################################
         chaine+= f"Titre : {elt[0]} \nLien : {elt[2]} \nDescription : {elt[1]}"
         chaine += "\n\n"
         #######################################################################

         # PARTIE HTML #########################################################
         html_texte += f"""
         <p>
         <strong><span class = 'titreart'>Titre : {elt[0]}</span></strong><br /> 
         <span class = 'dateart'>Date : {date} </span><br /> 
         <span class = 'descart'>Description : {elt[1]} </span><br /> <br />
         <span class = 'lienart'>Lien : 
         <a href='{elt[2]}' id = '{str(id)}' onclick = "changeColor('{str(id)}')" target = _blank>{elt[3]}</a>
         </span>
         </p>"""
         id+=1
         #######################################################################
    #################################################################################################
         
    # AFFICHAGE CONSOLE ####
    print(chaine)
    ########################

    # FIN HTML ################
    html_texte+=html_template_fin
    # EXPORTATION DU FICHER HTML
    f = open("Information_Entreprise_Action.html", 'w', encoding="utf-8")
    f.write(html_texte)
    f.close()
    ############################

def entreprise_existe(nom_entreprise_act):
    """
    Cette fonction permet de savoir si le nom de l'entreprise donnée par l'argument 'nom_entreprise' existe bien dans la base de données.
    Si elle existe, alors elle retourne True sinon elle renvoie la première entreprise existante de la base de données.
    """

    # RÉCUPÉRATION DE LA LISTE DES ENTREPRISES AVEC LEUR ACTION
    liste_ent = pc_sql.Entreprise.liste_entreprises(index=False)
    #print(liste_ent)
    ###########################################################

    # PARTIE VÉRIFICATION DE L'EXISTENCE DE L'ENTREPRISE EN PARCOURANT LA LISTE
    for elt in liste_ent:
        # CAS SI ELLE EXISTE (nom entreprise)
        if nom_entreprise_act == elt[0] :
            return True

        # CAS SI ELLE EXISTE (nom de l'action)
        elif nom_entreprise_act == elt[1]:
            return [True, elt[0]]
        
        else:
            pass

    # CAS SI ELLE N'EXISTE PAS
    return  liste_ent[0][0]

# DIFFÉRENTS TEST QUE NOUS POUVONS EXÉCUTER
if __name__=="__main__":
    option1()
    #option2_annee("Tesla", 2022)
    #option2_annee_mois("Tesla", 2022, "01")
    #option3("Tesla", 2022)
    #option4("Tesla", 2022)
    #option3("Netflix", 2021)
    #print(entreprise_existe("Tesla"))
    #print(entreprise_existe("AMZN"))
#########################################