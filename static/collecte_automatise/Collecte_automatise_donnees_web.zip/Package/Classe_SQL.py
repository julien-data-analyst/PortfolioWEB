import sqlite3

# CRÉATION DE LA CLASSE DE GESTION DE BASE DE DONNÉES ###############################
class BDDManager:

    # ATTRIBUT DE CLASSE (ADAPTER LE CHEMIN SI VOUS UTILISER UN AUTRE LOGICIEL DE PROGRAMMATION) ######################
    BASE = "base.db"
    ###########################################

    # MODÈLE RELATIONNEL ######################
    # ACTION(:id_action, date, #id_ent, haut, bas, ouverture, fermeture, volume)
    # ACTU(:id_actu, url, #id_ent, date, titre, source, description, contenu)
    # ENTREPRISE(:id_ent, entreprise, symbole)
    
    def __init__(self, code, data):
        """
        Cette initialisation permet de réunir la requête SQL indiqué par l'argument 'code' et les données concernées par l'argument 'data'.
        Cela va notamment servir pour appliquer les requêtes à l'aide de méthode d'instance de cette classe.
        """
        # ATTRIBUTS D'INSTANCE ################
        self.code = code
        self.data = data
        #######################################

    def sqliterequest(self) :
        """
        Méthode d'instance permettant d'exécuter une requête qui n'interfère pas dans l'enregistrement de données dans la base.
        """
        result = None
        try :
            connection = sqlite3.connect(self.BASE)
            c = connection.cursor()
            c.execute(self.code)
            result = c.fetchall()
            connection.close()
        except Exception as e:
            print(e)
        return result
    
    def sqliteinsertdata(self) :
        """
        Méthode d'instance permettant d'exécuter des requêtes de préférence de type INSERT pour pouvoir enregistrer des données.
        """
        try :
            connection = sqlite3.connect(self.BASE)
            c = connection.cursor()
            c.execute(self.code, self.data)
            connection.commit()
            connection.close()
        except Exception as e:
            connection.close()
            print(e)

    @staticmethod
    def initialisation():
        """
        Cette méthode statique permet d'initialiser ou de rénitialiser la base de données avec les requête de destruction et de création.
        """
    # INITIALISATION DE LA BASE DE DONNÉES ####################

    # SUPPRIMER LES TABLES DÉJÀ EXISTANTES ####################
        req_drop = ["DROP TABLE IF EXISTS ENTREPRISE;",
              "DROP TABLE IF EXISTS ACTU;",
              "DROP TABLE IF EXISTS ACTION;"]
        
        for req  in req_drop:
          drop = BDDManager(req, ())
          drop.sqliterequest()
    ###########################################################

    # CRÉATION DE TABLES ######################################
        req_create = [
              """CREATE TABLE IF NOT EXISTS ENTREPRISE(
              id_ent INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
              nom CHAR(50) NOT NULL,
              symbole CHAR(50) NOT NULL
              );""",

              """CREATE TABLE IF NOT EXISTS ACTION(
                id_act INTEGER PRIMARY KEY NOT NULL,
                date DATE NOT NULL,
                id_ent INTEGER NOT NULL,
                haut DECIMAL(8, 4) NOT NULL,
                bas DECIMAL(8, 4) NOT NULL,
                ouverture DECIMAL(8, 4) NOT NULL,
                fermeture DECIMAL(8, 4) NOT NULL,
                volume INTEGER NOT NULL,
                FOREIGN KEY (id_ent) REFERENCES ENTREPRISE(id_ent)
              );""",
              
              """CREATE TABLE IF NOT EXISTS ACTU(
                id_actu INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                url CHAR(225) NOT NULL,
                id_ent INTEGER NOT NULL,
                date DATETIME NOT NULL,
                titre CHAR(225) NOT NULL,
                source CHAR(225) NOT NULL,
                description TEXT NOT NULL,
                contenu TEXT NOT NULL,
                FOREIGN KEY (id_ent) REFERENCES ENTREPRISE(id_ent)
              );"""]

        for req  in req_create:
            create = BDDManager(req, ())
            create.sqliterequest()
    ###############################################################

    ###############################################################





# TABLE ENTREPRISE #################################################################################
class Entreprise:
    def __init__(self, nom_ent, nom_act):
        """
        La classe Entreprise possède les attributs d'instance suivants : 
        - nom_entreprise : nom de la compagnie
        - nom_action : nom de l'action (symbole boursier)
        Elle permet d'insérer plus facilement les entreprises avec leur symbole boursier dans la base de données.
        """

        # Attributs d'instances
        self.nom_ent = nom_ent
        self.nom_act = nom_act
        
        # Insertion de la ligne de donnée dans la base
        insert = BDDManager("INSERT INTO ENTREPRISE(nom, symbole) VALUES (?, ?);", (nom_ent, nom_act))
        insert.sqliteinsertdata()
    
    @staticmethod
    def liste_entreprises(nom_ent = "", nom_act = "", index = True) :
        """
        Permet de récupérer une liste contenant pour chaque élément le nom de l'entreprise et le symbole boursier associé.
        Deux argument peut-être mis qui sont le nom de l'entreprise et le nom de l'action recherché pour voir notamment si elle existe et quelle est son identifiant.
        """

        # PARTIE VÉRIFICATION DE LA DEMANDE D'INDICE
        if index==False:
            syntaxe = "nom, symbole"

        elif index:
            syntaxe = "*"
        
        else:
            raise ValueError("Erreur dans l'argument index où ce n'est pas une valeur booléen")
        ############################################

        # PARTIE CRÉATION DE LA REQUÊTE #######################
        if nom_ent=="" and nom_act=="":
            # CRÉATION DE LA REQUÊTE
            req_sel = BDDManager(f"SELECT {syntaxe} FROM ENTREPRISE;",())
            ########################
        
        elif nom_ent!="":
            # CRÉATION DE LA REQUÊTE
            req_sel = BDDManager(f"SELECT {syntaxe} FROM ENTREPRISE WHERE nom='{nom_ent}';",())
            ########################

        else:
            # CRÉATION DE LA REQUÊTE
            req_sel = BDDManager(f"SELECT {syntaxe} FROM ENTREPRISE WHERE symbole='"+nom_act+"';",())
            ########################

        # APPLICATION DE LA REQUÊTE
        nom_symb = req_sel.sqliterequest()
        ###########################

        # RENVOIE DE LA LISTE DES ENTREPRISES AVEC LEUR SYMBOLE BOURSIER OU DE L'ENTREPRISE DEMANDÉE AVEC SON ACTION
        return nom_symb
        ############################################################################################################
    
#####################################################################################################



# TABLE ACTION ######################################################################################
class Action:
    def __init__(self, id_ent, date, haut, bas, ouverture, fermeture, volume):
        """
        Cette classe possède les attributs d'instance suivants :
        - id_action : identifiant unique fait à partir de id_ent et de la date
        - id_ent : identifiant faisant référence à la table ENTREPRISE
        - date : date au format YYYY-MM-DD
        - haut : prix de l'action le plus haut
        - bas : prix de l'action le plus bas
        - ouverture : prix de l'action à l'ouverture
        - fermeture : prix de l'action à la fermeture
        - volume : nombre d'actions
        """

        # Les attributs d'instance
        sep_date = date.split("-")
        self.id_action = int(sep_date[0]+sep_date[1]+id_ent) #AnnéeMoisId_ent
        self.id_ent = id_ent
        self.date = date
        self.haut = haut
        self.ouverture = ouverture
        self.fermeture = fermeture
        self.volume = volume

        # Insertion de la ligne de donnée dans la base
        insert = BDDManager("INSERT INTO ACTION(id_act, date, id_ent, haut, bas, ouverture, fermeture, volume) VALUES (?, ?, ?, ?, ?, ?, ?, ?);", 
                            [self.id_action, date, id_ent, haut, bas, ouverture, fermeture, volume])
        insert.sqliteinsertdata()

    @staticmethod
    def fermeture_annee(annee, ent):
        """
        Cette méthode statique permet de récupérer pour une année précise les données mensuelles sur la valeur de fermeture de l'action.
        Elle aura besoin de deux arguments qui sont :
        - annee : l'année où on doit cherher
        - ent : nom de l'entreprise
        """

        # CRÉATION DE LA REQUÊTE 
        sel = BDDManager(f"""SELECT act.date, act.fermeture, ent.symbole FROM ACTION AS act 
                         INNER JOIN ENTREPRISE AS ent ON ent.id_ent = act.id_ent 
                         WHERE ent.nom='{ent}' AND strftime('%Y', act.date) = '{annee}' ORDER BY act.date;""", ())
        ########################

        # RENVOIE LA LISTE DES DONNÉES MENSUELLES
        return sel.sqliterequest()
        #########################################
    
    @staticmethod
    def donnees_mensuelles_annee(annee, symbole):
        """
        Permet de retourner une liste contenant les données mensuelles de l'action d'une entreprise sur une année complète.
        Cette méthode statique aura besoin de deux arguments qui sont :
        - annee : l'année où on doit chercher les données
        - symbole : l'action à chercher
        Attention à la manipulation des données de type INTEGER qui sont représentés non par des chiffres mais par un code byte
        que nous devons convertir en nombre.
        """
        # PARTIE INITIALISATION
        code_request=f"""SELECT act.date, ent.nom, act.haut, act.bas, act.ouverture, act.fermeture, act.volume FROM ACTION AS act 
        INNER JOIN ENTREPRISE AS ent ON ent.id_ent = act.id_ent 
        WHERE strftime('%Y', act.date) = '{annee}' AND ent.symbole = '{symbole}';"""
        #######################

        # PARTIE APPLICATION
        req_sql=BDDManager(code_request,())
        donnees = (req_sql.sqliterequest())
        #print(donnees)
        ####################

        # PARCOURIR CHAQUE ÉLÉMENT POUR TRANSFORMER LES VOLUMES EN NOMBRES
        # TRANSFORMATION ET AJOUT DES VOLUMES
        for i in range(len(donnees)):
            # TRANSFORMATION D'UN TUPLE EN UNE LISTE
            donnees[i] = list(donnees[i])

            # AJOUT DU VOLUME TRANSFORMÉ EN NOMBRE
            donnees[i][6] = int.from_bytes(donnees[i][6],byteorder='little')
        ###################################################################
            
            
        ###################################################################
        
        # RENVOIE LA LISTE DE DONNÉES MENSUELLE DEMANDÉE
        return donnees

    @staticmethod
    def donnees_mensuelles_mois_annee(mois, annee, symbole):
        """
        Permet de retourner une liste contenant les données mensuelles de l'action d'une entreprise sur un mois et une année précis.
        Cette méthode statique aura besoin de deux arguments qui sont :
        - mois : mois où on doit chercher
        - annee : année où on doit chercher
        - symbole : l'action qu'on doit chercher
        """

        # PARTIE INITIALISATION
        code_request=f"""SELECT act.date, ent.nom, act.haut, act.bas, act.ouverture, act.fermeture, act.volume FROM ACTION AS act 
        INNER JOIN ENTREPRISE AS ent ON ent.id_ent = act.id_ent 
        WHERE strftime('%Y-%m', act.date) = '{annee}-{mois}' AND ent.symbole = '{symbole}';"""
        #######################

        # PARTIE APPLICATION
        sel=BDDManager(code_request,())        
        donnees = sel.sqliterequest()
        #print(donnees)
        ####################

        # TRANSFORMATION ET AJOUT DES VOLUMES
        donnees[0] = list(donnees[0])
        donnees[0][6] = int.from_bytes(donnees[0][6],byteorder='little')
        #####################################

        # RENVOIE LES DONNÉES TROUVÉES
        return donnees
#####################################################################################################

# TABLE ACTU ########################################################################################
class Actu(BDDManager):

    trimestre = {}
    def __init__(self, id_ent, titre, page_maison, description, contenu, date, url):

        """
        Cette classe possède les attributs d'instance suivants : 
        - id_actu: identifiant unique composé de la date, de l'id de l'entreprise, de la source et du titre
        - id_ent : identifiant faisant référence à la table ENTREPRISE
        - titre : titre de l'article
        - page_maison : type d'article
        - description : description de l'article
        - contenu : partie du contenu de l'article
        - date : datetime au format YYYY-MM-DD HH:MM:SS
        - url : source menant à l'article
        """

        # Les attributs d'instance
        self.id_ent = id_ent
        self.titre = titre
        self.page_maison = page_maison
        self.description = description
        self.contenu = contenu
        self.date = date
        self.url = url

        # Insertion de la ligne de donnée dans la base
        insert = BDDManager("INSERT INTO ACTU(url, date, id_ent, titre, source, description, contenu) VALUES (?, ?, ?, ?, ?, ?, ?);", 
                            [url, date, id_ent, titre, page_maison, description, contenu])
        insert.sqliteinsertdata()
    
    @staticmethod
    def recuperation_article_annee(annee, ent):
        """
        Cette méthode statique permet de récupérer pour une année, les articles concernant l'entreprise indiquée. 
        Elle aura besoin de deux arguments :
        - annee : année où on doit chercher
        - ent : le nom de l'entreprise qu'on doit chercher
        """

        # PARTIE INITIALISATION
        req_sel = f"""SELECT act.titre, act.description, act.url, act.source, act.date FROM ACTU AS act 
        INNER JOIN ENTREPRISE AS ent ON ent.id_ent = act.id_ent 
        WHERE strftime('%Y', act.date) = '{annee}' AND ent.nom = '{ent}';"""
        req_sel = BDDManager(req_sel, ())
        
        # PARTIE APPLICATION + RENVOIE
        return req_sel.sqliterequest()
    
#####################################################################################################


# PARTIE TEST DES DIFFÉRENTES MÉTHODES
if __name__=="__main__":
    print(Action.donnees_mensuelles_annee(2022, "TSLA"))
    #print(Action.donnees_mensuelles_mois_annee("02", 2022, "AAPL"))
    #print(Action.fermeture_annee(2021, "Tesla"))
    #print(Actu.recuperation_article_annee(2022, "Tesla"))
    #print(Entreprise.liste_entreprises())
    #BDDManager.initialisation()
######################################