if __name__=="__main__":
    import Classe_SQL as cls_sql
else:
    import Package.Classe_SQL as cls_sql
import pandas as pd
import glob
import regex as r

def insertion_csv_sqlite(repertoire_destination, table):
    """
    Cette fonction permet d'insérer des données à l'aide des différents fichiers CSV conservés dans les dossiers action et actu.
    Elle a besoin de deux arguments qui sont :
    - repertoire_destination : chemin relatif où sont stockés les fichiers CSV
    - table : table de la base de données concernés pour l'insertion
    """

    # RÉCUPÉRER LA LISTE CONTENANT LES CHEMINS AVEC LES NOMS DE FICHIERS DE DONNÉES QUE NOUS AVONS BESOIN 
    liste_fich = glob.glob(repertoire_destination+"/*.csv")
    ######################################################################################################

    # CAS DE L'INSERTION DANS LA TABLE ACTION
    if table=="action":

        print("Insertion dans la table action")

        # PARCOURS DE CHAQUE FICHIER DE DONNÉES
        for fich in liste_fich:
            
            # LECTURE DU FICHIER DE DONNÉES
            data = pd.read_csv(fich)
            ###############################

            # RÉCUPÉRATION DU NOM DE L'ACTION DANS LE FICHIER
            ind_act = r.search("\\_\w*\.", fich)
            nom_action = fich[ind_act.start()+1:ind_act.end()-1]
            ################################################################################

            # RÉCUPÉRATION DE L'ID PERMETTANT D'IDENTIFIER L'ENTREPRISE À ASSOCIER À L'AIDE DU SYMBOLE QUE NOUS AVONS RÉCUPÉRÉ
            print(nom_action)
            id = cls_sql.Entreprise.liste_entreprises(nom_act=nom_action)

            if id == []:
                raise ValueError(f"Erreur dans l'insertion du fichier car l'action n'existe pas dans la base : \n{fich}")
            #######################################################################################################

        ##############################################################################
            
            # PARCOURS DE CHAQUE LIGNE DE DONNÉES POUR L'INSERTION DANS LA BASE DE DONNÉES
            for elt in data.to_records(index=False):
                # INSERTION DE LA LIGNE DE DONNÉES
                cls_sql.Action(str(id[0][0]), elt[5], elt[1], elt[2], elt[0], elt[3], elt[4])
            #########################################################################
    ###############################################################
    
    # CAS DE L'INSERTION DANS LA TABLE ACTU
    elif table == "actu":

        print("Insertion dans la table actu")

        # PARCOURS DE CHAQUE FICHIER DE DONNÉES
        for fich in liste_fich:
            # LECTURE DU FICHIER DE DONNÉES
            data = pd.read_csv(fich)
            ###############################


            # RÉCUPÉRATION DU NOM DE L'ENTREPRISE
            ind_ent = r.search("\w*\.", fich)
            nom_entreprise = fich[ind_ent.start():ind_ent.end()-1]
            ########################################################

            # RÉCUPÉRATION DE L'ID PERMETTANT D'IDENTIFIER L'ENTREPRISE À ASSOCIER À L'AIDE DU SYMBOLE QUE NOUS AVONS RÉCUPÉRÉ
            print(nom_entreprise)
            id = cls_sql.Entreprise.liste_entreprises(nom_ent=nom_entreprise)

            if id == []:
                raise ValueError(f"Erreur dans l'insertion du fichier car l'entreprise n'existe pas dans la base : \n{fich}")
            #######################################################################################################
            
            # PARCOURS DE CHAQUE LIGNE DE DONNÉES POUR L'INSERTION DANS LA BASE DE DONNÉES
            for elt in data.to_records(index=False):
                
                # RÉCUPÉRATION DE LA DATE AU FORMAT SQLITE
                date = elt[4].replace("T", " ")
                date = date.replace("Z", "")
                ##########################################

                # INSERTION DE LA LIGNE DE DONNÉES DANS LA BASE
                cls_sql.Actu(str(id[0][0]), elt[0], elt[1], elt[2], elt[3], date, elt[5])
                ########################################################################

    #############################################################################################################
    
    # CAS DE L'INSERTION DANS LA TABLE ENTREPRISE
    elif table == "entreprise":

        print("Insertion dans la table entreprise")

        # PARCOURS DE CHAQUE FICHIER DE DONNÉES
        for fich in liste_fich:

            # ON RÉCUPÈRE LE NOM DU FICHIER SANS LE CHEMIN ET SANS L'EXTENSION
            ind_act = r.search("\w*\\_\w*", fich)
            
            # ON VA SÉPARER LE NOM DE L'ENTREPRISE ET DE L'ACTION EN DEUX CHAINES DE CARACTÈRES
            ent, action = fich[ind_act.start():ind_act.end()].split("_")

            # INSERTION DU NOM DE L'ENTREPRISE ASSOCIÉ AVEC SON SYMBOLE
            cls_sql.Entreprise(ent, action)
    ##########################################################################################
    
    # ERREUR DE NOM DE TABLE
    else:
        print("Il n'existe que trois tables pour insérer les données qui sont : \n- actu \n- action \n- entreprise")
        raise ValueError("Nom de table n'existe pas")
    ########################

# APPLICATION INSERTION DES DONNÉES ###############################
if __name__=="__main__":
    # ADAPTER LE CHEMIN SI NÉCESSAIRE DANS LE CAS D'UTILISATION D'UN AUTRE LOGICIEL DE PROGRAMMATION
    insertion_csv_sqlite("Donnees/action", "entreprise")
    insertion_csv_sqlite("Donnees/action", "action")
    insertion_csv_sqlite("Donnees/actu", "actu")
###################################################################