import requests as r
from datetime import datetime, timedelta
import pandas as pd

# API POUR LA COLLECTE DE DONNÉES ET LES CLÉS (CHANGER SI NÉCESSAIRE) #################################
CLE_API_GNEWS = "710e62f98f759727738478e60ba71697"
CLE_API_STOCK = "44YEJNO9SB02CF0Q"

END_POINT_NEWS = 'https://gnews.io/api/v4/search'
END_POINT_STOCK = "https://www.alphavantage.co/query"
###################################################################

class ProcesseurDonnees :

     # DICTIONNAIRE DES TRIMESTRES, MOIS ET JOURS ###########################
     trimestre = {
        "1"  : {
         "01" : "31",
         "02" : "28",
         "03" : "31"},

        "2" : { 
         "04" : "31",
         "05" : "31",
         "06" : "30"},

        "3" : {
         "07" : "31",
         "08" : "31",
         "09" : "30"},
        
        "4" : {
         "10" : "31",
         "11" : "30",
         "12" : "31"}
    }
    #############################################################
    
   
     # COLLECTE ACTION  #################################################################################################################
     @staticmethod
     def collecte_actions(cles, nom_action, annee_deb, annee_fin):
                    """
                    Cette fonction permet de récupérer une liste contenant la date, la valeur d'ouverture, haute, basse, fermeture et volume de l'action 
                    mensuelle avec les arguments suivants :
                    - nom_action : symbole boursier
                    - annee_deb : l'année où on doit commencer à chercher les valeurs d'action
                    - annee_fin : l'année où on doit s'arrêter à chercher les valeurs d'action
                    On doit savoir que la requête retourne le résultat en json dans l'ordre décroissante des dates ce qui nous permet de faciliter 
                    la tâche pour extraire les dates avec les années correspondantes.
                    """

                    # PARTIE VÉRIFICATION ########################################################
                    if type(annee_deb)!=int or type(annee_fin)!=int:
                         raise TypeError("Erreur, veuillez mettre un type valide pour les années")
                    
                    if annee_deb > annee_fin:
                         raise ValueError("Erreur, veuillez mettre des années valides")
                    ##############################################################################
                    
                    print(f"Partie collecte des données mensuelles pour l'action {nom_action}.")
                    # PARTIE COLLECTE ACTION #####################################################
                    liste_act = []

                    # PARAMÈTRES PERMETTANT LA RÉCUPÉRATION DES VALEURS DES ACTIONS ############## 
                    parametres_act = {
                          "symbol" : nom_action, # Nom de l'acyion
                          "function" : "TIME_SERIES_MONTHLY", # Par mois non ajustée
                          "apikey": cles, # clé de l'API pour permettre la récupération
                          "datatype" : "json" # Récupération des données au format JSON
                    }
                    ###############################################################################

                    # APPLICATION DE LA REQUÊTE ###########################
                    rep_bis = r.get(END_POINT_STOCK, params=parametres_act)
                    #######################################################

                    # SI ON A UNE ERREUR DE REQUÊTE, ON ARRÊTE LE PROGRAMME EN MONTRANT L'ERREUR ##
                    if not("Monthly Time Series" in rep_bis.json()):
                         print(f"Erreur dans la requête d'action avec le symbole {nom_action} : ")
                         print(rep_bis.json())
                         return "Erreur de requête"
                    ###############################################################################

                    #print(rep_bis.json)
                    
                    # PARTIE RÉCUPÉRATION DES DONNÉES ET RENVOIE D'UNE LISTE DE DONNÉES ###############
                    data = rep_bis.json()["Monthly Time Series"]

                    for date in data:

                         annee = int(date.split("-")[0])
                         
                         # VÉRIFICATION SI L'ANNÉE QU'ON A N'EST PAS INFÉRIEUR À L'ANNÉE DÉBUT ET N'EST PAS SUPÉRIEUR À L'ANNÉE FIN ######
                         if annee < annee_deb:
                              break
                         
                         elif annee > annee_fin:
                              pass
                         #################################################################################################################

                         else:
                              liste_act.append([data[date]["1. open"],
                                             data[date]["2. high"],
                                             data[date]["3. low"],
                                             data[date]["4. close"],
                                             data[date]["5. volume"],
                                             date])
                    
                    return liste_act
                    ###################################################################################################################

     #############################################################################################################

# COLLECTE ARTICLE  #################################################################################################################
     @staticmethod
     def collecte_actu(cles, nom_compagnie, nom_act, mois, annee):

          """
    Cette fonction permet de récupérer une liste d'articles sur la compagnie et sur son symbole boursier avec les arguments suivants :
    - cles : l'ID pour pouvoir utiliser l'API GNews
    - nom_compagnie : nom de l'entreprise
    - nom_act : symbole boursier de l'entreprise
    - mois : mois auquel on a une variation élevée et où on doit chercher les articles
    - annee : année où on doit chercher les articles

    Chaque élément de cette liste va contenir une liste d'éléments qui sont les suivants :
    - Titre 
    - Source
    - Description
    - Contenu
    - Date de publication ('YYYY-MM-JJ HH:MM:SS')
    - Lien menant à l'article 
          """

          

    # PARTIE COLLECTE ACTU ######################################
          liste_actu = []

          for trim in ProcesseurDonnees.trimestre:
               
                # REPRÉSENTE LE TRIMESTRE ####################################################
                #print(trimestre[trim])
                ##############################################################################

                # RÉCUPÉRATION DU PREMIER MOIS ET DU TROISIÈME MOIS DU TRIMESTRE ACTUEL ######
                    liste_mois = []
                    if mois in list(ProcesseurDonnees.trimestre[trim].keys()):
                           liste_mois = list(ProcesseurDonnees.trimestre[trim].keys())
                           break
                #print(liste_mois)                
                ##############################################################################
                    
          #print("Collecte en "+str(annee)+" pour le mois chiffré de "+mois+" dans le trimestre "+trim)

          if liste_mois == []:
                 raise ValueError("Erreur d'attribution du mois")
          
          # PARAMÈTRES PERMETTANT LA RÉCUPÉRATION DES ARTICLES ############## 
          parametres_news = {
                    "q" : f"{nom_compagnie} OR {nom_act}", # Les mots clés à chercher qui vont être le nom de compagnie et le nom de l'action
                    "lang" : "fr", # Les articles doivent être écrits en français
                    "from" : f"{str(annee)}-{liste_mois[0]}-01T00:00:00Z", # Les dates de publications 
                                                                           # de ces articles doivent être supérieures à cette date                 
                    "to" : f"{str(annee)}-{liste_mois[2]}-{ProcesseurDonnees.trimestre[trim][liste_mois[2]]}T23:59:59Z", # Les dates de publications
                                                                                                                         # des articles doivent être inférieur à cette date              
                    "apikey" :cles, # Clé de l'API pour permettre la récupération 
                    "category" : "business", # Catégorie pour essayer d'avoir des articles plus pertinentes
                    "sortby" : "relevance" # Trier dans l'ordre décroissant pour ne qu'avoir les articles les plus pertinentes
                    }
          ####################################################################

          # APPLICATION DE LA REQUÊTE ###########################
          rep_bis = r.get(END_POINT_NEWS, params=parametres_news)
          #######################################################

          # VÉRIFICATION DU SUCCÈS DE LA REQUÊTE ###########################################################################
          data =  rep_bis.json()

          if not("articles" in data):
               print(f"Erreur dans la requête sur l'année {annee}, le trimestre {trim}, le mois actuel {mois} et de l'entreprise {nom_compagnie} : ")
               print(data)
               return data
          ##################################################################################################################

          # RÉCUPÉRATION DES ARTICLES ###########################################################################
          data = data["articles"]
          #print(data)
          
          for elt in data[0:4]:
                    liste_actu.append([elt["title"], elt["source"]["name"], 
                                       elt["description"], elt["content"], 
                                       elt["publishedAt"], elt["url"]])
          #######################################################################################################
                    
          # ON METS UNE PAUSE POUR ÉVITER D'AVOIR UN BLOCAGE QUAND ON FAIT TROP VITE LES REQUÊTES ###############################
          delay = timedelta(seconds=1)
          endtime = datetime.now() + delay
          while datetime.now() < endtime:
                         pass
          ##################################################################################################################

          ###################################################################################################################

          # RETOUR DES ARTICLES 'PERTINENTS'
          return liste_actu
          ##################################################################################################################

    ################################################################

#################################################################################################################
#################################################################################################################

     @staticmethod
     def collecte_deux_derniere_annees(cles_action, cles_news, nom_compagnie, nom_action):
          """
          Cette méthode statique permet de récupérer les valeurs mensuelles de l'action et les articles 'pertinents' de l'entreprise sur les deux dernières années.
          On a comme argument :
          - cles_action : ID pour l'API Alpha Vantage pour la collecte des actions
          - cles_news : ID pour l'API GNews pour la collecte des articles
          - nom_compagnie : nom de l'entreprise
          - nom_action : symbole boursier de l'entreprise

          Il exporte les données récupérées dans des fichiers CSV qui sont réparties dans deux dossier qui sont 'action' et 'actu'.
          """

          ## RÉCUPÉRATION DES ACTIONS CONCERNANT L'ENTREPRISE ######################################################
          liste = ProcesseurDonnees.collecte_actions(
                                    cles_action,
                                    nom_action, 
                                    int(datetime.now().strftime("%Y"))-2, 
                                    int(datetime.now().strftime("%Y")))


          ## SI ÉCHEC DE L'OPÉRATION ################################################################################
          #print(type(liste))
          if type(liste) != list:
                return liste
          ###########################################################################################################

          ## CRÉATION D'UNE DATAFRAME ET EXPORTATION DES DONNÉES VERS UN FICHIER CSV ################################
          dataset = pd.DataFrame(liste, columns=["open", "hight", "low", "close", "volume", "date"])
          dataset.to_csv("Donnees/action/"+nom_compagnie+"_"+nom_action+".csv", index=False)
          ##########################################################################################################

    ##########################################################################################################

          ## RÉCUPÉRATION DES ACTUALITÉS CONCERNANT L'ENTREPRISE ##################################################
          print(f"Partie calcul de la variance de l'action sur l'entreprise {nom_compagnie}")
          
          ## RÉCUPÉRATION DES DONNÉES SUR LES VALEURS DE FERMETURE DE L'ACTION DE L'ENTREPRISE ET DE LA DATE + CALCUL DE LA VARIANCE ########################
          
          data = pd.read_csv("Donnees/action/"+nom_compagnie+"_"+nom_action+".csv") # Lecture des données

          data = data[["date", "close"]] # Sélection des colonnes d'intérêts
          
          data = data.to_records(index=False) # Transformation en une liste de liste

          var = ProcesseurDonnees.calcul_var_desc(data) # Récupération d'une liste sur les variances des actions
          ###################################################################################################################################################

          # CRÉATION D'UN DICTIONNAIRE AVEC COMME CLÉS LES ANNÉES ET LEURS VALEURS QUI SONT VIDES POUR LE MOMENT
          annee_trim = {
                       str(int(datetime.now().strftime("%Y"))-2) : "",
                       str(int(datetime.now().strftime("%Y"))-1) : "",
                       str(datetime.now().strftime("%Y")) : ""
                 } # Il servira de repère pour savoir dans quelle trimestre nous sommes actuellement et en quelle année
          ######################################################################################################
          
          # PARTIE COLLECTE SELON LA VARIANCE MENSUELLE ########################################################
          print(f"Partie collecte des articles 'pertinents' de l'entreprise {nom_compagnie}.")
          dataset = []

          for elt in var:
               #print(elt)

               # Vérification si la valeur absolue de la variance est supérieure à 5 %
               if abs(elt[3]) > 5:

                    # On récupère le mois concernant la variation
                    mois_actuel = elt[2].split("-")[1]
                    
                    #print(mois_actuel)
                    #print(annee_trim[elt[0]])
               #########################################################################
                    
                    # Vérification si on n'a pas déjà visité l'année et le trimestre où se trouve le mois actuel
                    if annee_trim[elt[0]]!="":
                         
                         # Dans le cas où le trimestre a déjà été visité
                         if mois_actuel in ProcesseurDonnees.trimestre[annee_trim[elt[0]]]:
                            pass
                         
                         # Dans le cas où le trimestre n'a pas encore été visité
                         else:
                               # Application de la collecte
                               dataset+=ProcesseurDonnees.collecte_actu(
                                   cles_news,
                                   nom_compagnie,
                                   nom_action,
                                   mois_actuel,
                                   elt[0])
                              
                              ## SI ÉCHEC DE L'OPÉRATION ################################################################################
                               #print(type(liste))
                               if type(liste) != list:
                                    return liste
                              ###########################################################################################################
                               
                               # Ajout du trimestre que nous avons visité 
                               for keys in ProcesseurDonnees.trimestre:
                                   if mois_actuel in list(ProcesseurDonnees.trimestre[keys].keys()):
                                        annee_trim[elt[0]] = keys
                    
                    # Dans le cas où l'année n'a pas encore été visitée
                    else:
                              # Application de la collecte
                              dataset+=ProcesseurDonnees.collecte_actu(
                                   cles_news,
                                   nom_compagnie,
                                   nom_action,
                                   mois_actuel,
                                   elt[0])

                         ## SI ÉCHEC DE L'OPÉRATION ################################################################################
                              #print(type(liste))
                              if type(liste) != list:
                                   return liste
                         ###########################################################################################################
                              
                              # Ajout du trimestre que nous avons visité 
                              for keys in ProcesseurDonnees.trimestre:
                                   if mois_actuel in list(ProcesseurDonnees.trimestre[keys].keys()):
                                        annee_trim[elt[0]] = keys

          #print(dataset)       
          # PARTIE EXPORTATION VERS UN FICHIER CSV #####################################################################
          dataset = pd.DataFrame(dataset, columns=["title", "homepage", "description", "content", "publishedAt", "URL"])

          dataset.to_csv("Donnees/actu/"+nom_compagnie+".csv", index=False)
          ##############################################################################################################

          print(f"Collecte réussie pour l'entreprise {nom_compagnie}  avec l'action {nom_action}")
          ##########################################################################################################

     @staticmethod
     def calcul_var_desc(data):
          """
          Cette méthode statique permet de calculer la variance des valeurs d'une action sur la fermeture pour chaque mois en ayant comme argument : 
          - data : [[date, valeur_fermeture]...] (triés dans l'ordre décroissante)

          Cela permet de retourner une liste de liste appelée var contenant les éléments suivants :
          - var : [[année, date_mois_avant, date_mois_après, variation %], ...] 
          """
          # INITIALISATION
          var = []
          ################

          # PARCOURS DES ÉLÉMENTS DE LA LISTE DATA ###############
          for ind in range(len(data)):

               # Vérification la date n'est pas du mois de janvier
               if not("-01-" in data[ind][0]) :
                    
                    #print(data[ind])

                    # Calcul de la variation
                    nb = data[ind][1]-data[ind+1][1]

                    # Ajout des différentes informations dans la liste var
                    var.append([
                    data[ind][0].split("-")[0], 
                    data[ind+1][0], 
                    data[ind][0],
                    round(nb/data[ind+1][1]*100, 2)
                    ])
                    # [année, date_mois_avant, date_mois_après, variance %]
          ##################################################################
                    
          # Retourne la liste des variances
          return var
###################################################################



if __name__=="__main__":
      print(ProcesseurDonnees.collecte_actu(CLE_API_GNEWS,"Tesla", "TSLA", "01", 2023))
      print(ProcesseurDonnees.collecte_actions(CLE_API_STOCK, "TSLA", 2021, 2023))
      ProcesseurDonnees.collecte_deux_derniere_annees(CLE_API_STOCK, CLE_API_GNEWS, "Tesla", "TSLA")
      