import Package.package_collecte as pc
import os 
import Package.Affichage as aff
import Package.Insertion as ins
import Package.Classe_SQL as csql
import datetime as d

# DICTIONNAIRE DES COMPAGNIES AVEC LEUR SYMBOLE BOURSIER À TRAVAILLER DESSUS ########################
entreprises = {
    "Tesla" : "TSLA",
    "Netflix" : 'NFLX',
    "Amazon" : "AMZN",
    'Apple' : "AAPL",
    "Microsoft" : "MSFT"
}

# Préparation des noms et actions de l'entreprise
nouv_entreprises = {}
for ent in entreprises:
      # Nom de l'entreprise
      ent = ent.lower()
      maj = ent[0].upper()
      ent = maj+ent[1:]

      # Symbole boursier
      entreprises[ent] = entreprises[ent].upper()
      
      # Ajout des noms d'entreprises et symbole
      nouv_entreprises[ent] = entreprises[ent]

###################################################################

# CRÉATION DES DOSSIERS DONNEES, ACTU, ACTION #######################
if not os.path.exists("./Donnees"):
        os.makedirs("./Donnees")

if not os.path.exists("./Donnees/actu"):
        os.makedirs("./Donnees/actu")

if not os.path.exists("./Donnees/action"):
        os.makedirs("./Donnees/action")
###############################################################################

# CLÉS API POUR LA COLLECTE DE DONNÉES (CHANGER SI NÉCESSAIRE) ################
CLE_API_GNEWS = "710e62f98f759727738478e60ba71697"
CLE_API_STOCK = "44YEJNO9SB02CF0Q"
###############################################################################

# ÉTAPE 1 : COLLECTE DES DONNÉES SUR LES ENTREPRISES ########################
def actu_action_collecte_entreprise_deux_dernieres_annees(entreprises):
    """
    On procède à la collecte des données de plusieurs entreprises avec chacune d'elle une action. Pour cela, on aura besoin d'un seul argument qui est :
    - entreprises : dictionnaire contenant les entreprises en mots-clés avec leur action associé

    Nous allons nous servir des fonctions du package collecte qui va nous aider donc à la collecte de données. 
    Pour voir plus détails, aller voir le package collecte.

    Cela permet de créer les différents fichiers CSV que nous avons besoin pour l'insertion.
    """

    for ent in entreprises:
        print(f"Collecte de données pour l'entreprise {ent} et son action {entreprises[ent]}")
        verf = pc.ProcesseurDonnees.collecte_deux_derniere_annees(CLE_API_STOCK, CLE_API_GNEWS, ent, entreprises[ent])
        if verf != None:
              print(verf)
        print("\n")
####################################################################
        
actu_action_collecte_entreprise_deux_dernieres_annees(nouv_entreprises)

# ÉTAPE 2 : INITIALISATION ET INSERTION DE LA BASE DE DONNÉES #############################
print("\nInsertion des données dans la base")
csql.BDDManager.initialisation()
ins.insertion_csv_sqlite("Donnees/action", "entreprise")
ins.insertion_csv_sqlite("Donnees/actu", "actu")
ins.insertion_csv_sqlite("Donnees/action", "action")
###########################################################################################

# PARTIE VÉRIFICATION (POUR L'INTERFACE) #####################################################################
def verification_int(chiffre, annee_mois):
      """
      Cette fonction permet de vérifier si l'utilisateur a donné un argument valide pour l'année et le mois. 
      Elle aura besoin de deux arguments qui sont :
      - chiffre, nombre à vérifier qui est de type str
      - annee_mois, permet de préciser si la valeur de 'chiffre' est une année ou un mois

      Elle retourne 'OK' pour dire que c'est bon, sinon elle retourne l'origine de l'erreur.
      """
      try:
            # Conversion en nombre du chiffre
            chiffre = int(chiffre)

            # DANS LE CAS DES ANNÉES ##############################################################################################   
            if annee_mois == "annee":
                  # Année actuelle
                  annee = int(d.datetime.now().strftime("%Y"))

                  # Dans le cas d'une année qui date de plus de deux ans par rapport à l'année actuelle
                  if chiffre < annee-2 :
                        return f"L'année demandé est beaucoup trop loin. Les années possibles sont entre {annee-2} et {annee}."

                  # Dans le cas d'une année supérieure à l'année actuelle
                  elif chiffre > annee:
                        return f"L'année demandé n'est pas passée encore. Les années possibles sont entre {annee-2} et {annee}."
                  
                  # Dans le cas que l'année inscrite par l'utilisateur est bonne
                  else:
                        return "OK"
            ########################################################################################################################
            
            # DANS LE CAS DES MOIS ############################################################################################## 
            elif annee_mois == "mois":

                  # Dans le cas d'un mois supérieure à 12 ou inférieure à 1
                  if chiffre > 12 or chiffre < 1:
                        return f"Le mois demandé est impossible. Les mois sont entre 1 et 12."
                  
                  # Dans le cas que le mois inscrit par l'utilisateur est bon
                  else:
                        return "OK"
            ####################################################################################################################
                  
      # SI 'CHIFFRE' NE PEUT PAS ÊTRE CONVERTIE EN INT, ALORS ON A DES CARACTÈRES QUI NE SONT PAS DES NOMBRES
      except ValueError or TypeError:
            return "Des caractères détectés qui ne sont pas des chiffres ou que vous n'avez rien mis."
      ################################################################################################
#####################################################################################################################
      
# ÉTAPE 3 ET 4 : IHM (MODE CONSOLE) ET AFFICHAGE HTML ########################
def options_ent():
      """
      Cette fonction permet de communiquer avec l'utilisateur pour lui donner plusieurs options dont chacun d'elle aura un affichage console et un affichage HTML unique.
      Elle n'a besoin d'aucun argument et ne retourne rien.
      """

      # INITIALISATION ##########
      fini = False
      ###########################

      # PARTIE INTERFACE ########
      while fini == False:

            # PARTIE DES OPTIONS PRINCIPALES #######################################################
            liste_ent = csql.Entreprise.liste_entreprises(index=False)
            opt = input("""
                 Bonjour, veuillez choisir l'une de ces options en mettant le numéro correspondant :
                 1- Lister les entreprises 
                 2- Afficher les données mensuelles
                 3- Afficher les variations mensuelles
                 4- Afficher les articles pertinents
                 5- Quitter
                        """)
            ########################################################################################

            # ARRÊT DE LA CONSOLE
            if opt=="5":
                  fini = True
                  print("Nous allons arrêter l'interaction.\n")
                  return "Arrêt"
            #####################
            
            # LISTER LES ENTREPRISES
            elif opt=="1":
                  aff.option1()
            ########################
            
            elif opt=="2" or opt=='3'or opt=='4':

                  # DEMANDE DU NOM DE L'ENTREPRISE OU NOM DE L'ACTION
                  ent = input(f"Veuillez préciser l'entreprise dont vous voulez avoir les données pour l'option {opt}. \nListe des entreprises possibles : {liste_ent} \n")
                  
                  if ent=="":
                        print(f"Vous n'avez rien marqué, nous allons mettre par défaut {liste_ent[0][0]}")
                        ent=liste_ent[0][0]

                  else:
                        maj_ent = ent[0].upper()
                        min_ent = ent[1:].lower()
                        ent = maj_ent+min_ent
                  ################################
                  
                  # VÉRIFICATION SI L'ENTREPRISE EXISTE DANS LA BASE ##############
                  verf = aff.entreprise_existe(ent)
                  
                  # Dans le cas qu'elle n'existe pas pour le nom de l'entreprise
                  if verf != True:
                        
                        # VÉRIFICATION SI L'ACTION EXISTE DANS LA BASE ##############
                        ent = ent.upper()
                        verf = aff.entreprise_existe(ent)

                        # CAS DE LA NON EXISTENCE DANS LE NOM D'ENTREPRISE ET D'ACTION
                        if verf[0] != True:
                              print(f"""
                              Erreur sur l'inscription de l'entreprise avec '{ent}'.
                              Veuillez mettre un argument valide la prochaine fois. 
                              L'entreprise sera par défaut {verf}.
                              Origine de l'erreur : L'entreprise ou l'action qui a été mise n'existe pas dans la base de données
                              """)
                              ent = verf

                        # Cas où l'utilisateur donne le nom de l'action qui est existant, on associe le nom de l'entreprise qui a cette action
                        else:
                         ent = verf[1]
                        ###################################################################
                        
                  # DEMANDE L'ANNÉE
                  annee = input("Préciser l'année en chiffre (YYYY) en sachant que ça doit être sur les deux dernières années avec l'année actuelle \n")
                  #################

                  # VÉRIFICATION DE L'ANNÉE
                  verf = verification_int(annee, "annee")
                  # Dans le cas où il y a une erreur dans l'inscription de l'année
                  if verf != "OK":
                        print(f"""
                              Erreur sur l'inscription de l'année avec '{annee}', 
                              veuillez mettre un argument valide la prochaine fois. 
                              L'année sera par défaut {d.datetime.now().strftime("%Y")}.
                              Origine de l'erreur : {verf}
                              """)
                        
                        annee = d.datetime.now().strftime("%Y")

                  # AFFICHER LES DONNÉES MENSUELLES D'UNE ENTREPRISE
                  if opt=="2":

                  # PARTIE SOUS-OPTION ###############################################################
                  
                  # DEMANDE SI ON DOIT RECHERCHER SUR L'ANNÉE COMPLÈTE ou SUR UN MOIS PRÉCIS
                        yes_no = input("""
                                 Voulez-vous : 
                                 1- Trouver les données mensuelles sur l'année complète
                                 2- Trouver sur un mois précis
                                 """)
                  ##########################################################################

                        # RECHERCHE SUR UN MOIS PRÉCIS ###########################################
                        if yes_no=="2":
                              # DEMANDE LE MOIS
                              mois = input("Veuillez préciser le mois en chiffre \n")
                              #################

                              # VÉRIFICATION DU MOIS
                              verf = verification_int(mois, "mois")

                              # S'IL Y A UNE ERREUR DANS L'INSCRIPTION DU MOIS
                              if verf!= "OK":
                                    print(f"""
                              Erreur sur l'inscription du mois avec '{mois}', 
                              veuillez mettre un argument valide la prochaine fois. 
                              Le mois par défaut sera janvier (01).
                              Origine de l'erreur : {verf}
                              """)
                                    mois = "01"
                              ###############################################
                              
                              # DANS LE CAS DES MOIS QUI N'ONT QU'UN SEUL CHIFFRE (1, 2, ..., 9)
                              if len(mois) == 1 :
                                    mois = "0"+mois

                              # APPEL DE LA FONCTION D'AFFICHAGE 
                              aff.option2_annee_mois(ent, annee, mois)
                              ###########################################################
                  
                        # DANS LE CAS D'UNE ANNÉE COMPLÈTE ########################
                        elif yes_no == "1":
                              # APPEL DE LA FONCTION D'AFFICHAGE
                              aff.option2_annee(ent, annee)
                        ###########################################################
                  
                        # DANS LE CAS OÙ IL Y A UNE ERREUR
                        else: 
                              print("Veuillez mettre une commande valable à ce qu'il est demandé en précisant le numéro correspondant.\n")
                        ##################################
                        
                  #####################################################################################################
            
                  # AFFICHER LES VARIATIONS MENSUELLES D'UNE ENTREPRISE
                  elif opt=="3":
                        # APPLICATION DE LA FONCTION D'AFFICHAGE
                        aff.option3(ent, annee)
                  ####################################################################################


                  # AFFICHER LES ARTICLES 'PERTINENTS'
                  elif opt=="4":
                        # APPLICATION DE LA FONCTION D'AFFICHAGE
                        aff.option4(ent, annee)
                  ####################################################################################
                        
            # DANS LE CAS D'UNE COMMANDE NON VALIDE
            else:
                print("Veuillez mettre une commande valable à ce qu'il est demandé en précisant le numéro.\n")  
            ####################################################################################
                
            # DEMANDE DE CONTINUER L'INTERACTION
            cont = input("Voulez-vous continuer ? \n 1- OUI \n 2- NON \n")

            if  cont == "2":
                  fini = True
                  print("Nous allons arrêter l'interaction.\n")

            elif cont == "1":
                  print("Nous allons continuer l'interaction.\n")
            
            else:
                  print("Veuillez mettre une commande valable à ce qu'il est demandé en précisant le numéro.\n")
                  print("Nous allons continuer l'interaction.\n")
            ################################################################
###################################################################

options_ent()