Pour lancer les programmes, 
veuillez exécuter le script main.py en modifiant les noms des entreprises 
avec leur symbole boursier dans le dictionnaire et les clés d'API.