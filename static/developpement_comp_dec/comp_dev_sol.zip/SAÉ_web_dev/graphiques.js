/*
    Ce script contient le code Javascript qui permet à de créer les graohqiues ainsi que transformer les données brutes récupérées à travers le serveur local.
*/


// BLOC A : retards des trains

var blocadata = JSON.parse(document.getElementById("bloca").textContent);

var departures = [];
var arrivals = [];

blocadata.forEach(entry => {
    departures.push(entry.nbrderetards[0]); 
    arrivals.push(entry.nbrderetards[1]); 
});


const diag1 = {
    type: "bar",
    data: {
        labels: ["2015", "2016", "2017", "2018", "2019", "2020"],
        datasets: [{
                label: 'Départures',
                borderColor: "white",
                borderWidth: 0.5,
                hoverBorderColor: "black",
                backgroundColor: '#7F2071',
                hoverBackgroundColor: "#7F207180",
                data: departures
            },
            {
                label: 'Arrivées',
                borderColor: "white",
                borderWidth: 0.5,
                hoverBorderColor: "black",
                backgroundColor: '#DF1C2A',
                hoverBackgroundColor: "#DF1C2A80",
                data: arrivals
            }
        ]
    },
    options: {
        responsive: false,
        scales: {
            y: {
                beginAtZero: true,
                stacked: true,
                grid: {
                    display: false // Remove y-axis gridlines
                },
                ticks: {
                    color: 'black' // Change the color of y-axis labels here
                }
            },
            x: {
                stacked: true,
                grid: {
                    display: false // Remove x-axis gridlines
                },
                ticks: {
                    color: 'black' // Change the color of x-axis labels here
                }
            }
        },
        plugins: {
            title: {
                display: true,
                text: "Retards des trains par année",
                position: "top",
                color: "black",
                font: {
                    size: 20,
                    family: "Georgia, serif",
                    weight: "bold",
                    lineheight: 1.5
                },
                padding: {
                    bottom: 5
                }
            },
            legend: {
                display: true,
                position: "bottom",
                labels: {
                    color: "#000000",
                    font: {
                        size: 11,
                        weight: "bold",
                        family: "Georgia, serif"
                    }
                }
            }
        },
        tooltip: {
            enabled: true,
            backgroundColor: "black",
            titleColor: "white",
            bodyColor: "black",
            titleFont: { weight: 'bold' },
            bodyFontSize: 14,
            padding: 10,
            cornerRadius: 10,
            borderWidth: "0.5",
            xAlign: "left",
            callbacks: {
                label: function(tooltipItem, data) {
                    var datasetLabel = data.datasets[tooltipItem.datasetIndex].label || '';
                    var value = data.datasets[tooltipItem.datasetIndex].data[tooltipItem.index];
                    var explanation = "This is an explanation of the data.";
                    return datasetLabel + ': ' + value + ' - ' + explanation;
                }
            }
        }
    }
};

// Afficher le diagramme 1
const affdiag1 = new Chart(
    document.getElementById("diag1"),
    diag1
);


// BLOC B I : gares et retards
// Départs

var blocb1data = JSON.parse(document.getElementById("blocb1").textContent);

let labelsb2i = blocb1data.nom_gare; 
// console.log(labelsb2i);
let datadiag2i = blocb1data.retards_depart; 

 
const diag2a = {
    type: "bar",
    data: {
        labels: labelsb2i,
        datasets: [{
            borderColor: "white",
            borderWidth: 0.5,
            hoverBorderColor: "black",
            backgroundColor: '#7F2071',
            hoverBackgroundColor: "#7F207180",
            data: datadiag2i
        }]
    },
    options: {
        responsive: false,
        indexAxis: 'y', 
        scales: {
            x: {
                beginAtZero: true, 
                ticks: {
                    font: {size: 7},
                    color : "black"
                },
                grid: {
                    display: false // Remove x-axis gridlines
                }
            },
            y: {
                ticks: {
                    font: {size: 7},
                    color : "black" 
                },
                grid: {
                    display: false 
                }
            }
        },
        plugins: {
            title: {
                display: true,
                text: "Top 5 : Gares les plus affectées par des retards (au départ)",
                position: "top",
                color: "black",
                font: {
                    size: 9,
                    family: "Georgia, serif",
                    weight: "bold",
                    lineheight: 1.5
                },
                padding: {
                    bottom: 1
                }
            },
            tooltip: { 
                enabled: true, 
                backgroundColor: "black", 
                titleColor: "white", 
                bodyColor: "white", 
                titleFont: { weight: 'bold' }, 
                bodyFontSize: 14,
                padding: 10, 
                cornerRadius: 10, 
                borderWidth: "0.5", 
                xAlign: "left" 
            },
            legend: {
                display: false // cacher la légende
            }
        }
    }
};


// Afficher le diagramme 2a
const affdiag2 = new Chart(
document.getElementById("diag2a"),
diag2a
);



// Arrivées
var blocb2data = JSON.parse(document.getElementById("blocb2").textContent);

let labelsb2ii = blocb2data.nom_gare; 
// console.log(blocb2data);
let datadiag2ii = blocb2data.retards_arrivee; 

const diag2b = {
    type: "bar",
    data: {
        labels: labelsb2ii,
        datasets: [{
            borderColor: "white",
            borderWidth: 0.5,
            hoverBorderColor: "black",
            backgroundColor: '#DF1C2A',
            hoverBackgroundColor: "#DF1C2A80",
            data: datadiag2ii
        }]
    },
    options: {
        responsive: false,
        indexAxis: 'y', 
        scales: {
            x: {
                beginAtZero: true, 
                ticks: {
                    font: {size: 7},
                    color : "black"
                },
                grid: {
                    display: false // Remove x-axis gridlines
                }
            },
            y: {
                ticks: {
                    font: {size: 7},
                    color : "black" 
                },
                grid: {
                    display: false 
                }
            }
        },
        plugins: {
            title: {
                display: true,
                text: "Top 5 : Gares les plus affectées par des retards (à l'arrivée)",
                position: "top",
                color: "black",
                font: {
                    size: 9,
                    family: "Georgia, serif",
                    weight: "bold",
                    lineheight: 1.5
                },
                padding: {
                    bottom: 1
                }
            },
            tooltip: { 
                enabled: true, 
                backgroundColor: "black", 
                titleColor: "white", 
                bodyColor: "white", 
                titleFont: { weight: 'bold' }, 
                bodyFontSize: 10,
                padding: 10, 
                cornerRadius: 10, 
                borderWidth: "0.5", 
                xAlign: "left" 
            },
            legend: {
                display: false // cacher la légende
            }
        }
    }
};


// Afficher le diagramme 2b
const affdiag2b = new Chart(
    document.getElementById("diag2b"),
    diag2b
    );




/* Récupérer l'année */
var annee = document.getElementById("annee").textContent;
console.log(annee);

// BLOC C : 

// Données arrivées
var dataarr = JSON.parse(document.getElementById("bloc3a").textContent);
// console.log(dataarr);

// Données départs
var datadep = JSON.parse(document.getElementById("bloc3b").textContent);



// Graphe linéaire arrivées
dataarrlabel = ["Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"];

dataarrdata = dataarr.map(info => parseInt(info.nbr_total_retards));


const diag3a = {
    type: "line",
    data: {
        labels: dataarrlabel,
        datasets: [{
            data: dataarrdata,
            borderColor: "black",
            borderDash: [10],
            borderWidth: 0.5,
            backgroundColor: "red", 
            fill: {
                target: "origin",
                above: "#faebd780" 
            },
            pointBackgroundColor: ['red'],
            pointHoverBorderRadius: 3,
            pointHoverBorderWidth: 3,
            pointHoverRadius: 3,
            pointHitRadius: 2,
            pointRadius: 5,
            label: false 
        }]
    },
    options: {
        responsive: false,
        scales: {
            y: {
                beginAtZero: true,
                stacked: true,
                grid: {
                    display: true 
                },
                ticks: {
                    color: 'black' 
                }
            },
            x: {
                stacked: true,
                grid: {
                    display: false 
                },
                ticks: {
                    color: 'black' 
                }
            }
        },
        plugins: {
            legend: {
                display: false 
            }
        }
    }
};


  
  const canvasline1 = new Chart(
    document.getElementById("diag3a"),
    diag3a
  );



// Graphe linéaire départs
dataarrlabel = ["Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"];

datadepdata = datadep.map(info => parseInt(info.nbr_total_retards));


const diag3b = {
    type: "line",
    data: {
        labels: dataarrlabel,
        datasets: [{
            data: datadepdata,
            borderColor: "black",
            borderDash: [10],
            borderWidth: 0.5,
            backgroundColor: "purple", 
            fill: {
                target: "origin",
                above: "#faebd780" 
            },
            pointBackgroundColor: ['red'],
            pointHoverBorderRadius: 3,
            pointHoverBorderWidth: 3,
            pointHoverRadius: 3,
            pointHitRadius: 2,
            pointRadius: 5,
            label: false 
        }]
    },
    options: {
        responsive: false,
        scales: {
            y: {
                beginAtZero: true,
                stacked: true,
                grid: {
                    display: true 
                },
                ticks: {
                    color: 'black' 
                }
            },
            x: {
                stacked: true,
                grid: {
                    display: false 
                },
                ticks: {
                    color: 'black' 
                }
            }
        },
        plugins: {
            legend: {
                display: false 
            }
        }
    }
};


  
  const canvasline2 = new Chart(
    document.getElementById("diag3b"),
    diag3b
  );





// BLOC D : RÉPARTITION EN POURCENTAGE DES CAUSES DE RETARDS SELON LE MOIS + COMMENTAIRE SUR LES RETARDS
/********************************* POUR LE CAS DU BLOC D */
var donnees_pie = document.getElementById("blocd").textContent;
donnees_pie = JSON.parse(donnees_pie);
//console.log(donnees_pie);

function graph_circ(cause, donnees, id){
  var data2={
    labels: donnees.mois,
    datasets: [
      {
        data: donnees.prct_moy[cause],
        backgroundColor: [
          "rgba(110, 30, 120, 0.9)", 
          "rgba(161, 0, 107, 0.85)", 
          "rgb(205, 0, 55)", 
          "orange",
          "rgb(130, 190, 0)",
          "rgb(160, 160, 160)",
          "rgb(0, 136, 206)",
          "black",
          "rgb(0, 154, 166)",
          "rgba(66, 55, 50, 0.85)",
          "pink",
          "purple"
     ],
        borderWidth:1,
        hoverBackgroundColor: "#ffffff",
        hoverBorderColor: "black"
      },
    ]
  };
  
  var config2 = {
    type: 'pie',
    data: data2,
    options: {
      responsive: false,
      plugins: {
        legend: {
          display: false,
        },
        title: {
          display: true,
          text: cause,
          color: "black",
          font: {
            size: 10,
            family: "Georgia, serif",
            weight: "bold",
            lineheight: 1.5
        }
        },
        tooltip: {
            backgroundColor: "black",
            titleFont: {
                size: 10, 
                family: "Georgia, serif"
            },
            bodyColor: "white",
            bodyFont: {
                size: 10,
                family: "Georgia, serif"
            },
            borderColor: "#ffffff",
            borderWidth: 0.05,
            footerFont: {
                size: 8, 
                family: "Georgia, serif"
            },
          callbacks: {
            title: function(tooltipItem) {

              //console.log(tooltipItem)

              var de_d = "";
              if(tooltipItem[0].label == "Avril" || tooltipItem[0].label == "Août" || tooltipItem[0].label == "Octobre"){
                de_d = "d'";
              }
              else{
                de_d = "de ";
              }
              var label = "Pour le mois "+de_d+tooltipItem[0].label.toLowerCase()+" : ";
              return label;
          },
          label: function(tooltipItem){
            //console.log(tooltipItem)
            var label = "On a "+tooltipItem.formattedValue+" % des retards concernés";
            return label;
          },
          footer: function(){
            return "Pour le motif '"+cause+"' en "+annee;
          }
              }
          }}
      }
  };
  
      const monChart2 = new Chart(
        document.getElementById(id),
        config2,
        
        );
}


/* Boucle for sur les différentes causes pour créer les camemberts */
for(cause in donnees_pie.prct_moy){
  let id = "";
  let split = cause.split(" ");
  for(mot in split){
    id = id + split[mot][0];
  }
  //console.log(id);
  graph_circ(cause, donnees_pie, id+"Pie");
}
/******************************************************************/

// BLOC E : RÉPARTITION DES RETARDS SELON LE SEUIL PAR MOIS
var donnees = document.getElementById("bloce").textContent;
donnees = JSON.parse(donnees);
//console.log(donnees);

const data = {
    labels: donnees.mois,
    datasets: [
      {
        label: 'Seuil de 15 minutes',
        data: donnees.seuil_15,
        backgroundColor: "rgba(110, 30, 120, 0.9)",
        borderColor: "white",
        borderWidth:0.5,
        hoverBorderColor:"black",
        hoverBackgroundColor: "#7F207180",
      },
      {
        label: 'Seuil de 30 minutes',
        data: donnees.seuil_30,
        backgroundColor: "rgba(161, 0, 107, 0.85)",
        borderColor: "white",
        borderWidth:0.5,
        hoverBorderColor:"black",
        hoverBackgroundColor: "#7F207180",
      },
      {
        label: 'Seuil de 60 minutes',
        data: donnees.seuil_60,
        backgroundColor: "rgb(205, 0, 55)",
        borderColor: "white",
        borderWidth:0.5,
        hoverBorderColor:"black",
        hoverBackgroundColor: "#7F207180",
      },
    ]
  };

//console.log(data);
const config = {
    type: 'bar',
    data: data,
    options: {
      plugins: {
        title: {
          display: true,
          text: "Répartition des seuils de retard en "+annee,
          position: "top",
                    color: "black",
                    font: {
                        size: 20,
                        family: "Georgia, serif",
                        weight: "bold",
                        lineheight: 1.5
                    },
                    padding: {
                        bottom: 5
                    }
        },
        legend: {
            display: true,
            position: "bottom",
            labels: {
                color: "#000000",
                font: {
                    size: 11,
                    weight: "bold",
                    family: "Georgia, serif"
                }
            }},
        tooltip: {
            backgroundColor: "black",
                titleFont: {
                    size: 10, 
                    family: "Georgia, serif"
                },
                bodyColor: "white",
                bodyFont: {
                    size: 10,
                    family: "Georgia, serif"
                },
                borderColor: "#ffffff",
                borderWidth: 0.05,

          callbacks: {
            title: function(tooltipItems){
              //console.log(tooltipItems);
              var de_d = "";
              if(tooltipItems[0].label == "Avril" || tooltipItems[0].label == "Août" || tooltipItems[0].label == "Octobre"){
                de_d = "d'";
              }
              else{
                de_d = "de ";
              }
              return "Pour le mois "+de_d+tooltipItems[0].label.toLowerCase()+" : ";
            },
            label: function(tooltipItem) {
              //console.log(tooltipItem)
              var label = "Nombre de trains ayant dépassé le seuil de "+tooltipItem.dataset.label.replace(/Seuil de /i, "") || '\n';

              if (label) {
                  label += ' : ';
              }
              label += tooltipItem.parsed.y; // Format de votre choix
              return label;
          }
              }
          }
      },

      responsive: false,
      scales: {
        x: {
          stacked: true,
          
          title: {
          text: "Mois",
          display: true,
        font: {
              size: 10,
              family: "Georgia, serif",
              weight: "bold",
              lineheight: 1.5
          },
        },
        beginAtZero: true,
        stacked: true,
        grid: {
            display: false // Remove y-axis gridlines
        },

        ticks: {
            color: 'black' // Change the color of x-axis labels here
        }
        },

        y: {
          stacked: true,
          title:{
          display: true,
          text: "Effectif",
          font: {
            size: 10,
            family: "Georgia, serif",
            weight: "bold",
            lineheight: 1.5
        },
          },
          beginAtZero: true,
          stacked: true,
          grid: {
              display: false // Remove y-axis gridlines
          },
          ticks: {
              color: 'black' // Change the color of x-axis labels here
          }
        }
      },
    }
      };

    /* Visualisation graphiques */
    const monChart = new Chart(
        document.getElementById('diag5'),
        config,
        
        );
/******************************************************************/

/* FONCTION D'AFFICHAGE */
function toggle_visibility(id) {
    var element = document.getElementById(id);
    //console.log(element);
    if (element.style.display == 'none') {
        element.style.display = 'block';
    } else {
        element.style.display = 'none';
    }
  }
