<!-- 
    BUT SD 2
    SAÉ Développement d'un composant d'une solution décisionnelle
    Par : Dalyop Yop, Renoult Julien
 -->

<?php
    define("HOST","localhost");
    define("USER","root");
    define("PASS","juju76460");
    define("PORT",3306);
    define("DBNAME","trains3");
?>