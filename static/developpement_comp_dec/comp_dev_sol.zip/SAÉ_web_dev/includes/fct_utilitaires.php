<!-- 
    Ce script contient les fonctions utilisées dans le développement du dashboard.
 -->

<!-- 
    BUT SD 2
    SAÉ Développement d'un composant d'une solution décisionnelle
    Par : Dalyop Yop, Renoult Julien
 -->


 <?php


/**
 * Fonction connect_db
 * 
 * Connexion à la base de données.
 *
 * @return mysqli|false Retourne l'objet de connexion à la base de données en cas de succès, ou false en cas d'échec.
 */
function connect_db() {
    // Paramètres de connexion à la base de données
    include_once("db_params.inc.php");

    // Établissement de la connexion à la base de données
    $conn = mysqli_connect(HOST, USER, PASS, DBNAME);

    // Vérification des erreurs de connexion
    if (mysqli_connect_error()) {
        // Affichage du message d'erreur et arrêt de l'exécution du script en cas d'échec de la connexion
        echo "Il y avait une erreur de connexion : " . "<br/>" . mysqli_connect_error();
        exit("<br/> Impossible de se connecter à la base de données.");
    }
    
    // Décommentez la ligne suivante si vous souhaitez afficher un message de succès lors de la connexion
    // echo "Connecté ^_^ <br/>";

    // Retourne l'objet de connexion à la base de données
    return $conn;
}


/**
 * Fonction request_db
 * 
 * Exécute/envoie des requêtes à/sur la base de données.
 *
 * @param string $req La requête SQL à exécuter.
 * @return array|bool Retourne un tableau associatif des résultats de la requête en cas de succès, ou false en cas d'échec.
 */
function request_db($req) {
    // Connexion à la base de données
    $conn = connect_db(); 

    // Vérification de la connexion
    if ($conn) {
        // Exécution de la requête
        $result = mysqli_query($conn, $req);
        
        // Vérification des erreurs de requête
        if ($result === false) {
            // Affichage du message d'erreur en cas d'échec de la requête
            echo "Il y avait une erreur :-( " . mysqli_error($conn);
        } else {
            // Récupération des données de la requête
            $data = mysqli_fetch_all($result, MYSQLI_ASSOC);
            // var_dump($data);
            // Retourne les données de la requête
            return $data;
        }

        // Fermeture de la connexion à la base de données
        mysqli_close($conn);
        // Retourne true pour indiquer que la requête a été exécutée avec succès
        return true;
    } else {
        // Retourne false si la connexion à la base de données a échoué
        echo "ERROR HERE";
        return false;
    }
}


/* CRÉATION DE LA FONCTION DE REQUÊTE SQL*/
/*************************************************/
/**
 * Exécute une requête SQL et renvoie le résultat obtenu (vide ou non).
 *
 * Cette fonction prend quatres paramètres dont deux optionnelles
 * et renvoie le résultat de la requête exécuté sous la forme d'un tableau associatif.
 *
 * @param string $req_sel La requête SQL (préparée).
 * @param connection $connection Permet la connection à la base de données.
 * @param array $data Une liste contenant les différents paramètres à utiliser.s
 * @param string $params Le type de ces paramètres.
 * @return array Un tableau associatif contenant les résultats de la requête.
*/
function mysqlrequest($req_sel, $connection, $data = [], $params = "") {
    /* 1ÈRE ÉTAPE : PRÉPARATION DE LA REQUÊTE */
    $stmt = mysqli_prepare($connection, $req_sel);
    if($stmt === false) {
        return "Erreur dans la préparation de la requête";
    }
    
    /* SI PRÉSENCE DE PARAMÈTRES ET QU'ILS SOIENT DE LA MÊME LONGUEUR */
    if($params <> "" AND $data <> [] AND strlen($params) == count($data)) {
        /* INSERTION DES PARAMÈTRES */
        mysqli_stmt_bind_param($stmt, $params, ...$data);
    }

    /* 2ÈME ÉTAPE : EXÉCUTION DE LA REQUÊTE */
    if(mysqli_stmt_execute($stmt)) {
        $res = mysqli_stmt_get_result($stmt);
        if($res === NULL) {
            return "Erreur dans l'exécution de la requête (avec paramètres)";
        }
        
        /* 3ÈME ÉTAPE : RÉCUPÉRATION DU RÉSULTAT SI BIEN EXÉCUTÉ DANS UN TABLEAU ASSOCIATIF */
        $donnees = mysqli_fetch_all($res, MYSQLI_ASSOC);

        /* 4ÈME ÉTAPE : ARRÊT DE LA CONNEXION DU STATEMENT */
        mysqli_stmt_close($stmt);

        /* 5ÈME ÉTAPE : RETOUR DES RÉSULTATS OBTENUS */
        return $donnees;
    } else {
        return "Erreur dans l'exécution de la requête";
    }
}
// Fonction modifiée - je l'ai modifié pour que je puisse la utiliser pour le bloc C.
// Aucune erreur provoquée - Yop
// Fonction re-utilisée pour le bloc C - tout le dashboard se met à jour lorsque l'année est changée. 

/*************************************************/




// Bloc D
/* CRÉATION D'UNE FONCTION SUR LA RÉCUPÉRATION DES POURCENTAGES MOYENS PAR CAUSE ET PAR MOIS */
/***************************************************************************/
/**
 * Récupération et traitement des données avec la base.
 * Cela concerne les tables retards, types_retards, trajets, periodes, details_retards et retards_types_retards.
 * 
 * Cette fonction prend deux paramètres
 * et renvoie le résultat des données sous un tableau associatif contenant :
 * [ 
 * mois : tableau indexé contenant les mois
 * prct_moy : tableau associatif  contenant en mots-clés le nom des causes et indique un tableau indexé contenant les pourcentages moyens de chaque mois 
 *]
 *
 * @param string $annee L'année demandée pour récupérer les données.
 * @param connection $connection Permet de se connecter à la base de données.
 * @return array Un tableau associatif contenant les données récupérées et traitées.
*/
function cause_annee($annee){
    /* PARTIE CONNECTION */
    $connection = connect_db();
    
    /* PARTIE REQUÊTAGE */
    $request_sel = "SELECT tr.description, p.mois, AVG(rtr.pourcentage) as moyenne FROM retards r 
    INNER JOIN retards_types_retards rtr ON rtr.id_retard = r.id_retard 
    INNER JOIN types_retards tr ON tr.id_type_retard = rtr.id_type_retard 
    INNER JOIN trajets t ON t.id_trajet = r.id_trajet 
    INNER JOIN periodes p ON p.id_date = t.id_date 
    INNER JOIN details_retards dr ON dr.id_retard = r.id_retard 
    WHERE p.annee = ?
    GROUP BY tr.description, p.mois
    ORDER BY tr.description, p.mois;";

    $result = mysqlrequest($request_sel, $connection, [$annee], "i");

    //var_dump($result);
    /////////////////////////////////////////////////

    /* PARTIE TRATEMENT */
    /* 1ÈRE ÉTAPE : INITIALISATION */
    // Ici, on va ajouter les informations dans deux tableaux différents

    // Création d'un tableau associatif qui va contenir les informations suivantes
    // [cause => [
    //          'janvier' => 2000, ...]]
    $chiffre_cause = [];
    $cause_act = "";

    /* 2ÈME ÉTAPE : AJOUT DES ÉLÉMENTS DANS LES TABLEAUX CORREPONDANTS */
    for($i = 0; $i < count($result); $i++){
        // POUR LA CAUSE ET LE MOIS
        //var_dump($result[$i]["mois"]);
        if($result[$i]["description"] != $cause_act){
        $chiffre_cause[$result[$i]["description"]] = [];
        $cause_act = $result[$i]["description"];
        }

        // POUR LE POURCENTAGE MOYEN ARRONDI
        $chiffre = round((float) $result[$i]["moyenne"], 2);
        $chiffre_cause[$result[$i]["description"]][] = $chiffre;

    }

    //var_dump($mois);
    //var_dump($chiffre_cause);

    /* 3ÈME : RÉUNION DES DEUX TABLEAUX DANS UN TABLEAU ASSOCIATIF */
    $donnees = [
        "mois" => [
            "Janvier",
            "Février",
            "Mars",
            "Avril",
            "Mai",
            "Juin",
            "Juillet",
            "Août",
            "Septembre",
            "Octobre",
            "Novembre",
            "Décembre"
        ],
        "prct_moy" => $chiffre_cause
    ];
    /////////////////////////////////////////////////

    // Fermeture de la connexion à la base de données
    mysqli_close($connection);

    //var_dump($donnees);
    
    /* 4ÈME ÉTAPE : RENVOIE DES DONNÉES RÉCUPÉRÉES ET TRAITÉES */
    return $donnees;
    /////////////////////////////////////////////////
}
/***************************************************************************/


/* CRÉATION D'UNE FONCTION SUR LA RÉCUPÉRATION DES COMMENTAIRES SUR LES RETARDS PAR MOIS*/
/***************************************************************************/
/**
 * Récupération et traitement des données concernant les commentaires sur les retards.
 * Cela concerne les tables retards, details_retards, trajets et periodes.
 * 
 * Cette fonction prend deux paramètres
 * et renvoie le résultat des données sous un tableau associatif contenant :
 * [
 * Janvier => [commentaire_1, ...],
 * ...
 * ]
 * 
 * @param string $annee L'année demandée pour récupérer les données.
 * @return array Un tableau associatif contenant les données récupérées et traitées.
 */
function commentaire_retard($annee){

    /* PARTIE CONNECTION À LA BASE DE DONNÉES */
    $connection = connect_db();

    /* PARTIE REQUÊTAGE */
    $request_sel = 'SELECT DISTINCT p.mois, dr.commentaire_retards FROM retards r
    INNER JOIN details_retards dr ON dr.id_retard = r.id_retard 
    INNER JOIN trajets t ON t.id_trajet = r.id_trajet 
    INNER JOIN periodes p ON p.id_date = t.id_date 
    WHERE p.annee = ? and dr.commentaire_retards <> ""
    GROUP BY p.mois, dr.commentaire_retards 
    ORDER BY p.mois ;';

    $result = mysqlrequest($request_sel, $connection, [$annee], "i");

    //var_dump($result);
    /////////////////////////////////////////////////

    /* PARTIE TRAITEMENT */

    /* 1ÈRE ÉTAPE : INITIALISATION */

    // Création d'un tableau associatif sur les mois
    $mois = [
        1 => "Janvier",
        2 => "Février",
        3 => "Mars",
        4 => "Avril",
        5 => "Mai",
        6 => "Juin",
        7 => "Juillet",
        8 => "Août",
        9 => "Septembre",
        10 => "Octobre",
        11 => "Novembre",
        12 => "Décembre"
    ];

    // Tableau associatif qui va contenir en mot-clé le mois et la valeur un tableau des commentaires de retards
    $donnees = [];
    $mois_actuel = "";
    for($i = 0; $i < count($result); $i++){
        if($mois[$result[$i]["mois"]] != $mois_actuel){
            $mois_actuel = $mois[$result[$i]["mois"]];
            $donnees[$mois_actuel] = [];
        }
        //var_dump($mois_actuel);
        array_push($donnees[$mois_actuel], $result[$i]["commentaire_retards"]);
    }
    //var_dump($donnees);

    // Fermeture de la connexion à la base de données
    mysqli_close($connection);

    return $donnees;
}
/***************************************************************************/


// Bloc E
/* CRÉATION DE LA FONCTION SUR LA RÉCUPÉRATION DES SEUILS SELON UNE ANNÉE */
/***************************************************************************/
/**
 * Récupération et traitement des données avec la base.
 * Cela concerne les tables retards, seuils_retards, trajets et periodes.
 * 
 * Cette fonction prend deux paramètres
 * et renvoie le résultat des données sous un tableau associatif contenant :
 * [ 
 * mois : tableau indexée contenant les mois
 * seuil_15 : tableau indexé contenant les effectifs des trains qui ont dépassé le seuil de retard de 15 minutes
 * seuil_30 : tableau indexé contenant les effectifs des trains qui ont dépassé le seuil de retard de 30 minutes
 * seuil_60 : tableau indexé contenant les effectifs des trains qui ont dépassé le seuil de retard de 60 minutes   
 *]
 *
 * @param string $annee L'année demandée pour récupérer les données.
 * @return array Un tableau associatif contenant les données récupérées et traitées.
*/
function seuil_annee($annee){

    /* PARTIE CONNECTION À LA BASE DE DONNÉES */
    $connection = connect_db();
    
    /* PARTIE REQUÊTAGE */
    $result = mysqlrequest("SELECT p.mois, sr.seuil, SUM(sr.nombre_trains) AS somme FROM retards r 
    INNER JOIN seuils_retards sr ON r.id_retard = sr.id_retard 
    INNER JOIN trajets t ON t.id_trajet = r.id_trajet 
    INNER JOIN periodes p ON p.id_date = t.id_date
    WHERE p.annee = ?
    GROUP BY p.mois, sr.seuil
    ORDER BY p.mois ;", $connection, [$annee], "i");

    //var_dump($result);
    /////////////////////////////////////////////////
    /* PARTIE TRATEMENT */
    /* 1ÈRE ÉTAPE : INITIALISATION */
    // Ici, on va ajouter les différents éléments dans deux tableaux séparés
    $chaine_mois = [];
    $seuil_15 = [];
    $seuil_30 = [];
    $seuil_60 = [];

    // Création d'un tableau associatif sur les mois
    $mois = [
            1 => "Janvier",
            2 => "Février",
            3 => "Mars",
            4 => "Avril",
            5 => "Mai",
            6 => "Juin",
            7 => "Juillet",
            8 => "Août",
            9 => "Septembre",
            10 => "Octobre",
            11 => "Novembre",
            12 => "Décembre"
        ];

    /* 2ÈME ÉTAPE : AJOUT DES ÉLÉMENTS DANS LES TABLEAUX CORREPONDANTS */
    for($i=0; $i < count($result); $i++){
        
        // VÉRIFICATION SI LE MOIS N'EST PAS DÉJÀ DANS LE TABLEAU CORRESPONDANT
        if(!in_array($mois[$result[$i]['mois']], $chaine_mois)){
            $chaine_mois[] = $mois[$result[$i]['mois']];
        }

        // AJOUT DES DIFFÉRENTES VALEURS DANS LES SEUILS CORRESPONDANTS
        switch($result[$i]["seuil"]){
            case 15:
                $seuil_15[] = (integer) $result[$i]["somme"];
                break;

            case 30:
                $seuil_30[] = (integer) $result[$i]["somme"];
                break;

            case 60:
                $seuil_60[] = (integer) $result[$i]["somme"];
                break;
        }

    }
    ////////////////////////////////////////////////////////////////////


    /* 3ÈME ÉTAPE : RÉUNION DES QUATRES TABLEAUX SOUS UN TABLEAU ASSOCIATIF */
    $donnees = [
        "mois" => $chaine_mois,
        "seuil_15" => $seuil_15,
        "seuil_30" => $seuil_30,
        "seuil_60" => $seuil_60
    ];
    ////////////////////////////////////////////////////////////////////////////
    
    // Fermeture de la connexion à la base de données
    mysqli_close($connection);
    
    //var_dump($donnees);

    /* 4ÈME ÉTAPE : RENVOIE DES DONNÉES RÉCUPÉRÉES ET TRAITÉES */
    return $donnees;
    /////////////////////////////////////////////////////////////

}








?>
