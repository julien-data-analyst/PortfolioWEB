<!-- 
    BUT SD 2
    SAÉ Développement d'un composant d'une solution décisionnelle
    Par : Dalyop Yop, Renoult Julien
 -->



<?php
//Configuration du comportement d'affichage des erreurs
//Afficher les erreurs sur la page avec la directive display_errors
// en passant 1 ou True
ini_set('display_errors', 1);
// signaler tous les types d'erreurs PHP qui pourraient survenir
//pendant l'exécution du script.
//E_ALL est une constante qui représente tous les types d'erreurs
//possibles: avertissements (warnings), les erreurs de syntaxe,
//les erreurs d'exécution
error_reporting(E_ALL);
//Rendre le temps d'exécution du script illimité
set_time_limit(0);

//Inclusion des paramètres de connexion
include_once("db_params.inc.php");

/**
 * Lecture d'un fichier CSV
 * @param mixed $nomFichier de type string: le nom du fichier à lire

 *@return array un tableau associatif 2D (un tableau de tableau où chaque ligne contient
des couples clé=>valeur, la clé c'est le descripteur)
 */
function lireFichierCSV($nomFichier) {
    // Chemin vers le répertoire où se trouve le fichier CSV
    // __DIR__ donne le chemin du dossier, sans slash final.
    //Par exemple, si votre script est dans /var/www/html/mon_script.php,
    // __DIR__ retournera /var/www/html.
    $cheminDuFichier = __DIR__ . '/Data/' . $nomFichier;

    //Tableau associatif contenant les données du fichier
    $tabContenu = array();

    // Vérifier si le fichier existe
    if (!file_exists($cheminDuFichier)) {
        throw new Exception("Le fichier $nomFichier n'existe pas dans le répertoire Data.");
    }

    // Ouvrir le fichier en lecture seule
    if (($id_file  = fopen($cheminDuFichier, "r")) === false) {
        throw new Exception("Impossible d'ouvrir le fichier $nomFichier.");
    }

    try {
        // Lire les en-têtes du fichier CSV
        //0 dans fgets indique qu'on va lire toute la ligne  quelle que soit sa longueur
        fgetcsv($id_file, 0, ",");
        // Lire le fichier ligne par ligne
        while (($ligne = fgetcsv($id_file, 0, ",")) !== false) {
            $ligneAssociative = [
                "Année" => (integer)$ligne[0],
                "Mois" => (integer)$ligne[1],
                "GareDepart" => $ligne[2],
                "GareArrivee" => $ligne[3],
                "TempsMoyenDeVoyage" => (double)$ligne[4],
                "NombreDeCirculationsPrevues" => (integer)$ligne[5],
                "NombreDeTrainsAnnules" => (integer)$ligne[6],
                "NombreDeTrainsEnRetardAuDepart" => (integer)$ligne[7],
                "RetardMoyenDesTrainsEnRetardAuDepart" => (double)$ligne[8],
                "RetardMoyenDeTousLesTrainsAuDepart" => (double)$ligne[9],
                "CommentaireSurLesRetardsAuDepart" => $ligne[10],
                "NombreDeTrainsEnRetardALArrivee" => (integer)$ligne[11],
                "RetardMoyenDesTrainsEnRetardALArrivee" => (double)$ligne[12],
                "RetardMoyenDeTousLesTrainsALArrivee" => (double)$ligne[13],
                "CommentaireSurLesRetardsALArrivee" => $ligne[14],
                //"PourcentageDeTrainsEnRetardDuADesCausesExternes" => (double)$ligne[15],
                //"PourcentageDeTrainsEnRetardDuAInfrastructureFerroviaire" => (double)$ligne[16],
                //"PourcentageDeTrainsEnRetardDuAGestionTrafic" => (double)$ligne[17],
                //"PourcentageDeTrainsEnRetardDuAuMaterielRoulant" => (double)$ligne[18],
                //"PourcentageDeTrainsEnRetardDuAGestionEtReutilisationDesEquipementsGare" => $ligne[19],
                //"PourcentageDeTrainsEnRetardDuAUTraficDesPassagers" => (double)$ligne[20],
                "NombreDeTrainsEnRetardDePlusDe15Min" => (integer)$ligne[21],
                "RetardMoyenDesTrainsDePlusDe15Min" => (double)$ligne[22],
                "NombreDeTrainsEnRetardDePlusDe30Min" => (integer)$ligne[23],
                "NombreDeTrainsEnRetardDePlusDe60Min" => (integer)$ligne[24],
                "Periode" => date('Y-m-d', strtotime($ligne[25])),
                "RetardCausesExternes" => $ligne[26],
                "RetardInfrastructureFerroviaire" => $ligne[27],
                "RetardGestionDuTrafic" => $ligne[28],
                "RetardMatérielRoulant" => $ligne[29],
                "RetardGestionEtReutilisationDesEquipementsGare" => $ligne[30],
                "RetardTraficDesPassagers" => $ligne[31]
            ];
            array_push($tabContenu, $ligneAssociative);
        }
    } catch (Exception $e) {
        // Gestion des exceptions pendant la lecture du fichier
        echo "Erreur lors de la lecture du fichier CSV : " . $e->getMessage();
    } finally {
        // Fermer le fichier dans tous les cas
        fclose($id_file);
        return $tabContenu;
    }
}


/**
 * Créer la base de données sous MySQL
 * @param mixed $nomBDD de type string: le nom du fichier à lire
 * @return void
 */
function creerBDD($nomBase) {
    try {
        //établir une connexion avec serveur sans utiliser une BDD
        $connexion = mysqli_connect(HOST,USER,PASS,'');

        // Créer la base de données
        $requete = "CREATE DATABASE IF NOT EXISTS ". $nomBase. " CHARACTER SET utf8 COLLATE utf8_general_ci";
        if (mysqli_query($connexion, $requete) === true){
            // Sélectionner la base de données créée
            mysqli_query($connexion, "USE ".$nomBase);

            // Créer la table `gares`
            mysqli_query($connexion,"CREATE TABLE IF NOT EXISTS gares (
                        id_gare  INT AUTO_INCREMENT PRIMARY KEY,
                        nom_gare VARCHAR(255) UNIQUE NOT NULL
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci");

            // Créer la table dates ou periodes
            mysqli_query($connexion,"CREATE TABLE IF NOT EXISTS periodes (
                        id_date  INT AUTO_INCREMENT PRIMARY KEY,
                        mois INT NOT NULL,
                        annee INT NOT NULL
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci");

            // Créer la table `trajets`
            mysqli_query($connexion,"CREATE TABLE IF NOT EXISTS trajets (
                        id_trajet  INT AUTO_INCREMENT PRIMARY KEY,
                        id_gare_dep  INT NOT NULL,
                        id_gare_arr  INT NOT NULL,
                        id_date  INT NOT NULL,
                        temps_moy_voyage FLOAT,
                        nbre_circulations INT,
                        nbre_trains_annules INT,
                        CONSTRAINT fk_idGareDep FOREIGN KEY (id_gare_dep) REFERENCES gares (id_gare),
                        CONSTRAINT fk_idGareArr FOREIGN KEY (id_gare_arr) REFERENCES gares (id_gare),
                        CONSTRAINT fk_idDate FOREIGN KEY (id_date) REFERENCES periodes (id_date)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci");

            // Créer la table `retards`
            mysqli_query($connexion,"CREATE TABLE IF NOT EXISTS retards (
                        id_retard  INT AUTO_INCREMENT PRIMARY KEY,
                        id_trajet  INT NOT NULL,
                        CONSTRAINT fk_idTrajet FOREIGN KEY (id_trajet) REFERENCES trajets (id_trajet)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci");

            // Créer la table `types_retards`
            mysqli_query($connexion,"CREATE TABLE IF NOT EXISTS types_retards (
                        id_type_retard INT AUTO_INCREMENT PRIMARY KEY,
                        description VARCHAR(255) NOT NULL
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci");

            // Créer la table d'association entre `retards` et `types_retards`
            mysqli_query($connexion,"CREATE TABLE IF NOT EXISTS retards_types_retards (
                        id_retard INT NOT NULL,
                        id_type_retard INT NOT NULL,
                        pourcentage DECIMAL(5,2),
                        PRIMARY KEY (id_retard, id_type_retard),
                        CONSTRAINT fk_idRetard FOREIGN KEY (id_retard) REFERENCES retards (id_retard),
                        CONSTRAINT fk_idTypeRetard FOREIGN KEY (id_type_retard) REFERENCES
                        types_retards (id_type_retard)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci");

            //Créer la table de seuils de retards 15, >30 ou >60 min
            mysqli_query($connexion,"CREATE TABLE IF NOT EXISTS seuils_retards (
                            id_seuil_retard INT AUTO_INCREMENT PRIMARY KEY,
                            seuil INT NOT NULL,
                            id_retard  INT NOT NULL,
                            nombre_trains INT,
                            retard_moyen FLOAT DEFAULT 0,
                            CONSTRAINT fk_seuilsIdRetard FOREIGN KEY (id_retard) REFERENCES retards (id_retard)
                        ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci");
            //Créer table details retards (à l'arrivée ou au départ)
            mysqli_query($connexion,"CREATE TABLE details_retards (
                            id_detail_retard  INT AUTO_INCREMENT PRIMARY KEY,
                            id_retard  INT NOT NULL,
                            type ENUM('depart', 'arrivee') NOT NULL,
                            nbre_trains_retardes INT,
                            retard_moy_trains_en_retard FLOAT,
                            retard_moy_tous_trains FLOAT,
                            commentaire_retards TEXT,
                            CONSTRAINT fk_detailsIdRetard FOREIGN KEY (id_retard) REFERENCES retards (id_retard)
                        ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci");

            echo "La base de données et les tables ont été créées avec succès.";
        }
        else{
            echo "Impossible de créer la BDD";
        }
    } catch (Exception $e) {
        echo "Erreur : " . $e->getMessage();
    }finally{
        mysqli_close($connexion);
    }

}

function connexionBDD($base) {
    $idConnexion = new mysqli(HOST,USER,PASS,$base,PORT);
    if (!$idConnexion){
        echo "<script type=text/javascript>";
        echo "alert('Connexion impossible à la base')</script>";
        exit();
    }
    return $idConnexion;
}

function periodeExiste($connexion, $mois, $annee){
    // Vérifier si la période existe déjà
    $stmt = $connexion->prepare("SELECT id_date FROM periodes WHERE mois = ? AND annee = ?");
    $stmt->bind_param("ii", $mois,$annee);
    $stmt->execute();
    $res = $stmt->get_result();
    return $res;
}
function obtenirOuInsererGare($connexion, $nomGare) {
    // Vérifier si la gare existe déjà
    $stmt = $connexion->prepare("SELECT id_gare FROM gares WHERE nom_gare = ?");
    $stmt->bind_param("s", $nomGare);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($res->num_rows > 0) {
        // La gare existe, récupérer son ID
        $row = $res->fetch_assoc();
        return $row['id_gare'];
    } else {
        // La gare n'existe pas, l'insérer
        $stmtInsert = $connexion->prepare("INSERT INTO gares (nom_gare) VALUES (?)");
        $stmtInsert->bind_param("s", $nomGare);
        $stmtInsert->execute();
        $idGare = $stmtInsert->insert_id;
        $stmtInsert->close();
        return $idGare;
    }
}

// Assurez-vous d'avoir une fonction qui vérifie l'existence du type de retard et retourne son ID
function obtenirIdTypeRetard($connexion, $type) {
    $stmt = $connexion->prepare("SELECT id_type_retard FROM types_retards WHERE description = ?");
    $stmt->bind_param("s", $type);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($res->num_rows > 0) {
        $row = $res->fetch_assoc();
        return $row['id_type_retard'];
    } else {
        // Insérer le nouveau type de retard si non trouvé et retourner son ID
        $stmtInsert = $connexion->prepare("INSERT INTO types_retards (description) VALUES (?)");
        $stmtInsert->bind_param("s", $type);
        $stmtInsert->execute();
        return $stmtInsert->insert_id;
    }
}
/**
 *  Pour insérer les données du fichier CSV dans la base de données
 */
function peuplerBDDdepuisCSV($base, $donnees) {

    //connexion à la bdd
    $connexion=connexionBDD($base);

    if ($connexion->connect_error) {
        die("Échec de la connexion : " . $connexion->connect_error);
    }
    // Activation du mode autocommit pour démarrer la transaction
    $connexion->autocommit(FALSE);

    try {

        //Préparer les requetes pour l'insertion
        $stmtGares = $connexion->prepare("INSERT INTO gares (nom_gare) VALUES (?)");
        $stmtPeriodes = $connexion->prepare("INSERT INTO periodes (mois,annee) VALUES (?,?)");
        $stmtTrajets = $connexion->prepare("INSERT INTO trajets (id_gare_dep, id_gare_arr, id_date, temps_moy_voyage, nbre_circulations, nbre_trains_annules) VALUES (?, ?, ?, ?, ?, ?)");
        $stmtRetards = $connexion->prepare("INSERT INTO retards (id_trajet) VALUES (?)");
        $stmtDetailsRetards = $connexion->prepare("INSERT INTO details_retards (id_retard, type, nbre_trains_retardes, retard_moy_trains_en_retard, retard_moy_tous_trains, commentaire_retards) VALUES (?, ?, ?, ?, ?, ?)");
        $stmtSeuilsRetards = $connexion->prepare("INSERT INTO seuils_retards(id_retard, seuil,nombre_trains,retard_moyen) VALUES (?,?,?,?)");
        $stmtTypesRetards = $connexion->prepare("INSERT INTO types_retards (description) VALUES (?)");
        $stmtRetardsEtTypes = $connexion->prepare("INSERT INTO retards_types_retards (id_retard, id_type_retard, pourcentage) VALUES (?, ?, ?)");

        // Pour chaque ligne de données, effectuez les insertions nécessaires
        foreach ($donnees as $ligne) {
            //insertion gare
            $idGareDep = obtenirOuInsererGare($connexion, $ligne["GareDepart"]);
            $idGareArr = obtenirOuInsererGare($connexion, $ligne["GareArrivee"]);
            echo "<br> Gare depart: ".$idGareDep;
            echo "<br> Gare Arrivée: ".$idGareArr;

            //insertion periode
            $resPeriode = periodeExiste($connexion,$ligne["Mois"],$ligne["Année"]);
            if ($resPeriode->num_rows == 0) {
                // La gare n'existe pas, donc on l'insère
                $stmtPeriodes->bind_param("ii", $ligne["Mois"],$ligne["Année"]);
                $stmtPeriodes->execute();
                // Récupérer l'ID de la gare arrivée nouvellement insérée
                $idPeriode = $stmtPeriodes->insert_id;
                echo "<br> Periode: ".$idPeriode;
            }
            else{
                $row = $resPeriode->fetch_assoc();
                $idPeriode= $row['id_date'];
            }
            //insertion trajet
            $stmtTrajets->bind_param("iiidii", $idGareDep, $idGareArr, $idPeriode, $ligne["TempsMoyenDeVoyage"], $ligne["NombreDeCirculationsPrevues"], $ligne["NombreDeTrainsAnnules"]);
            $stmtTrajets->execute();
            $idTrajet = $stmtTrajets->insert_id;

            echo "<br> Trajet: ".$idTrajet;
            //insertion retard
            $stmtRetards->bind_param("i", $idTrajet);
            $stmtRetards->execute();
            $idRetard = $stmtRetards->insert_id;
            echo "<br> Retard: ".$idRetard;

            //Insertion Types retards
            $pourcentagesRetards = [
                "Causes Externes" => $ligne["RetardCausesExternes"],
                "Infrastructure Ferroviaire" => $ligne["RetardInfrastructureFerroviaire"],
                "Gestion Du Trafic" => $ligne["RetardGestionDuTrafic"],
                "Matériel Roulant" => $ligne["RetardMatérielRoulant"],
                "Gestion Et Réutilisation Des Equipements Gare" => $ligne[ "RetardGestionEtReutilisationDesEquipementsGare"],
                "Trafic Des Passagers" => $ligne["RetardTraficDesPassagers"]
            ];
            foreach ($pourcentagesRetards as $type=>$pourcentage) {
                $idTypeRetard = obtenirIdTypeRetard($connexion, $type);
                echo "<br> TypeRetard".$idTypeRetard;

                // Insertion dans la table d'association retards_types_retards
                $stmtRetardsEtTypes->bind_param("iid", $idRetard, $idTypeRetard, $pourcentage);
                $stmtRetardsEtTypes->execute();
                $idRT =  $stmtRetardsEtTypes->insert_id;
                echo "<br> Retard& Type: ".$idRT;
            }


            //insertion détails départ
            $type = "depart"; // ENUM value
            $nbTrainsEnRetard = $ligne["NombreDeTrainsEnRetardAuDepart"];
            $retardMoyenEnRetard =$ligne["RetardMoyenDesTrainsEnRetardAuDepart"];
            $retardMoyenTousTrains = $ligne["RetardMoyenDeTousLesTrainsAuDepart"];
            $commentaire = $ligne["CommentaireSurLesRetardsAuDepart"];
            $stmtDetailsRetards->bind_param("isidds", $idRetard, $type, $nbTrainsEnRetard, $retardMoyenEnRetard, $retardMoyenTousTrains, $commentaire);

            if (!$stmtDetailsRetards->execute()) {
                throw new Exception("Erreur lors de l'insertion des détails du retard Départ : " . $stmtDetailsRetards->error);
            }

            $type = "arrivee"; // ENUM value
            $nbTrainsEnRetard = $ligne["NombreDeTrainsEnRetardALArrivee"];
            $retardMoyenEnRetard =$ligne["RetardMoyenDesTrainsEnRetardALArrivee"];
            $retardMoyenTousTrains = $ligne["RetardMoyenDeTousLesTrainsALArrivee"];
            $commentaire = $ligne["CommentaireSurLesRetardsALArrivee"];
            //insertion détails arrivée
            $stmtDetailsRetards->bind_param("isidds", $idRetard, $type, $nbTrainsEnRetard, $retardMoyenEnRetard, $retardMoyenTousTrains, $commentaire);

            if (!$stmtDetailsRetards->execute()) {
                throw new Exception("Erreur lors de l'insertion des détails du retard Arrivée : " . $stmtDetailsRetards->error);
            }
            //Insertion seuils retard
            $nbreTrains = $ligne["NombreDeTrainsEnRetardDePlusDe15Min"];
            $seuil = 15;
            $retardMoy = $ligne["RetardMoyenDesTrainsDePlusDe15Min"];
            $stmtSeuilsRetards->bind_param("iiid", $idRetard,$seuil,$nbreTrains, $retardMoy);

            if (!$stmtSeuilsRetards->execute()) {
                throw new Exception("Erreur lors de l'insertion Seuil 15min : " . $stmtDetailsRetards->error);
            }
            $nbreTrains = $ligne["NombreDeTrainsEnRetardDePlusDe30Min"];
            $seuil = 30;
            $retardMoyen = 0.0;
            $stmtSeuilsRetards->bind_param("iiid", $idRetard,$seuil, $nbreTrains,$retardMoyen);
            if (!$stmtSeuilsRetards->execute()) {
                throw new Exception("Erreur lors de l'insertion Seuil 30min : " . $stmtDetailsRetards->error);
            }

            $nbreTrains = $ligne["NombreDeTrainsEnRetardDePlusDe60Min"];
            $seuil = 60;
            $stmtSeuilsRetards->bind_param("iiid", $idRetard,$seuil, $nbreTrains,$retardMoyen);
            if (!$stmtSeuilsRetards->execute()) {
                throw new Exception("Erreur lors de l'insertion Seuil 60min : " . $stmtDetailsRetards->error);
            }

        }
            // Si tout s'est bien passé, valider la transaction
        $connexion->commit();
        echo "<h4>Données insérées</h4>";
    } catch (Exception $e) {
    // En cas d'erreur, annuler la transaction
        $connexion->rollback();
        echo "Une erreur est survenue : " . $e->getMessage();
    } finally {
        // Fermeture des statements et de la connexion
        $stmtGares->close();
        $stmtPeriodes->close();
        $stmtTrajets->close();
        $stmtRetards->close();
        $stmtDetailsRetards->close();
        $stmtSeuilsRetards->close();
        $stmtTypesRetards->close();
        $stmtRetardsEtTypes->close();

        $connexion->close();
    }
}

//Programme principal pour tester les focntions

try {
    $contenu=lireFichierCSV("Regularites_Liaisons_Trains_France.csv");
    foreach($contenu[4] as $cle => $val){
        echo $cle.": ".$val."<br/>";
    }
    // Création de la BDD
    creerBDD("trains3");
    peuplerBDDdepuisCSV("trains3", $contenu);


} catch (Exception $e) {
    echo "Erreur : " . $e->getMessage();
}
?>
