<!-- 
    Ce script joue le rôle central dans la visualisation des données et l'interaction avec l'utilisateur.
    Elle est composée du code PHP
-->

<!-- 
    BUT SD 2
    SAÉ Développement d'un composant d'une solution décisionnelle
    Par : Dalyop Yop, Renoult Julien
 -->


<!-- PARTIE PHP : TRAITEMENT -->
<?php
    // Accéder aux functions créées
    include "includes/fct_utilitaires.php";

/* Vérification si la personne a fait un choix sur l'année*/
if(isset($_GET['choix'])) {
    $choix = (integer) $_GET['choix'];
}
else{
    $choix = 2015; // Choix par défaut
}

// BLOC A Traitement

// Requête pour le premier graphique
$req = "SELECT p.annee, dr.`type`, SUM(dr.nbre_trains_retardes) AS nbr_total_retards
        FROM trajets t
        INNER JOIN periodes p ON p.id_date = t.id_date
        INNER JOIN retards r ON r.id_trajet = t.id_trajet
        INNER JOIN details_retards dr ON dr.id_retard = r.id_retard
        GROUP BY p.annee, dr.`type`
        ORDER BY p.annee;";

    $blocares = request_db($req);
    if ($blocares) {
        // echo "Succès !";
        $bloca = [];

    foreach ($blocares as $val) {
        $annee = $val["annee"];
        // var_dump($annee);
        $type = $val["type"];
        $nbrderetards = (int)$val["nbr_total_retards"];

        // Si l'année n'existe pas,
        if (!isset($bloca[$annee])) {
            $bloca[$annee] = [
                'type_ret' => [],
                'nbrderetards' => []
            ];
        }

        // Ajouter le type est le nbre de retards.
        $bloca[$annee]['type_ret'][] = $type;
        $bloca[$annee]['nbrderetards'][] = $nbrderetards;
    }

    // Convertir l'array
    $indexedBloca = array_values($bloca);

    $blocadata = json_encode($indexedBloca);

    } else {
        echo "Erreur !".mysqli_error($conn);
    }



// BLOC B Traitement

// Graphique 2a
// Requêtes pour le deuxième graphique
$req2 = "SELECT g.nom_gare, SUM(dr.nbre_trains_retardes) as retards_depart
        FROM trajets t
        INNER JOIN gares g ON g.id_gare = t.id_gare_dep 
        INNER JOIN retards r ON r.id_trajet = t.id_trajet
        INNER JOIN details_retards dr ON dr.id_retard = r.id_retard
        WHERE dr.type = 'depart' -- Filtrer les lignes par type de retard
        GROUP BY g.nom_gare
        ORDER BY retards_depart desc limit 5;";

    $blocbres1 = request_db($req2);

    if($blocbres1){
        // echo "Succès !";
        // var_dump($blocbres1);

        $nomgare =[];
        $retards1 = [];

        foreach($blocbres1 as $val){
            $nomgare[] = $val["nom_gare"];
            $retards1[] = (integer) $val["retards_depart"];
        }

        $blocb1data = [
            "nom_gare" => $nomgare,
            "retards_depart" => $retards1
        ];

        $blocb1data = json_encode($blocb1data);
        // var_dump($blocb1data);
    }
    else{
        echo "Erreur !".mysqli_error($conn);
    }
    
// Graphique 2b
    $req2b = "SELECT g.nom_gare, SUM(dr.nbre_trains_retardes) as retards_arrivee
    FROM trajets t
    INNER JOIN gares g ON g.id_gare = t.id_gare_dep 
    INNER JOIN retards r ON r.id_trajet = t.id_trajet
    INNER JOIN details_retards dr ON dr.id_retard = r.id_retard
    WHERE dr.type = 'arrivee' -- Filtrer les lignes par type de retard
    GROUP BY g.nom_gare
    ORDER BY retards_arrivee desc limit 5;";

$blocbres2 = request_db($req2b);

if($blocbres2){
    // echo "Succès !";
    // var_dump($blocbres2);

    $nomgare2 =[];
    $retards2 = [];

    foreach($blocbres2 as $val){
        $nomgare2[] = $val["nom_gare"];
        $retards2[] = (integer) $val["retards_arrivee"];
    }

    $blocb2data = [
        "nom_gare" => $nomgare2,
        "retards_arrivee" => $retards2
    ];

    $blocb2data = json_encode($blocb2data);
    // var_dump($blocb2data);
}
else{
    echo "Erreur !".mysqli_error($conn);
}


// Pour le bloc C, D et E sur les années
/* Récupération des différentes années pour la construction du choix de l'année */
$annees = request_db("SELECT DISTINCT annee FROM periodes ORDER BY annee;");

// Graphique 3

// Requête pour les retards arrivées 
$req3 = "SELECT p.mois , SUM(dr.nbre_trains_retardes) AS nbr_total_retards
            FROM trajets t
            INNER JOIN periodes p ON p.id_date = t.id_date
            INNER JOIN retards r ON r.id_trajet = t.id_trajet
            INNER JOIN details_retards dr ON dr.id_retard = r.id_retard
            WHERE dr.type = 'arrivee' AND p.annee = ? -- utiliser un place holder - requêtage dynamique et éviter de mauvaises surprises
            GROUP BY p.mois ORDER BY p.mois ASC;";

// Requête pour les retards arrivées 
$req3ii = "SELECT p.mois , SUM(dr.nbre_trains_retardes) AS nbr_total_retards
    FROM trajets t
    INNER JOIN periodes p ON p.id_date = t.id_date
    INNER JOIN retards r ON r.id_trajet = t.id_trajet
    INNER JOIN details_retards dr ON dr.id_retard = r.id_retard
    WHERE dr.type = 'depart' AND p.annee = ? -- utiliser un place holder - requêtage dynamique et éviter de mauvaises surprises
    GROUP BY p.mois ORDER BY p.mois ASC;";

$params = "i"; // année est un entier

$resultat3arr = mysqlrequest($req3, connect_db(), [$choix], $params);
$resultat3arr = json_encode($resultat3arr);
// var_dump($resultat3arr); // visualiser les résultats arrivées


$resultat3dep = mysqlrequest($req3ii, connect_db(), [$choix], $params);
$resultat3dep = json_encode($resultat3dep);
// var_dump($resultat3dep); // visualiser les résultats départs




// BLOC D Traitement

//// Partie graphique :
$blocd = cause_annee($choix);
//var_dump($blocd);
$blocd = json_encode($blocd);
//var_dump($blocd);

//// Partie commentaire :
// Commentaire sur les retards en question pour l'année sélectionnée
$commentaire = commentaire_retard($choix);
//var_dump($commentaire);

// BLOC E Traitement
// Récupération des effectifs des trains sur l'année
$bloce = seuil_annee($choix); // choix = année choisie
//var_dump($bloce);
$bloce = json_encode($bloce);
//var_dump($bloce);

?>





<!-- PARTIE HTML : AFFICHAGE -->

<!DOCTYPE html> 
<html lang="fr">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title> Analyse des Retards de Trains en France </title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>

<body>
    <h1> Analyse des retards de Trains en France</h1>
    <hr>
    <div style="background-color: #f0f8ff80; border-radius: 10px; padding: 10px; max-width: 1250px; margin: 0 auto; margin-bottom: 20px; margin-top: 20px; font-size: 24px;">
            <p> &nbsp;&nbsp;📍La France a actuellement le deuxième réseau ferroviaire européen avec un total de 29 901 kilomètres de voies ferrées. <a href="https://www.sncf.com/fr" target="_blank"> La SNCF</a>, société nationale des chemins de fer, exploite la plupart des services de transports de voyageurs et de marchandises sur le réseau national géré par sa filiale SNCF Réseau. <br/> &nbsp; Malheureusement, les départs et les arrivées des trains sont souvent retardés pour diverses raisons. Nous explorons en détail ces retards et soulignons les tendances des retards. Ceci aidera à améliorer les services ferroviaires en France. </p>
    </div> 


    <div class="dashboard-container">
        <!-- Bloc a -->
        <div class="dashboard-block">
            <canvas id="diag1" height="547" width="600"></canvas>
            <script id="bloca" type="application/json">
                <?= $blocadata ?>
            </script>
            <div style="background-color: #f0f8ff80;">
                 <p> &nbsp &nbsp💡L'impact de la pandemie : <br/> On constate une augmentation constante du nombre de trains annulés entre 2015 et 2018. L'année 2019 se démarque - ce qui n'est pas surprenant étant donné que la fin de l'année 2019 a marqué le début de la tristement célèbre pandémie COVID-19 qui a paralysé le secteur de transport. </p>
            </div>
        </div>

        <!-- Bloc b -->
        <div class="dashboard-block">
            <div class="sub-block">
                <canvas id="diag2a"></canvas>
                <script id="blocb1" type="application/json"> 
                    <?= $blocb1data ?>
                </script>
            </div>
            <div class="sub-block">
                <canvas id="diag2b"></canvas>
                <script id="blocb2" type="application/json"> 
                    <?= $blocb2data ?>
                </script>
            </div>
            <div style="background-color: #f0f8ff80;">
                 <p> &nbsp &nbsp <a href="https://www.ouest-france.fr/tourisme/decouvrez-le-classement-des-meilleures-gares-deurope-la-france-dans-le-top-10-d7ca9308-98f7-11ee-8c0c-39439450f6ad#:~:text=La%20gare%20du%20Nord%2C%20la,e%20place%20(77%20points)" target="_blank"> Le saviez-vous ?</a> La gare du Nord, la plus fréquentée d'Europe avec environ 700 000 voyageurs quotidiens, pointe quant à elle à la 13e place. Deux autres gares parisiennes se placent juste derrière : la gare Saint-Lazare, à la 15e place, et la gare Montparnasse, à la 18e place. </p>
            </div>
        </div>

 <!-- Bloc c -->
        <script id="annee" type="application/json"> <?= $choix ?></script>
                <div class="dashboard-block">
                                <!-- Sélection de l'année -->
                    <form method="get">
                        <select name="choix">
                            <?php 
                            // Sélection des années distinctes

                            $deb_opt = "<option value='";
                            $fin_opt = "</option>";
                            $chaine = "";
                            foreach($annees as $annee){
                                $chaine.=$deb_opt.$annee["annee"]."'>".$annee["annee"].$fin_opt;
                            }
                            echo $chaine;
                            ?>
                        </select>
                    <input type="submit" value="Changer l'année">
                    </form>
                    <!-- ------------------------------------------- -->
                            <div class="sub-block">
                                <h3> <center> Retards par mois concernant les arrivées </center> </h3>
                                <canvas id="diag3a" height="332"></canvas>
                                    <script id="bloc3a" type="application/json"> 
                                        <?= $resultat3arr ?>
                                    </script>
                            </div>
                            <hr>
                            <div class="sub-block">
                                <h3> <center> Retards par mois concernant les départs </center> </h3>
                                <canvas id="diag3b" height="332"></canvas>
                                    <script id="bloc3b" type="application/json"> 
                                        <?= $resultat3dep ?>
                                    </script>
                            </div>
                <div style="background-color: #f0f8ff80;">
                <hr>
                    <p> &nbsp &nbsp La période des vacances est la période ayant le plus de retards à l'arrivée et au départ de 2015 à 2019. L'année 2020, l'année de la pandémie COVID-19, n'a pas d'autres records à partir de juin. Le système de transport a été mis en arrêt et la collecte des données limitée. </p>
                </div>
            </div>

            <!-- ------------------------------------------------------------------------------------ -->

        <!-- Bloc d -->
        <div class="dashboard-block">
            <h3 id="titreD">Répartition en pourcentage des retards par cause, selon le mois en <?= $choix ?></h3>
            <script id="blocd" type="application/json"> 
                    <?= $blocd ?>
                </script>

<?php 

            /* Récupération des différentes causes de retard */
            $liste_cause = request_db("SELECT DISTINCT description FROM types_retards;");

            /* Création de la structure HTML */
            // Création des deux balises div qui vont contenir chacune d'elle trois camemberts (six causes de retards au total)
            $deb_div = "<div class='PieChart'>";
            $fin_div = "</div>";

            // Création des balises canvas ayant comme dimension (200x350)
            $deb = "<canvas id = '";
            $fin = "' height = '300' width = '350'></canvas>";

            // Initialisation de la chaîne qui va contenir toutes les informations
            $chaine = "";

            /* Application de la structure HTML (répétition de ces différentes étapes)*/
            foreach($liste_cause as $cause){
                /* 1ÈRE ÉTAPE : Création de l'identifiant */
                // Identifiant : InitialesCPie
                $init = "";
                // Récupérer la première lettre de chaque mot
                $tab_car = explode(" ", $cause["description"]);
                foreach($tab_car as $ch){
                    $init .= $ch[0];    
                }
                //var_dump($init);
                //var_dump($tab_car);

                /* 2ÈME ÉTAPE : Définir le début et la fin des div */
                if($init == "CE" | $init == "GDT" | $init == "GERDEG"){ // CE : Causes Externes, MR : Matériel Roulant
                    $chaine .= $deb_div;
                }

                /* 3ÈME ÉTAPE : Création de la ligne qui va contenir le graphique concernant la cause actuelle */
                $chaine .= $deb.$init."Pie".$fin;

                if($init == "IF" | $init == "MR" | $init == "TDP"){ // GDT : Gestion Du Trafic, TDP : Trafic Des Passagers
                    $chaine .= $fin_div;
                }
                /********************************************************************************/
            }

            //var_dump($chaine);

            /* Ajout dans la structure HTML */
            echo $chaine;
?>
        </div>

        <!-- Bloc e -->
        <div class="dashboard-block2">
            <canvas id="diag5" height="500" width="680"></canvas>
            <script id="bloce" type = "application/json"><?= $bloce ?></script>

                            <!-- Bloc d : commentaire des retards -->
<?php
                // Ajout des commentaires
            $deb_mois = "<ul class='tmois'>";
            $deb_comm = "<ul class='commentaire'>";
            $fin = "</ul>";

            $ch_comm = "<h3 style='background-color: #f0f8ff80; border-radius: 10px; padding: 10px; max-width: 1250px; font-size: 24px;'> Les commentaires sur les retards de train en ".$choix." : </h3>";
            foreach($commentaire as $mois => $tab_com){

                // Dans le cas des accents sur les mois
                $mois = str_replace("é", "É", $mois);
                $mois = str_replace("û", "Û", $mois);
                $ch_comm .= $deb_mois;
                $ch_comm .= "<li class='mois'><h2>".strtoupper($mois)." : </h2></li>";
                $ch_comm .= $deb_comm;
                for($i = 0; $i < count($tab_com); $i++){
                    $nb=$i+1;
                    $ch_comm.="<li class='comm'><h4> Commentaire n°".$nb." : </h4> <p>".$tab_com[$i]."</p></li>";
                }
                $ch_comm .= $fin.$fin;
            }

            // Variable booléenne qui va servir s'il faut afficher ou non les détails
            $montrer_element = false;
?>
            <!-- Bouton d'affichage des détails -->
            <button onclick="toggle_visibility('comm')">Afficher Détails</button>

            <!-- Affichage des commentaires sur les retards dans le HTML -->
            <div id='comm' style="<?php if (!$montrer_element) echo 'display: none;'; ?>">
            <?php
            echo $ch_comm;
            ?>
        </div>
    </div>



    <!-- Librairie JavaScript Chart JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.js"></script>
    <script src="graphiques.js"></script>
</body>
    <div class="footer">
        <i>
    <center> <strong> Par : Dalyop Yop, Renoult Julien
    <br/>
    Université de Caen : IUT Grand Ouest Normandie
    <br/>
    <a href="https://uniform.unicaen.fr/catalogue/formation/but/6769-but-statistique-et-informatique-decisionnelle", target="_blank"> BUT Science des données 2 </a> </strong> </center>
        </i>
    </div>

</html>

