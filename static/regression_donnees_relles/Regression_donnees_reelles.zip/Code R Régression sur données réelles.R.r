# ======================================= #
# SAE - Régression sur données réelles
# Auteurs : Julien Renoult - Nomel Lin Romuald Djahoua - Axelle Rukiramarigo 
# Date : 02/03/2023-05/04/2023
# Données : bodyfat.csv
# Source : https://www.kaggle.com/datasets/fedesoriano/body-fat-prediction-dataset?resource=download
# ======================================= #

# ---- Chargement des librairies ----

library(flextable) # flextable()
library(modelsummary) # modelsummary()

# ======================================= #
# ---- Chargement des données  -----

## Lecture des 10 premières lignes du fichier

readLines(con = "../Data/bodyfat.csv", n=10)

# Commentaires :
# - On voit que la première ligne contient le nom des variables, 
# - On voit que le séparateur est un point virgule 
# - On voit que toutes les variables sont des variables quantitatives à part case qui représente l'id.

## Importation des données dans dataset :

dataset = read.table(file = "../Data/bodyfat.csv",
                     header = TRUE,
                     sep = ";",
                     encoding = "UTF-8",
                     quote = "\"")

## Contrôle de l'importation des données :

# Affichage des dix premières lignes du fichier.

head(dataset, 10) 

# Affichage de la structure du fichier.

str(dataset) 

# Commentaires :
# - On a bien 252 observations dans la base de données.
# - Toutes les données sont déjà dans le bon format.
# - Cependant le poids et la taille ne sont pas dans les bonnes unités
# pour pouvoir calculer l'indice de masse maigre donc il faudra les convertir.


# ======================================= #
# ---- Préparation des données (1/2)----

## Modification des unités.
  
within(dataset,
     weight<-weight*0.453592) -> dataset

within(dataset,
       height<-height*0.0254) -> dataset

# Vérification du succès de la conversion.

head(dataset, 10)

# Commentaire :
# - Conversion du poids (Livre ou IBS) en kilogramme en sachant que 1 IBS= 0.453592 Kilogramme.
# - Conversion de la taille (Inches ou Pouces) en mètre en sachant que 1 inches = 0.0254 Mètre.

## Création des indicateurs Siri, FFM, FFMI :

# Calcul de l'indicateur Siri

data.frame(dataset, Siri= (495/dataset$density)-450) -> dataset

# Calcul de l'indicateur FFM

data.frame(dataset, FFM=dataset$weight*(1-(dataset$Siri/100))) -> dataset

# Calcul de l'indicateur FFMI

data.frame(dataset, FFMI=dataset$FFM/(dataset$height*dataset$height)) -> dataset

# Contrôle des données

head(dataset, 10)
str(dataset)

## Sélection des variables d'intérêts :

data=subset(dataset, select = c(neck,chest,abdomen,hip,thigh,knee,ankle,biceps,forearm,wrist,FFMI))

# Contrôle des données

head(data, 10)
str(data)

# ======================================= #
# ---- Analyse exploratoire (1/2)----

## Résumé des variables d'intérêts

summary(data)

# Commentaire :
# - Toutes les variables observés dans data n'ont aucune donnée manquante ni aberrante
# - Cependant, on peut observer une valeur fortement atypique avec le FFMI qui a comme maximum 111.09

## Création des boîtes à moustaches pour chaque variable d'intérêts

boxplot(data,
            main="Distributions des variables d'intérêt",
            xlab = "Variable d'intérêt",
            ylab = "Valeur",
            las=1)

mtext("BUT Science des Données - Lisieux", side = 1, line = 3, adj = 0)

mtext("Source : Kaggle Bodyfat", side = 1, adj = 1, line = 3)

# Commentaire :
# - On peut observer des valeurs aytpiques représenté par des points sur le graphique avec tous les boxplots

## Création d'une base de données contenant toutes les valeurs avec leurs variables d'intérèts qui sera nommé table_val

stack(data, drop = FALSE) -> table_val

# Affichage des dix pemières lignes de données et de la structure de la table_val

head(table_val, 10)
str(table_val)

## Création de la fonction qui permet la détection de valeurs atypiques

detecter_atypiques <- function(var, coef=1.5) {
  q1 <- quantile(data[[var]], 0.25)
  q3 <- quantile(data[[var]], 0.75)
  iqr <- q3 - q1
  seuil_sup <- q3 + coef * iqr
  seuil_inf <- q1 - coef * iqr
  si_sinon=with(table_val, ifelse(ind==var,ifelse(values>seuil_sup,TRUE,ifelse(values<seuil_inf,TRUE,FALSE)),FALSE))
  subset(table_val, subset = si_sinon) -> table_valvar
}

## Détection des valeurs atypiques pour chaques variables d'intérèts

# Commentaire : 
# - Nous avons décidé de mettre comme coefficient 3 pour détecter les valeurs fortement atypiques

# Valeur(s) atypique(s) pour neck

valeurs_neck<-detecter_atypiques("neck", 3)
head(valeurs_neck)

# Détection d'une seule valeur fortement atypique pour neck

# Valeur(s) atypique(s) pour FFMI

valeurs_FFMI<-detecter_atypiques("FFMI", 3)
head(valeurs_FFMI)

# Détection de deux valeurs fortement aytpiques pour FFMI

# Valeur(s) atypique(s) pour abdomen

valeurs_abdomen<- detecter_atypiques("abdomen", 3)
head(valeurs_abdomen)

# Détection d'une seule valeur fortement atypique pour abdomen

# Valeur(s) atypique(s) pour thigh

valeurs_thigh<- detecter_atypiques("thigh", 3)
head(valeurs_thigh)

# Détection d'une seule valeur fortement atypique pour thigh

# Valeur(s) atypique(s) pour knee

valeurs_knee <- detecter_atypiques("knee", 3)
head(valeurs_knee)

# Détection d'une seule valeur fortement atypique pour knee

# Valeur(s) atypique(s) pour ankle

valeurs_ankle <- detecter_atypiques("ankle", 3)
head(valeurs_ankle)

# Détection de deux valeurs fortement atypiques pour ankle

# Valeur(s) atypique(s) pour biceps

valeurs_biceps <- detecter_atypiques("biceps", 3)

# Pas de présence de valeurs fortment atypiques pour biceps

# Valeur(s) atypique(s) pour forearm

valeurs_forearm <- detecter_atypiques("forearm", 3)

# Pas de présence de valeurs fortement atypiques pour forearm

# Valeur(s) atypique(s) pour chest

valeurs_chest <- detecter_atypiques("chest", 3)

# Pas de présence de valeurs fortement atypiques pour chest

# Valeur(s) atypique(s) pour hip

valeurs_hip <- detecter_atypiques("hip", 3)
head(valeurs_hip)

# Détection d'une seule valeur fortement atypique pour hip

# Valeur(s) atypiques pour wrist

valeurs_wrist <- detecter_atypiques("wrist", 3)

# Pas de présence de valeurs fortement atypiques pour wrist

## Trouver les observations de data contenant ces résultats :

subset(x = dataset, subset = abdomen==148.1 | ankle>33 | FFMI>30 | hip==147.7 | knee==49.1 | neck==51.2 | thigh==87.3)-> obs_fort_atypiques

# Vérification du succès de l'opération :

head(obs_fort_atypiques)

# Tableau d'observations fortement atypiques :

flextable(obs_fort_atypiques) -> ft
ft <- set_caption(ft, caption = "Observations fortements atypiques")
ft

# Commentaire :
# - On trouve qu'il a 4 observations qui contiennent une ou plusieurs valeurs dans leurs variables d'intérèts qu'ils sont fortement atypiques
# - Cette détection permet à la suite de les supprimer de la base de données


## Création des histogrammes pour les variables d'intérêts :

# Création de la fonction qui permet de faire l'histogramme et la densitée lissée

Graph1 = function(var){
  hist(data[[var]],
       col="grey80",
       probability = TRUE,
       main = paste("Distribution",var,sep=" - "),
       xlab = var)
  lines(density(data[[var]]),
        col = "blue",
        lwd = 2)
}

## Représentation graphique des variables d'intérèts :

# Représentation graphique d'abdomen, hip, thigh, knee, ankle, biceps

par(mfrow = c(3,2))

lapply(X = names(subset(data,select= c(abdomen,hip,thigh,knee,ankle,biceps))),
       FUN = Graph1)

par(mfrow = c(1,1))

# Représentation graphique de neck, chest, wrist, forearm, FFMI

par(mfrow = c(3,2))

lapply(X = names(subset(data,select= c(neck,chest,wrist,forearm,FFMI))),
       FUN = Graph1)

par(mfrow = c(1,1))

# Commentaire :
# - Distribution d'abdomen, hip, biceps, thigh, knee, hip, ankle, neck, chest, wrist, forearm semble symétrique 
# même si on voit que la présence de certains valeurs atypiques viennent pertuber le graphique de ces variables d'intérèts
# - Distribution FFMI est asymétrique du au valeurs fortement atypiques (110 et 30)

## Création des nuages de dispersions : FFMI vs les autres variables quantitatives :

# Création de la fonction permettant l'apparition du nuage de point avec la densité lissée

Graph2 = function(varx){
  
  Loess = loess(data[["FFMI"]] ~ data[[varx]])
  
  temp = data.frame(data[,c("FFMI",varx)],
                    Loess = fitted(Loess))
  
  temp = temp[order(temp[[varx]]),]
  
  
  plot(data[["FFMI"]] ~ data[[varx]],
       pch = 20,
       main = paste("Nuage de dispersion : FFMI vs ",varx,sep = ""),
       xlab = varx,
       ylab = "FFMI")
  
  lines(temp$Loess ~ temp[[varx]],
        col = "red",
        lwd = 2)
}

## Représentation graphique des nuages de dispersion avec comme variable à expliquer le FFMI versus les variables morphologiques:

# Représentation graphique avec les variables neck, chest, abdomen, hip :

par(mfrow = c(2,2))

lapply(X = names(subset(data,
                        select = c(neck,chest,abdomen,hip))),
       FUN = Graph2)

par(mfrow = c(1,1))

# Représentation graphique avec les variables wrist, thigh, knee, forearm :

par(mfrow = c(2,2))

lapply(X = names(subset(data,
                        select = c(wrist,thigh,knee,forearm))),
       FUN = Graph2)

par(mfrow = c(1,1))

# Représentation graphique avec les variables ankle et biceps :

par(mfrow = c(1,2))

lapply(X = names(subset(data,
                        select = c(ankle,biceps))),
       FUN = Graph2)

par(mfrow = c(1,1))

# Commentaire :
# - Pour toutes les nuages de points, il existe une valeur fortement atypique qui est le FFMI en 110 ce qui gâche l'observation
# et ne permet vraiment pas d'observer efficacement les points sur les nuages de dispersion

# ======================================= #
# ---- Préparation des données (2/2)----

## On va enlever les observations fortement aytpiques détectés avec obs_fort_atypiques :

subset(data[-c(31,39,42,86),])-> data

### Représentation graphique après suppression des lignes de données :

## Histogramme :

# Représentation graphique d'abdomen, hip, thigh, knee, ankle, biceps :

par(mfrow = c(3,2))

lapply(X = names(subset(data,select= c(abdomen,hip,thigh,knee,ankle,biceps))),
       FUN = Graph1)

par(mfrow = c(1,1))

# Représentation graphique de neck, chest, wrist, forearm, FFMI :

par(mfrow = c(3,2))

lapply(X = names(subset(data,select= c(neck,chest,wrist,forearm,FFMI))),
       FUN = Graph1)

par(mfrow = c(1,1))

# Commentaire :
# - Après la suppresion de valeurs fortement atypiques, on peut observer qu'à peu près toutes les ditributions notamment FFMI semble être symétrtiques
# - Nous pouvons donc dire que le problème est réglé pour l'analyse univarié

## Nuage de dispersion :

# Représentation graphique avec les variables neck, chest, abdomen, hip :

par(mfrow = c(2,2))

lapply(X = names(subset(data,
                        select = c(neck,chest,abdomen,hip))),
       FUN = Graph2)

par(mfrow = c(1,1))

par(mfrow = c(2,2))

lapply(X = names(subset(data,
                        select = c(wrist,thigh,knee,forearm))),
       FUN = Graph2)

par(mfrow = c(1,1))

par(mfrow = c(1,2))

lapply(X = names(subset(data,
                        select = c(ankle,biceps))),
       FUN = Graph2)

par(mfrow = c(1,1))

# Commentaire :
# - Nous pouvons observer que pour tous les nuages de dispersion, la distribution des points semble bien distribué et leur régression lissée semble être une droite
# - Cependant, on peut observer la présence de valeur aytpique dans les nuages de dispersions notamment avec FFMI vs forearm, FFMI vs neck et FFMI vs knee mais elles ne sont pas fortement atypiques


# ======================================= #
# ---- Analyse exploratoire (2/2)----

### Corrélation linéaire de Pearson :

## Préparation/Application des calculs :

# On crée une base de données var_rep qui contient toutes les variables d'intérèts à part FFMI :

subset(data,
       select = -c(FFMI))->var_rep

# Création de la fonction qui permet de faire la corrélation linéaire de Pearson :

Corrélation_linéaire <- function(var){
  Pearson= round(cor(data[[var]],data$FFMI)*100, 2)
  return(Pearson)
}


# Application de la fonction de corrélation sur les fonctions d'intérèts :

lapply(X = names(var_rep),
       FUN = Corrélation_linéaire) -> table_corr

# Vérification de la corrélation de chaque variable d'intérèt :

print(table_corr)

## Création du tableau de synthèse :

# Modifier la base de données var_rep pour qu'ils ne contiennent cette fois-ci 
# que les corrélations linéaires de chaque variable d'intérèt :

data.frame(table_corr) -> var_rep

# Vérification du succès de l'opération

head(var_rep)

# Modifications des noms des variables :

colnames(var_rep)=colnames(data[-11])

# Vérification du succès de l'opération

head(var_rep)

## Partie représentation du tableau :

ft <- flextable(var_rep)

ft <- set_caption(ft, caption = "Corrélation FFMI & variables morphologiques")

ft

# Commentaire :
# - On peut observer que pour toutes les variables morphologiques avec la variable FFMI, 
# on a une corrélation linéaire positif de plus de 30 %.
# - On peut dire que neck à la plus grande Corrlélation linéaire positif parmi toutes les variables morphologiques
# et donc peut-être la meilleure variable pour la modélisation d'une droite de régression
# - Nous allons le vérifier avec le coefficient de détermination

# ======================================= #
# ---- Modélisation ----

## Modèle 1 : neck versus FFMI :

model1 = lm(FFMI ~ neck, data = data)

summary(model1)

# Commentaire :
# - Équation du modèle : m(neck) = 3.762 + 0.436 x neck
# - 31.42 % de variabilité expliqué par la variable neck

## Modèle 2 : abdomen versus FFMI

model2 = lm(FFMI ~ abdomen, data = data)

summary(model2)

# Commentaire :
# - Équation du modèle : m(abdomen) = 14.393 + 0.064 x abdomen
# - 13.44 % de variabilité expliqué par la variable abdomen


## Modèle 3 : wrist versus FFMI

model3 = lm(FFMI ~ wrist, data = data)

summary(model3)

# Commentaire :
# - Équation du modèle : m(wrist) = 1.067 + 0.8452 x wrist
# - 30.09 % de variabilité expliqué par la variable wrist

## Modèle 4 : chest versus FFMI

model4 = lm(FFMI ~ chest, data = data)

summary(model4)

# Commentaire :
# - Équation du modèle : m(chest) = 8.927 + 0.113 x chest
# - 26.79 % de variabilité expliqué par la variable chest

## Modèle 5 : hip versus FFMI

model5 = lm(FFMI ~ hip, data = data)

summary(model5)

# Commentaire :
# - Équation du modèle : m(hip) = 5.808 + 0.145 x hip
# - 27.7 % de variabilité expliqué par la variable hip

## Modèle 6 : knee versus FFMI

model6 = lm(FFMI ~ knee, data = data)

summary(model6)

# Commentaire :
# - Équation du modèle : m(knee) = 6.565 + 0.356 x knee
# - 21.48 % de variabilité expliqué par la variable knee

## Modèle 7 : thigh versus FFMI

model7 = lm(FFMI ~ thigh, data = data)

summary(model7)

# Commentaire :
# - Équation du modèle : m(thigh) = 8.745 + 0.195 x thigh
# - 28.84 % de variabilité expliqué par la variable thigh

## Modèle 8 : forearm versus FFMI

model8 = lm(FFMI ~ forearm, data = data)

summary(model8)

# Commentaire :
# - Équation du modèle : m(forearm) = 7.824 + 0.435 x forearm
# - 24.57 % de variabilité expliqué par la variable forearm


## Modèle 9 : ankle versus FFMI

model9 = lm(FFMI ~ ankle, data = data)

summary(model9)

# Commentaire :
# - 24.52 % de variabilité expliqué par la variable ankle
# - Équation du modèle : m(ankle) = 5.173 + 0.658 x ankle

## Modèle 10 : biceps versus FFMI

model10 = lm(FFMI ~ biceps, data = data)

summary(model10)

# Commentaire :
# - 28.06 % de variabilité expliqué par la variable biceps
# - Équation du modèle : m(biceps) = 9.907 + 0.322 x biceps

# ========================================================== #
# ---- Comparaison des différents modèles ----

## Création d'un tableau de comparaison :

# Préparation de la comparaison des différents modèles :

models = list(Model1 = model1,
              Model2 = model2,
              Model3 = model3,
              Model4 = model4,
              Model5 = model5,
              Model6 = model6,
              Model7 = model7,
              Model8 = model8,
              Model9 = model9,
              Model10 = model10)

# Présentation du tableau de comparaison :

modelsummary(models)

# Présentation du tableau de synthèse des coefficients de détermination :

model1C = summary(model1)[8]
model2C = summary(model2)[8]
model3C = summary(model3)[8]
model4C = summary(model4)[8]
model5C = summary(model5)[8]
model6C = summary(model6)[8]
model7C = summary(model7)[8]
model8C = summary(model8)[8]
model9C = summary(model9)[8]
model10C = summary(model10)[8]


data.frame(c(model1C[1],model2C[1], model3C[1],
             model4C[1],model5C[1], model6C[1],
             model7C[1], model8C[1], model9C[1],
             model10C[1])) -> Coefficient_determination

colnames(Coefficient_determination)=c("neck", "abdomen", "wrist", "chest", "hip", "knee", "thigh", "forearm", "ankle", "biceps")

Coefficient_determination[1,1:10]=round(Coefficient_determination[,1:10]*100,2)

ft <- flextable(Coefficient_determination)

ft <- set_caption(ft, caption = "Coefficient de détermination FFMI & variables morphologiques")

ft
# Commentaire :
# - Il semblerait que le meilleur modèle qui explique le plus,
# la variabilitée de l'indice de masse est le modèle 1 avec un coefficient de détermination de 31.77 %
# - Dans ce modèle, on utilise la variable neck comme variable explicative

# ======================================= #
# ---- Visualisation et interprétation du meilleur modèle ----

# Création de la régression lissée :

with(data,
     loess(FFMI ~ neck, span=0.8)) -> smooth

smooth = data.frame(neck = data$neck,
                    smooth=fitted(smooth))

smooth= smooth[order(smooth$neck,decreasing=FALSE),]

# Représentation du modèle sans la régression lissée:

with(data,
     plot(FFMI ~ neck,
          pch = 21,
          col = "black",
          bg = "purple",
          las = 1,
          cex = 0.7,
          main= "Droite des moindres carrés (neck VS FFMI)",
          xlab= "Variable neck",
          ylab = "Variable FFMI"))

abline(model1,
       col="green4",
       lty=1,
       lwd=3)

text(x=32, y=26, "FFMI = 3.762 + 0.436 x neck")
text(x=32, y=25.65, "R-Squared = 31.42%")

mtext("BUT Science des Données - Lisieux", side = 1, line = 3, adj = 0)

mtext("Source : Kaggle Bodyfat", side = 1, adj = 1, line = 3)

# Représentation du modèle et de la régression lissée :

with(data,
     plot(FFMI ~ neck,
          pch = 21,
          col = "black",
          bg = "purple",
          las = 1,
          cex = 0.7,
          main= "Droite des moindres carrés et régression lissée (neck VS FFMI)",
          xlab= "Variable neck",
          ylab = "Variable FFMI"))

with(smooth,
     lines(smooth ~ neck,
           col="red",
           lty=2,
           lwd=3))

abline(model1,
       col="green4",
       lty=1,
       lwd=3)

text(x=32.25, y=24.75, "FFMI = 3.762 + 0.436 x neck")
text(x=32, y=24.5, "R-Squared = 31.42%")

legend(x = "topleft",
       lty = c(2,1),
       lwd = c(3,3),
       col = c("red","green4"),
       legend = c("Régression lissée", "Droite des moindres carrés"),
       bty = "n")

mtext("BUT Science des Données - Lisieux", side = 1, line = 3, adj = 0)

mtext("Source : Kaggle Bodyfat", side = 1, adj = 1, line = 3)

# Commentaire :
# - On peut voir que la droite des moindres carrés ne se superpose pas sur la régression lissée
# - Cela est du sûrement à des valeurs atypiques qu'ils sont dans le graphique